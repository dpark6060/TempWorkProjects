#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import scipy.stats as sts
import subprocess as sp



def GenerateGradientSequence(Nx,Ny,dx,dy,T):
    
    Npoints=Nx*Ny
    dt=T/Npoints
    xMid=Nx/2.0
    yMid=Ny/2.0
    
    
    FOVx=dx*Nx
    FOVy=dy*Ny
    
    # For Possum: Gmax=0.055 T/m
    #Gmax=0.055          #T/m
    gamma=42.6e6        #MHz/tesla
        
    dkx=1.0/FOVx
    dky=1.0/FOVy
    dkz=1.0/FOVz
    
    Kminx=-1*xMid*dkx
    Kmaxx=xMid*dkx
    
    Kminy=-1*yMid*dky*2
    Kmaxy=yMid*dky*2
    
    


    
