#!/usr/bin/env python

import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import scipy.stats as sts
import subprocess as sp
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import scipy.interpolate as ipt
import Invdisttree as ivd
print np.__path__


x=[0,1,2,0,1,2,0,1,2]
y=[0,0,0,1,1,1,2,2,2]
C=np.array([x,y]).T

z=[[0,1,2],[3,4,5],[6,7,8]]
X,Y=np.meshgrid([0,1,2],[0,1,2])


#fImag=ipt.interp2d(SliceKx,SliceKy,np.imag(FftSlice),kind='linear',bounds_error=False,fill_value=0)
    
#f=ipt.interp2d(X,Y,z,kind='linear',bounds_error=False,fill_value=10)

nx=[0.5,1.0,1.5,0.5,1.0,1.5,0.2,1.0,1.5]
ny=[0.3,0.3,0.3,1.2,1.2,1.2,1.9,1.5,1.5]

nC=np.array([nx,ny]).T

N = 100
d=10
z=np.arange(N)

x=range(10)
y=range(10)
X,Y=np.meshgrid(x,y)
y=np.zeros(len(x)*len(y))
x=[]
for i in range(10):
    x=x+range(10)
    y[i*10:(i+1)*10]=i


C=np.array([x,y]).T

nx=np.array(x)+np.random.rand(len(x))*0.3
ny=np.array(y)+np.random.rand(len(y))*0.3

nC=np.array([nx,ny]).T

Ndim = 2
Nask = N  # N Nask 1e5: 24 sec 2d, 27 sec 3d on mac g4 ppc
Nnear = 4  # 8 2d, 11 3d => 5 % chance one-sided -- Wendel, mathoverflow.com
leafsize = 16
eps = .1  # approximate nearest, dist <= (1 + eps) * true nearest
p = 1  # weights ~ 1 / distance**p
cycle = .25
seed = 1


#...............................................................................
invdisttree = ivd.Invdisttree( C, z, leafsize=leafsize, stat=1 )
nz = invdisttree( nC, nnear=Nnear, eps=eps, p=p )

# print "average distances to nearest points: %s" % \
#     np.mean( invdisttree.distances, axis=0 )
# print "average weights: %s" % (invdisttree.wsum / invdisttree.wn)
#     # see Wikipedia Zipf's law
# err = np.abs( terrain(ask) - interpol )
# print "average |terrain() - interpolated|: %.2g" % np.mean(err)

# print "interpolate a single point: %.2g" % \

# nx=np.array([[0.5,1.0,1.5],[0.5,1.0,1.5],[0.5,1.0,1.5]])
# ny=np.array([[0.3,0.3,0.3],[0.9,0.9,0.9],[1.4,1.4,1.4]])
# print nx.shape

# NX,NY=np.meshgrid(nx,ny)

# NX[-1,0]=0
# NY[-1,0]=2
# nz=f(nx,ny)
# 

#     invdisttree( known[0], nnear=Nnear, eps=eps )
# 
# print z
# rz=np.reshape(z,(-1))
# print rz
# print nz
#

print nz.shape
fig=pl.figure()
ax=fig.gca(projection='3d')
surf=ax.plot_wireframe(X,Y,z.reshape(d,d),cmap=cm.coolwarm,linewidth=2,antialiased=False)

# fig=pl.figure()
# ax=fig.gca(projection='3d')
surf=ax.plot_surface(np.reshape(nx,(d,d)),np.reshape(ny,(d,d)),np.reshape(nz,(d,d)),cmap=cm.rainbow,linewidth=1,antialiased=False)
pl.show()

