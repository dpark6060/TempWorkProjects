#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import seaborn as sb
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb


SubDir='/share/studies/Connectome/Subjects'
Subjects=glob.glob(os.path.join(SubDir,'*','tfMRI_WM_*','MotionCorrection','tfMRI_WM_[LR][LR]_mc.par'))

df=np.array([])
#,dtype={'names':('xRotation','yRotation','zRotation','xTranslation','yTranslation','zTranslation'),'formats':('f4','f4','f4','f4','f4','f4')}

f,ax=pl.subplots(2,3)

arrays=[np.mean(np.loadtxt(sub),axis=0) for sub in Subjects]
SubId=[sub.split('/')[5] for sub in Subjects]
b=np.vstack(arrays)
DF=pd.DataFrame(b,index=np.arange(b.shape[0]),columns=['xRotation_rads','yRotation_rads','zRotation_rads','xTranslation_mm','yTranslation_mm','zTranslation_mm'])
DF['SubID']=pd.Series(SubId,index=DF.index)
columns=['xRotation(rads)','yRotation(rads)','zRotation(rads)','xTranslation(mm)','yTranslation(mm)','zTranslation(mm)']
x=DF.index

# for i in columns:
#     
#     # pyc='y=DF.{}'.format(i)
#     # exec(pyc)
#     
#     sb.lmplot(x="SubID",y=i,data=DF,fit_reg=False,scatter=True)
#     pl.figure()
#     
#     # grid=sb.JointGrid(x,y,space=0,size=1)
#     # grid.plot_joint(pl.scatter,color='g')
#     # grid.ax_joint.set_xticks(DF.index)
#     # grid.ax_joint.set_xticklabels(DF['SubID'])

sb.distplot(DF.xRotation_rads,ax=ax[0,0])
sb.distplot(DF.yRotation_rads,ax=ax[0,1])
sb.distplot(DF.zRotation_rads,ax=ax[0,2])
sb.distplot(DF.xTranslation_mm,ax=ax[1,0])
sb.distplot(DF.yTranslation_mm,ax=ax[1,1])
sb.distplot(DF.zTranslation_mm,ax=ax[1,2])
pl.setp(ax,yticks=[])
pl.tight_layout()
pl.show()