#!/bin/env python

from __future__ import division
import numpy as np
import matplotlib.pyplot as pl
import pywt


def SoftThresh(y,t):
    xh=[]
    for i in y:
        if i>t:
            xh.append(i-t)
        elif i<-t:
            xh.append(i+t)
        else:
            xh.append(0)
    return(np.array(xh))

def cs_recon(Y,lamb,niter):
    Xi=Y
    for ii in range(niter):
        xi = np.fft.ifft( Xi );  
        xi_st = SoftThresh(xi.real, lamb);  # Enforce sparsity
        Xi = np.fft.fft(xi_st); 
        Xi = Xi * (Y==0) + Y;  # Enforce data consistency
    return(xi_st)


# start with sparse signal decoding

phase_transition=np.zeros((32,32))
for n in range(8):
    for rr,rho in enumerate(np.arange(60,127,4)):
        for dd,delta in enumerate(np.arange(60,127,4)):
            k=np.floor(rho*delta/128).astype(int)
            #print k
            x_orig=np.append(np.sign(np.random.randn(k)) , np.zeros( (1,128-k) ))
            x_orig = x_orig[ np.random.permutation(128) - 1 ]
            X_orig = np.fft.fft(x_orig)
            
            Yr = np.zeros(128, dtype='complex');
            prm = np.random.permutation(128) - 1
            Yr[ prm[:dd] ] = X_orig[ prm[:dd] ];
            x_rec=cs_recon(Yr,0.05,30)
            phase_transition[rr, dd] += np.linalg.norm( x_rec - x_orig ) / (np.linalg.norm( x_orig ) + 1e-5)
            pl.stem(x_rec)
            pl.figure()
            pl.stem(x_orig)
            pl.show()
            
            
            
pl.figure(figsize=(6, 6))
pl.imshow(phase_transition[1:-1,1:-1]/8, origin='lower',  extent = (0.03125, 1-0.03125, 0.03125, 1-0.03125), vmax = 1)
pl.colorbar()
pl.title( 'Phase Transition' )
pl.xlabel('Measurements (n) / Signal length (N)')
pl.ylabel('Sparsity (k) / Measurements (n)');



x = np.array(  [0.2, 0.5, 0.6, 0.8, 1] + [0] * (128-5) )
x = x[ np.random.permutation(128) - 1 ]
#pl.stem(x)
#pl.figure()
#pl.show()

# y = x + 0.05 * np.random.randn(128)
# 
# pl.figure()
# pl.stem(y)
# pl.title('y')
# 
# # 
# # xh=SoftThresh(y,0.1)
# # pl.figure()
# # pl.stem(xh)
# 
# 
# X=np.fft.fft(x)
# pl.figure()
# pl.plot(np.abs(np.fft.fftshift(X)))
# pl.title('fft of raw signal X')
# 
# Xu = np.zeros(128, dtype='complex');
# Xu[::4] = X[::4]
# xu = np.fft.ifft(Xu) * 4
# pl.figure()
# pl.stem(np.real(xu))
# 
# 
# 
# Xr = np.zeros(128, dtype='complex');
# prm = np.random.permutation(128) - 1
# Xr[ prm[:32] ] = X[ prm[:32] ];
# xr = np.fft.ifft(Xr) * 4
# 
# 
# 
# pl.figure()
# pl.stem(np.real(xr))
# pl.title('time domain of random sampled FFT')
# 
# 
# Y=Xr
# Xi=Xr
# lamb=0.01
# for ii in range(100):
#     xi = np.fft.ifft( Xi );  
#     xi_st = SoftThresh(xi.real, lamb);  # Enforce sparsity
#     Xi = np.fft.fft(xi_st); 
#     Xi = Xi * (Y==0) + Y;  # Enforce data consistency
#     
# pl.figure()
# pl.stem(xi_st)
# pl.title('100 Iterations lamda={}'.format(lamb))
# pl.show()
# 




pl.show()





















