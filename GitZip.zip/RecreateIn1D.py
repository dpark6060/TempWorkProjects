#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import seaborn as sb
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb




def create_Signal_1():
    Fs=20.0
    Ts=1.0/Fs
    
    T=100
    
    Signal=np.zeros(int(np.round(T*Fs)*10))
    
    Onsets=[0,5,8,15,20,40,55,70,80,95]
    Values=[0,0,1,1,4,2,2,5,5,0]
    
    start=0
    
    currentVal=0
    currentInd=start
    for o,v in zip(Onsets,Values):
        ind=int(np.round(o*Fs)+start)
        Signal[currentInd:ind]=np.linspace(currentVal,v,ind-currentInd)
        currentInd=ind
        currentVal=v
    return(Signal,Fs,start,int(np.round(T*Fs)))



def messwithsignal():
    s,fs,start,l=create_Signal_1()
    ffs=np.fft.fftshift(np.fft.fft(s))
    
    dsffs=np.zeros(len(ffs),complex)
    
    skip=10
    
    dsffs[::skip]=ffs[::skip]
    origlen=100*20
    curlen=len(ffs)
    pad=int(np.round((curlen-origlen)/2))
    start=pad

    sample=np.arange(36,curlen,skip)
    small_sdffs=np.zeros(len(sample),complex)
    small_sdffs=ffs[sample]
    pl.plot(np.abs(np.fft.ifft(small_sdffs)))
    print 'len orig: {}'.format(len(small_sdffs))
    pl.title('ClippedFft')
    
    pl.figure()    
    pl.plot(np.abs(np.fft.ifft(dsffs)))
    
    
    NewFFT,I=ResampFft_2(ffs,4)
    pl.figure()
    pl.plot(np.abs(np.fft.ifftshift(np.fft.ifft(NewFFT))))
    pl.title('ireg samp')
    
    iregdsfft=np.zeros(len(I),complex)
    iregdsfft=ffs[I]
    pl.figure()
    pl.plot(np.abs(np.fft.ifft(iregdsfft)))
    pl.title('ClippedIregFFT')
  
  
  
  
  
    Xm=np.arange(len(I))

    
    MyKx=np.fft.fftshift(np.fft.fftfreq(len(ffs)))[I]
    #MyKx=np.fft.fftshift(np.fft.fftfreq(Nsamp))
    #np.fft.fftshift(np.fft.fftfreq(Nsamp))
    # MyKx=np.fft.fftshift(np.fft.fftfreq(Lhf))[inds]

    mn=MyIfft2(MyKx,Xm,iregdsfft)
    mn=(mn/skip)
    pl.figure(figsize=(4,3))
    pl.plot(mn,label='Reconstructed')
    pl.title('Sample Corrected Reconstruction')  

    pl.show()


def ResampFft_2(Fft,N):
    
    #scheme='Sin'
    #scheme='Linear'
    #scheme='Quad'
    scheme='Linear'
    
    if scheme=='Reg':
        nSkip=(len(Fft)-N*10)/2
        
        inds=np.arange(nSkip,nSkip+N*10,10)
        # for n in range(N)[1:]:
        #     inds.append(inds[n-1]+nSkip)
        # inds=np.array(np.round(inds)).astype(int)
        # 
        # pl.figure(figsize=(7.5,2))
        # pl.plot(np.log(np.abs(Fft)),'r')
        # pl.stem(inds,np.ones(len(inds))*5)
        # pl.xlim((9470,10500))
        # pl.show()
        # 
        
        NewFft=np.zeros(len(Fft),complex)
        NewFft[inds]=Fft[inds]
        return(NewFft,inds)
        
        
        # nSkip=len(Fft)/N
        # inds=[0]
        # for n in range(N)[1:]:
        #     inds.append(inds[n-1]+nSkip)
        # inds=np.array(np.round(inds)).astype(int)
        # 
        # pl.figure(figsize=(7.5,3))
        # pl.plot(np.log(np.abs(Fft)),'r')
        # pl.stem(inds,np.ones(len(inds))*5)
        # pl.show()
        # 
        # 
        # NewFft=np.zeros(len(Fft),complex)
        # NewFft[inds]=Fft[inds]
        # return(NewFft,inds)
    
    if scheme=='Linear':
        # Nskip=len(Fft)/N
        # print Nskip
        # Nlow=Nskip*0.85
        # Nhigh=Nskip*1.15
        # skip=np.round(np.linspace(Nlow,Nhigh,N-1)).astype(int)
        # inds=[0]
        # for s in skip:
        #     inds.append(inds[-1]+s)
        # 
        # print inds
        # print len(inds)
        # print N
        # 
        # pl.plot(np.abs(Fft))
        # pl.stem(inds,np.ones(len(inds))*10)
        # pl.show()
        # 
        # NewFft=np.zeros(len(Fft),complex)
        # NewFft[inds]=Fft[inds]
        # # pl.plot(np.abs(NewFft))
        # # pl.show()
        
        Nskip=10
        # L=Nskip*0.85
        # M=
        # a=(2*(M-L))/(N-1)
        # n=np.arange(N)
        # inds=[a*i**2 +L*i for i in n]
        
        
        
        s=Nskip*0.7
        inds=[0]
        a=0.06
        #a=0.1
        lfft=len(Fft)
        n=1
        while inds[-1]+s+a*n<lfft:
            inds.append(inds[n-1]+s+a*n)
            n=n+1
        start=0
        print n
        inds=np.array(np.round(inds)+start).astype(int)
        print np.diff(inds)
        print 'len inds: {}'.format(len(inds))
        print N
        
        # pl.figure(figsize=(7.5,2))
        # pl.plot(np.log(np.abs(Fft)),'r')
        # pl.stem(inds,np.ones(len(inds))*5)
        # # pl.xlim((9470,10525))
        # # pl.ylim((-2,9))
        # pl.show()
        
        NewFft=np.zeros(len(Fft),complex)
        NewFft[inds]=Fft[inds]
        # pl.plot(np.abs(NewFft))
        # pl.show()
        
        #nSkip=(len(Fft)-N*10)/2
        
        #inds=np.arange(nSkip,nSkip+N*10,10)
        
        return(NewFft,inds)
    
    
    if scheme=='Sin':
        Nskip=len(Fft)/N
        print Nskip
        shift=0#-np.pi/2
        t=np.linspace(shift+np.pi,shift+np.pi*2,N)
        csin=np.cos(t)
        csin*=0.15
        skip=np.round((1+csin)*Nskip).astype(int)
        pl.plot(csin)
        pl.show()
        
        
       
        inds=[0]
        for s in skip[1:]:
            inds.append(inds[-1]+s)
        
        print inds
        print len(inds)
        print N
        
        pl.plot(np.abs(Fft))
        pl.stem(inds,np.ones(len(inds))*50)
        pl.show()
        
        NewFft=np.zeros(len(Fft),complex)
        NewFft[inds]=Fft[inds]
        # pl.plot(np.abs(NewFft))
        # pl.show()
        return(NewFft,inds)
    
    
    if scheme=='Quad':
        Nskip=len(Fft)/N
        print Nskip
        shift=0
        t=np.linspace(shift,2,len(Fft))
        
        M=1000
        a=np.sqrt(M*1.0-1.0)/(N*1.0)
        
        I=[]
        for i in range(N):
           I.append(np.power(a*i,2))
        print I
        print M
        start=(len(Fft)-N*10)/2
        I=np.array(np.round(I)+start).astype(int)
        
        
        
        pl.figure(figsize=(7.5,2))
        pl.plot(np.log(np.abs(Fft)),'r')
        
        pl.stem(I,np.ones(len(I))*5)
        pl.xlim((9470,10525))
        pl.ylim((-2,9))
        pl.show()
        
        NewFft=np.zeros(len(Fft),complex)
        NewFft[I]=Fft[I]
        # pl.plot(np.abs(NewFft))
        # pl.show()
        
        return(NewFft,I)

def ResampFft_1(Fft,N):
    
    #scheme='Sin'
    #scheme='Linear'
    #scheme='Quad'
    scheme='Linear'
    #scheme='Reg'
    if scheme=='Reg':
        nSkip=(len(Fft)-N*10)/2
        
        inds=np.arange(nSkip,nSkip+N*10,10)
        # for n in range(N)[1:]:
        #     inds.append(inds[n-1]+nSkip)
        # inds=np.array(np.round(inds)).astype(int)
        
        pl.figure(figsize=(7.5,2))
        pl.plot(np.log(np.abs(Fft)),'r')
        pl.stem(inds,np.ones(len(inds))*5)
        pl.xlim((9470,10500))
        pl.show()
        
        
        NewFft=np.zeros(len(Fft),complex)
        NewFft[inds]=Fft[inds]
        return(NewFft,inds)
        
        
        # nSkip=len(Fft)/N
        # inds=[0]
        # for n in range(N)[1:]:
        #     inds.append(inds[n-1]+nSkip)
        # inds=np.array(np.round(inds)).astype(int)
        # 
        # pl.figure(figsize=(7.5,3))
        # pl.plot(np.log(np.abs(Fft)),'r')
        # pl.stem(inds,np.ones(len(inds))*5)
        # pl.show()
        # 
        # 
        # NewFft=np.zeros(len(Fft),complex)
        # NewFft[inds]=Fft[inds]
        # return(NewFft,inds)
    
    if scheme=='Linear':
        # Nskip=len(Fft)/N
        # print Nskip
        # Nlow=Nskip*0.85
        # Nhigh=Nskip*1.15
        # skip=np.round(np.linspace(Nlow,Nhigh,N-1)).astype(int)
        # inds=[0]
        # for s in skip:
        #     inds.append(inds[-1]+s)
        # 
        # print inds
        # print len(inds)
        # print N
        # 
        # pl.plot(np.abs(Fft))
        # pl.stem(inds,np.ones(len(inds))*10)
        # pl.show()
        # 
        # NewFft=np.zeros(len(Fft),complex)
        # NewFft[inds]=Fft[inds]
        # # pl.plot(np.abs(NewFft))
        # # pl.show()
        Nskip=7
        #Nskip=(len(Fft)-N*10)/2
        # L=Nskip*0.85
        # M=
        # a=(2*(M-L))/(N-1)
        # n=np.arange(N)
        # inds=[a*i**2 +L*i for i in n]
        
        
        
        s=Nskip
        inds=[0]
        a=0.061
        
        # lfft=len(Fft)
        # n=1
        # while inds[-1]+s+a*n<lfft:
        #     inds.append(inds[n-1]+s+a*n)
        #     n=n+1
        # 
        
        
        for n in range(N)[1:]:
            inds.append(inds[n-1]+s+a*n)
        start=(len(Fft)-N*10)/2
        #start=0
        inds=np.array(np.round(inds)+start).astype(int)
        print np.diff(inds)
        print len(inds)
        print N
        
        pl.figure(figsize=(7.5,2))
        pl.plot(np.log(np.abs(Fft)),'r')
        pl.stem(inds,np.ones(len(inds))*5)
        pl.xlim((9470,10525))
        pl.ylim((-2,9))
        pl.show()
        
        NewFft=np.zeros(len(Fft),complex)
        NewFft[inds]=Fft[inds]
        # pl.plot(np.abs(NewFft))
        # pl.show()
        
        #nSkip=(len(Fft)-N*10)/2
        
        #inds=np.arange(nSkip,nSkip+N*10,10)
        
        return(NewFft,inds)
    
    
    if scheme=='Sin':
        Nskip=len(Fft)/N
        print Nskip
        shift=0#-np.pi/2
        t=np.linspace(shift+np.pi,shift+np.pi*2,N)
        csin=np.cos(t)
        csin*=0.15
        skip=np.round((1+csin)*Nskip).astype(int)
        pl.plot(csin)
        pl.show()
        
        
       
        inds=[0]
        for s in skip[1:]:
            inds.append(inds[-1]+s)
        
        print inds
        print len(inds)
        print N
        
        pl.plot(np.abs(Fft))
        pl.stem(inds,np.ones(len(inds))*50)
        pl.show()
        
        NewFft=np.zeros(len(Fft),complex)
        NewFft[inds]=Fft[inds]
        # pl.plot(np.abs(NewFft))
        # pl.show()
        return(NewFft,inds)
    
    
    if scheme=='Quad':
        Nskip=len(Fft)/N
        print Nskip
        shift=0
        t=np.linspace(shift,2,len(Fft))
        
        M=1000
        a=np.sqrt(M*1.0-1.0)/(N*1.0)
        
        I=[]
        for i in range(N):
           I.append(np.power(a*i,2))
        print I
        print M
        start=(len(Fft)-N*10)/2
        I=np.array(np.round(I)+start).astype(int)
        
        
        
        pl.figure(figsize=(7.5,2))
        pl.plot(np.log(np.abs(Fft)),'r')
        
        pl.stem(I,np.ones(len(I))*5)
        pl.xlim((9470,10525))
        pl.ylim((-2,9))
        pl.show()
        
        NewFft=np.zeros(len(Fft),complex)
        NewFft[I]=Fft[I]
        # pl.plot(np.abs(NewFft))
        # pl.show()
        
        return(NewFft,I)

def MyIfft2(Kx,Xm,weights):
    # This takes a matrix as an input
    
    
    # Xm=Xm/mx
    # Ym=Ym/my
    mn=np.zeros(Xm.shape,complex)
    for kx,w in zip(Kx,weights):
        #print kx
        #mn+=[w*np.exp(1j*2*np.pi*(x*kx+y*ky)) for w,x,y in zip(weights,Xm,Ym)]
        mn+=w*np.exp(1j*2*np.pi*(Xm*(kx)))
    mn=mn/len(weights)
    return(mn)
    
def MyIfft3(Kx,Xm,weights):
    # This takes a matrix as an input
    
    
    # Xm=Xm/mx
    # Ym=Ym/my
    mn=np.zeros(Xm.shape,complex)
    for kx,w in zip(Kx,weights):
        #print kx
        #mn+=[w*np.exp(1j*2*np.pi*(x*kx+y*ky)) for w,x,y in zip(weights,Xm,Ym)]
        mn+=w*np.exp(1j*2*np.pi*(Xm*(kx)))
    mn=mn/len(weights)
    return(mn)





def test1dstuff(sig):
    SigFFT=np.fft.fftshift(np.fft.fft(sig))
    zerpadFFT=np.zeros(len(SigFFT),complex)
    skip=40
    zerpadFFT[::skip]=SigFFT[::skip]
    zpfImg=np.fft.ifftshift(np.fft.ifft(zerpadFFT))
    pl.plot(np.abs(zpfImg))
    pl.title('zpfImg')
    pl.figure()
    pl.plot(np.abs(zerpadFFT))
    pl.title('zeropadFFT')
    pl.figure()
    pl.plot(sig)
    pl.title('sig')
    sigds=sig[::skip]
    pl.figure()
    pl.plot(sigds)
    pl.plot(np.abs(zpfImg[:int(np.floor(len(sig)/skip))]))
    pl.title('sigds')
    NewFFT,inds=ResampFft_2(SigFFT,0)
    pl.figure()
    pl.plot(np.abs(np.fft.ifftshift(np.fft.ifft(NewFFT))))
    pl.title('MisSampledFFT')
    
    pl.figure()
    dsFFT=SigFFT[inds]
    dsfsig=np.fft.ifft(dsFFT)
    pl.plot(np.abs(dsfsig))
    pl.title('dsFFT')
    Lhf=len(sig)
    Xm=np.arange(len(dsfsig))
    MyKx=np.fft.fftshift(np.fft.fftfreq(Lhf))[inds]*20
    print "myKX"
    print MyKx
    
    #mn=MyIfft2(np.fft.fftshift(MyKx),Xm,dsFft)
    mn=MyIfft2(MyKx,Xm,dsFFT)
    mn=(mn/skip)
    pl.figure(figsize=(4,3))
    pl.plot(np.abs(dsfsig),label='Original')
    pl.plot(np.abs(mn),label='Reconstructed')

    pl.legend()

    
    pl.show()
    
    
    
    
    
    
    
    
#     
# messwithsignal()
# sys.exit()
#     
    
    
Sig,fs,start,l=create_Signal_1()
# pl.plot(Sig)
# pl.show()
# test1dstuff(Sig)
# 
# sys.exit()




HFfft=np.fft.fftshift(np.fft.fft(Sig))

PlotSig=Sig[start:start+l]
pl.figure(figsize=(4,3))
pl.plot(np.log(np.abs(HFfft)))
pl.title('Original log(FFT)')

Lhf=len(Sig)
Fslow=1.0
Skip=int(np.round(fs/Fslow))
dsSig=PlotSig[::Skip]
Nsamp=len(dsSig)
# pl.plot(dsSig)
# pl.show()

UpSamp=fs/Fslow

Fft=np.fft.fftshift(np.fft.fft(dsSig,Lhf))
NewFft,inds=ResampFft_1(HFfft,Nsamp)
print inds
#inds=np.where(NewFft!=0)
dsFft=np.zeros(len(inds),complex)
dsFft=NewFft[inds]
NewdsSig=np.fft.ifft(np.fft.fftshift(dsFft))
pl.figure(figsize=(4,3))
pl.plot(dsSig,label='Original')
pl.plot(np.abs(NewdsSig)/20,label='Reconstructed')
pl.title('Conventional IFFT of sampled points')
pl.legend()
pl.figure()

pl.plot(np.abs(NewFft))
pl.figure()
# pl.plot()
# pl.show()



NewSig=np.fft.fftshift(np.fft.ifft(np.fft.fftshift(NewFft)))
#pl.plot(np.abs(NewSig[0:Nsamp]))
pl.plot(np.abs(NewSig))

pl.title('iFft of HF fft')
pl.figure(figsize=(4,3))
pl.plot(dsSig)
pl.title('Original signal')
pl.plot()
# pl.show()

xFreq=np.fft.fftfreq(Lhf)
scalex=(np.amax(xFreq)-np.amin(xFreq))/2.0
SliceKx=np.fft.fftshift(xFreq)[inds]
#SliceKx=SliceKx/scalex*Nsamp
Xm=np.arange(len(dsSig))
print Xm
#MyKx=SliceKx/scalex*OS/(np.pi*4)
MyKx=SliceKx

MyInds=(inds-inds[0])
reg=np.arange(0,Nsamp)*10
print "fftfreq at lowf"
print np.fft.fftshift(np.fft.fftfreq(Nsamp))
print "myinds"
print MyInds
print 'RegSamp'
print np.arange(0,Nsamp)*10
print "Resampled hif fftfreq"
#print np.fft.fftshift(np.fft.fftfreq(Nsamp*10))[MyInds]
MyKx=np.fft.fftshift(np.fft.fftfreq(Lhf))[inds]*20
#MyKx=np.fft.fftshift(np.fft.fftfreq(Nsamp))
#np.fft.fftshift(np.fft.fftfreq(Nsamp))
# MyKx=np.fft.fftshift(np.fft.fftfreq(Lhf))[inds]
# refkx=np.fft.fftshift(np.fft.fftfreq(Lhf))[reg]
# span=np.amax(refkx)-np.amin(refkx)
# MyKx=MyKx/span
print "myKX"
print MyKx

#mn=MyIfft2(np.fft.fftshift(MyKx),Xm,dsFft)
mn=MyIfft2(MyKx,Xm,dsFft)
mn=(mn/Skip)
pl.figure(figsize=(4,3))
pl.plot(dsSig,label='Original')
pl.plot(mn,label='Reconstructed')
pl.title('Sample Corrected Reconstruction')
pl.show()


















