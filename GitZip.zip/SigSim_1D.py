#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import scipy.stats as sts
import subprocess as sp
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import scipy.interpolate as ipt
import Invdisttree as ivd

global OutputFile
OutputFile='/home/dparker/Desktop/MyPossumOutput.txt'
if os.path.exists(OutputFile):
    os.remove(OutputFile)

global FileHandle
FileHandle=open(OutputFile,'w')

def coeff(xold, xnew, told, tnew):
  #return slope and intercept of a line
  #//cout<<"xold="<<xold<<" xnew="<<xnew<<" told="<<told<<" tnew="<<tnew<<" a="<<a<<" b="<<b<<endl;
    if ((tnew-told)>1e-12):
        a=xold-told*(xnew-xold)/(tnew-told)#;	//intercept
        b=(xnew-xold)/(tnew-told)#;			//slope
        return a,b
  #//cout<<"xold="<<xold<<" xnew="<<xnew<<" told="<<told<<" tnew="<<tnew<<" a="<<a<<" b="<<b<<endl;
    return 0,0



def i1(gold,gnew,told,tnew):
    #// integral: i1 = \int G(t) dt

    g1,g2=coeff(gold,gnew,told,tnew)#            // g1 = Intercept, g2 = Slope
    #i11=tnew*(g1+g2*tnew/2)-told*(g1+g2*told/2)
    
    FileHandle.write("Gradient is g1+g2*(tnew-told): g1={} g2={} tnew-told={}\n".format(g1,g2,tnew-told));
    
    i11=(tnew-told)*g1+(tnew-told)*(tnew+told)*g2/2#;  // s*T/m+s^2*T/m
    FileHandle.write("i11={}\n".format(i11))
    return i11


def i2(gold,gnew,aold,anew,told,tnew):
    #// integral: i2 = \int sin(\alpha(t)) G(t) dt
    g1,g2=coeff(gold,gnew,told,tnew)
    a1,a2=coeff(aold,anew,told,tnew);
    FileHandle.write("g1={} g2={}\n".format(g1,g2))
    FileHandle.write("Angle is a1+a2*(tnew-told): a1={} a2={} tnew-told={}\n".format(a1,a2,tnew-told));
    FileHandle.write("aold= {} anew= {}\n".format(aold,anew))
    
    if (np.abs(a2)*(tnew-told)<0.01):
        FileHandle.write("fabs(a2)*(tnew-told)={}< 0.01".format(np.abs(a2)*(tnew-told)))
        i22=(2*g1*np.cos(a2*(tnew-told)/4)*np.sin(a1+a2*(told+tnew)/2)+g2*tnew*np.sin(a1+a2*(3*tnew+told)/4)+g2*told*np.sin(a1+a2*(tnew+3*told)/4))*(np.sinc(a2*(tnew-told)/(4*np.pi))*(tnew-told)/2)
        #//teylor done for np.sin(o(1e-04)) error expected to be less than 0.0016%
    else:
        FileHandle.write("fabs(a2)*(tnew-told)={} > 0.01".format(np.abs(a2)*(tnew-told)))
        i22=g1*2*(np.sin(a2*(tnew-told)/2)/a2)*np.sin(a1+a2*(tnew+told)/2)+g2*(np.sin(a1)*(tnew*np.sin(a2*tnew)/a2-told*np.sin(a2*told)/a2-2*(np.sin(a2*(tnew-told)/2)/a2)*(np.sin(a2*(tnew+told)/2)/a2))+np.cos(a1)*(-tnew*np.cos(a2*tnew)/a2+told*np.cos(a2*told)/a2+2*(np.sin(a2*(tnew-told)/2)/a2)*(np.cos(a2*(tnew+told)/2)/a2)))
    FileHandle.write("i22={}\n".format(i22))
    return i22;


def i3(gold,gnew,aold,anew,told,tnew):
    # integral: i3 = \int np.cos(\alpha(t)) G(t) dt
    g1,g2=coeff(gold,gnew,told,tnew)
    a1,a2=coeff(aold,anew,told,tnew)
    FileHandle.write("g1={} g2={}\n".format(g1,g2))
    FileHandle.write("Angle is a1+a2*(tnew-told): a1={} a2={} tnew-told={}\n".format(a1,a2,tnew-told));
    FileHandle.write("aold= {} anew= {}\n".format(aold,anew))
    
    if (np.abs(a2)*(tnew-told)<0.01):
        i33=(2*g1*np.cos(a2*(tnew-told)/4)*np.cos(a1+a2*(told+tnew)/2)+g2*tnew*np.cos(a1+a2*(3*tnew+told)/4)+g2*told*np.cos(a1+a2*(tnew+3*told)/4))*(np.sinc(a2*(tnew-told)/(4*np.pi))*(tnew-told)/2);#teylor done for np.sin(o(1e-04))
    #i33=np.cos(a1)*i1(gold,gnew,told,tnew);
    
    else:
        i33=g1*2*(np.sin(a2*(tnew-told)/2)/a2)*np.cos(a1+a2*(tnew+told)/2)+g2*(np.sin(a1)*(tnew*np.cos(a2*tnew)/a2-told*np.cos(a2*told)/a2-2*(np.sin(a2*(tnew-told)/2)/a2)*(np.cos(a2*(tnew+told)/2)/a2))+np.cos(a1)*(tnew*np.sin(a2*tnew)/a2-told*np.sin(a2*told)/a2-2*(np.sin(a2*(tnew-told)/2)/a2)*(np.sin(a2*(tnew+told)/2)/a2)));
    #i33=((g1+g2*tnew)*np.sin(a1+a2*tnew)-(g1+g2*told)*np.sin(a1+a2*told)+(g2*np.cos(a1+a2*tnew)-g2*np.cos(a1+a2*told))/a2)/a2;
    FileHandle.write("i33={}\n\n".format(i33))
    return i33;

def i4(gold, gnew, trold, trnew,  told, tnew):
# integral: i4 = \int T(t) G(t) dt    : T(t) is translation
    g1,g2=coeff(gold,gnew,told,tnew);
    tr1,tr2=coeff(trold,trnew,told,tnew);
    e=tnew-told;
    a=g1*tr1;
    b=(g1*tr2+g2*tr1)/2;
    c=g2*tr2/3;
    i44=e*(a+e*(b+e*c))+told*e*(2*b+3*c*(e+told));
    return i44;



def I(h,r1,r2,g):
    M=rotmat(r2)
    A=axismat(r1)
    AM=A*M
    A2M=A*AM
    v=g[0,:]*M[:,h]+g[1,:]*AM[:,h]+g[2,:]*A2M[:,h]
    return v[0,0]
    
def axismat(angleaxis):
#returns A where R = I + sin(angle) A + (1 - cos(angle)) A^2
    axis=np.zeros(3)
    axis=angleaxis[1:]
    norm_axis=np.sqrt(np.sum(np.square(axis)))
    if (np.abs(norm_axis-1)>1e-12):
        if (np.abs(norm_axis)>1e-12):
            axis[0]=axis[0]/norm_axis
            axis[1]=axis[1]/norm_axis
            axis[2]=axis[2]/norm_axis
    

    m=np.matrix([[0,-axis[2],axis[1]],
                 [axis[2],0,-axis[0]],
                 [-axis[1],axis[0],0]])
    

    return m

#/////////////////////////////////////////////////////////////////////////////////////////////
def rotmat(angleaxis):
#returns R where R = I + sin(angle) A + (1 - cos(angle) A^2
    d=np.matrix(np.eye(3))
    A=axismat(angleaxis);
    angle=angleaxis[0];
    #A=A.A
    m=d+np.sin(angle)*A+(1-np.cos(angle))*(A*A);
    return m;



def TrueRotation(RotAxis):
    th=RotAxis[0]
    ux=RotAxis[1]
    uy=RotAxis[2]
    uz=RotAxis[3]
    u=np.array([[0,-uz,uy],[uz,0,-ux],[-uy,ux,0]])
    print u
    uu=np.array([[ux**2,ux*uy,ux*uz],[ux*uy,uy**2,uy*uz],[ux*uz,uy*uz,uz**2]])
    
    UU=u*u.T
    
    print uu
    print UU
    
   # Rtrue=[[np.cos(th)+ux**2*(1-np.cos)]]
    
    R=np.cos(th)*np.eye(3)+np.sin(th)*u+(1-np.cos(th))*uu
    #print R
    return(R)


class Vector:
    
    def __getitem__(self,n):
        return(self.v[n])
    
    
    
    def __init__(self,v=np.zeros(3)):
        self.v=v
        
    def translate(self,T,v=np.zeros(3)):
        tv=v+T
        return(tv)
        
    def rotate(self,theta,a):
        R=self.MakeRotMat_New(theta,a)
        rv=np.dot(self.v,R)
        return(rv)
    
    def xfm(self,trans,theta,a):
        self.v=self.translate(trans,self.v)
        rtv=self.rotate(theta,a)
        return(rtv)

    def set_v(self,newv):
        self.v=newv
        
    def get_v(self):
        return self.v
    
    def get_mag(self):
        return np.sqrt(np.sum(np.square(self.v)))
    
    def get_angle(self,axis):
        # Returns the angle of the vector relative to an axis
        if axis==0:
            angle=np.arcsin(self.v[0]/self.get_mag())
        if axis==1:
            angle=np.arcsin(self.v[1]/self.get_mag())
        if axis==2:
            angle=np.arcsin(self.v[2]/self.get_mag())
        else:
            print('Axis must be 0,1, or 2 for x,y,z')
            angle=0
        return(angle)
    
    
    def MakeRotMat(self,theta,a):  
        Ux=np.array([[0,-a[2],a[1]],[a[2],0,-a[0]],[-a[1],a[0],0]])
        Ut=np.array([a]).T*np.array([a])
        # print Ux
        # print Ut
        # print Ux.shape
        # print Ut.shape
        #R=np.cos(theta*np.pi/180)*np.eye(3)+np.sin(theta*np.pi/180)*Ux+(1-np.cos(theta*np.pi/180))*Ut
        R=np.eye(3)+np.sin(theta*np.pi/180)*Ux+(1-np.cos(theta*np.pi/180))*Ut
        return R

    def MakeRotMat_New(self,theta,a):  
        Ux=np.matrix([[0,-a[2],a[1]],[a[2],0,-a[0]],[-a[1],a[0],0]])
        Ut=np.array([a]).T*np.array([a])
        # print Ux
        # print Ut
        # print Ux.shape
        # print Ut.shape
        R=np.eye(3)+np.sin(theta*np.pi/180)*Ux+(1-np.cos(theta*np.pi/180))*Ux*Ux
        #R=np.eye(3)+np.sin(theta*np.pi/180)*np.array(A)+(1-np.cos(theta*np.pi/180))*np.dot(A,A)
        return R.A



class voxel:
    def __init__(self,M=Vector(),T1=0,T2s=0,Phi=0,s=Vector()):
        self.MM=Vector(M.v)                # This is the Magnitude of the magnetic vector at T=0
        self.MzTheta=self.MM.get_angle(2)   # In Radians     # This is the angle of the voxel's magnetic vector relative to the Z axis (Mag vector is x,y,z convention, like all other vectors)
        self.M0=M                           # This will be the M immediatly after excitation for relaxation calculations
        self.T1=T1                          # The T1 value of this particular voxel
        self.T2s=T2s                        # The T2 value of this particular voxel
        self.Phi=Phi                        # The current XY phase of this particular voxel's Mxy vector
        self.Mxy=np.sqrt(np.square(self.MM.v[0])+np.square(self.MM.v[1]))   # The Magnitude of this voxel's Mxy vector
        self.Mxy0=self.Mxy                  # initial Mxy vector.  Worth storing to avoid calculating all the time.
        self.s=s                            # The location (in meters) of this voxel's center
        self.Mz=self.MM.v[2]

        
    def set_xyz(self,s):
        self.s=s
    def set_T1(self,t1):
        self.T1=T1
    def set_T2s(self,t2):
        self.T2s=t2
    def set_Phi(self,phi):
        self.Phi=phi
    def set_M(self,m):
        self.Mt=m
        self.MzTheta=self.Mt.get_angle(2)
        self.Mxy=np.sqrt(np.square(self.Mt.v[0])+np.square(self.Mt.v[1]))
        
    def get_xyz(self):
        return self.s
    def get_Phi(self):
        return self.Phi


    def recover(self,t):        
        
        self.Mxy=self.Mxy0*np.exp(-t/self.T2s)
        self.Mz=self.M0.v[2]*np.exp(-t/self.T1)+self.MM.v[2]*(1-np.exp(-t/self.T1))
        

        
        #print self.Mxy
        

            
        #print self.MzTheta
        # if self.M0==2:
        #     print't =\t:}\nMxy =\t{}\nMz =\t{}'.format(t,self.Mxy,self.Mz)

    def excite(self,angle):
        self.M0.v=self.MM.rotate(angle,[0,1,0])   # Apply the appropriate rotation in the z axis        
        self.MzTheta=angle                      # Rather than calculate the angle, we will just set it equal to what we just rotated.  This has been tested, it works.
        self.Mxy=np.sqrt(np.square(self.M0.v[0])+np.square(self.M0.v[1])) # Calculate Mxy
        self.Mz=self.M0.v[2]                    # Mz is just the first 
        self.Mxy0=self.Mxy
        if self.MM.v[-1]!=0:
            print self.Mxy0


        # print self.Mxy
        # print self.Mt.v





class Target:
    def __init__(self,tissue=np.zeros((1,1,1))):
        
        self.T1gm=1331e-3
        self.T2gm=51e-3
        self.xDim=2e-3
        self.yDim=2e-3
        self.zDim=4e-3
        self.Lx=tissue.shape[0]
        self.Ly=tissue.shape[1]
        self.Lz=tissue.shape[2]
        self.Cx=np.round(self.Lx/2.0)-1
        self.Cy=np.round(self.Ly/2.0)-1
        self.Cz=np.round(self.Lz/2.0)-1
        self.xfmMat=[[self.xDim,0,0],[0,self.yDim,0],[0,0,self.zDim]]
        self.xfmT=[-1*self.Cx,-1*self.Cy,-1*self.Cz]        
        self.obj=self.MakeVoxels(tissue)

    def cor2mil(self,x,y,z):

        mm=np.dot(self.xfmMat,[x,y,z])+self.xfmT
        return(mm)
    
    def MakeVoxels(self,tissue):
        Object=np.empty(tissue.shape,dtype=object)
        xxx=-1*(self.Lx-1)/2.0 # Starting point for x
        posx=[(xxx+i)*self.xDim for i in range(self.Lx)]
        yyy=-1*(self.Ly-1)/2.0
        posy=[(yyy+i)*self.yDim for i in range(self.Ly)]
        zzz=-1*(self.Lz-1)/2.0
        posz=[(zzz+1)*self.zDim for i in range(self.Lz)]
        for i,v in np.ndenumerate(tissue):
            
            s=Vector((posx[i[0]],posy[i[1]],posz[i[2]]))
            Object[i]=voxel(Vector([0,0,v]),self.T1gm,self.T2gm,0,s)
            if v>0:
                print s.v
                
                
            
        return Object
    
    def excite_Voxels(self,angle):
        m=None
        for i,v in np.ndenumerate(self.obj):
            #print v
            v.excite(angle)
            v.set_Phi(0)
            if v.MM.v[-1]!=0:
                m=v.Mxy
                #print m
        return(m)
    
    def recover_Voxels(self,dt):
        m=None
        for i,v in np.ndenumerate(self.obj):
            v.recover(dt)
            
            if v.MM.v[-1]!=0:
                m=v.Mxy
                #print m
        return(m)
    
    def reset_phase(self):
        for i,v in np.ndenumerate(self.obj):
            v.set_Phi(0)
    
    def get_Voxel(self,xyz):
        return self.obj[xyz]
     
class Pulse:
    def __init__(self,TR=3,gam=46.6e6,angle=90,Te=8e-3):

        self.TR=TR
        self.angle=angle
        self.Te=Te
        self.gammabar=gam
        
    def episequence(self,nVolumes,zc,nSlices,resZ,slcdir,phasedir,readdir,resX,resY,bottom,top,Bwrec,TRslc,rt,maxG,Nx,Ny,xDim,yDim,zDim):
         # Input parameters: n = number of volumes, ns = number of slices (per volume)
        #   ddz = slice thickness (m) , zc = coordinate of slice centre (m)
        #EPISEQUENCE MATRIX INPUTFILE
        #(1)=time in s,(2)=rf angle,(3)=rf frequency bandwidth df(Hz),(4)=rf center frequency fc(Hz),(5)=readout 1/0 (6)=x gradient(T/m),(7)=y gradient(T/m),(8)=z gradient(T/m)
        #TRslc=2.997# for epi
                 #               =  TRline for ge 
        #Set up gradient directions
        if slcdir=='z+':
            sdindex=7
        if phasedir=='y+':
            pdindex=6
        if readdir=='x+':
            rdindex=5
        
        # Assuming z=slice y=phase, x=read, and all are in the positive direction
        simdir=1
        phdir=1
        redir=1
        angle_rad=self.angle*np.pi/180
        gdt=maxG/rt #calculate the delta gradient/sec (T/ms)
        
        # Slice Selection
        Gz=7.128e-3 # Slice selection gradient during rf Excitation (T/m)
        dtz=Gz/gdt # Time required for SS gradient to rise to Gz (s)
        rft=4*1e-3 # Not sure what this is - I think time of the RF pulse...added to dtz so must be (s) - I believe it's the duration of the RF pulse
        
        dtz11=np.sqrt(((rft+dtz)*Gz)/(2*gdt))
        Gz1 = ((rft+dtz)*Gz)/(2*dtz11)
        dtz1=dtz11*2.0
        # fig 26.1 - Gz*(rft+dtz) = area A+B+C+D assuming B=0 and A=D
        # will come back to all this
        # dtz11 is time for 0 to Gz1; dtz1 is the total time for the negative pulse
        TA=rft/2.0+dtz+dtz1 # Time at which all rf stuff is over
        # fir 26.1 - this is t9
        
        df=zDim*self.gammabar*Gz #frequency width - slice thickness(m) times the gradient (T/m) Times self.gammabar (Hz/T) (in m*Hz/T*T/m=Hz), kinda like bandwidth of slice?
        
        fc=np.array(zc)*self.gammabar*Gz # Center frequencies of slices
        
        # Read Out
        dtx=1.0/Bwrec # Sampling time along readout direction
        dkx=1.0/(resX*xDim) # K space incrament is 1/FOV
        dky=1.0/(resY*yDim)
        
        Gx=dkx/(self.gammabar*dtx) # from dtx*self.gammabar*Gx=dkx - gradient strength needed to move dkx hz in dtx seconds given gamma
        dt=Gx/gdt # how long it will take for the gradient to reach Gx
        
        dty=np.sqrt(4.0*dky/(self.gammabar*gdt)) # solving dty using a triangle pulse, dty is the full width of the pulse, solve using the integral and Gy(t)=gdt*t dky=self.gammabar*integral(Gy(t)dt)
        Gy=1.0/2.0*dty*gdt
        
        
        # These are for moving k space to the appropriate location before sampling starts
        dtx1=np.sqrt(Gx*(dt+resX*dtx)*2.0/gdt) # calculating center time if read gradient was a triangle??!?! A=Gx*(Nx*dtx+dt), in triangle: A=1/2*b*h, Gx*(Nx*dtx+dt)=1/2*b*h, h=gdt*b, solve for b - divided by two
        
        Gx1=dtx1*gdt/2.0 # Can't figure out equation for this, but it's half the gradient strength.  so this should move k space to the start of the x row.  Not sure why it's divided by two, though
        # It seems like dtx1 is the time it takes to make it half way across k space at maximum gradient.  maybe it's just because we don't need to go that fast.
        
        dty1=np.sqrt(bottom)*dty # initial dy, moving k space to the start of the y row.
        Gy1=dty1*gdt/2.0
        
        # More things
        TEl=bottom*(2.0*dt+(resX-1.0)*dtx)+(dt+resX/2.0*dtx) #from the self.Te which is the middle of the central k space line, how much time is acquired to the LEFT of the TE
        #Bottom number of lines * time to acquire a line +1/2 time to acquire one line
        TEr=top*(2.0*dt+(resX-1)*dtx)+(dt+(resX/2.0-1)*dtx) #from the TE which is the middle of the central k space line, how much time is acquired to the RIGHT of the TE
        #Top number of lines * time to acquire a line +1/2 time to acquire one line
        
        TD=self.Te-TEl  # Counting back from self.Te, subtract readout time occuring BEFORE self.Te
        TC=TD-dtx1 # Now Subtract the initial kspace x-placement (Frequency encoding)
        TB=TC-dty1 # minus the initial kspace y-placement (Phase encoding)
        TF=self.Te+TEr  # now calculate when the reading will be complete
        tcrush=2.0*rt # how long the crush gradient will be on
        TG=TF+2.0*rt+tcrush # what time the crush gradient will start.
        
        TRslc=self.TR*0.999
        
        # dtz1=float("{0:.9f}".format(dtz1))
        # dtz11=float("{0:.9f}".format(dtz11))
        # dt=float("{0:.10f}".format(dt))
        # Gx=float("{0:.7f}".format(Gx))
        # dtx1=float("{0:.9f}".format(dtx1))
        # Gx1=float("{0:.7f}".format(Gx1))
        # dty=float("{0:.10f}".format(dty))
        # Gy=float("{0:.8f}".format(Gy))
        # dty1=float("{0:.9f}".format(dty1))
        # Gy1=float("{0:.7f}".format(Gy1))
        # 
        # TEl=float("{0:.6f}".format(TEl))
        # TEr=float("{0:.7f}".format(TEr))
        # TD=float("{0:.6f}".format(TD))
        # TC=float("{0:.7f}".format(TC))
        # TB=float("{0:.7f}".format(TB))
        # TA=float("{0:.8f}".format(TA))
        # TF=float("{0:.6f}".format(TF))
        # TG=float("{0:.6f}".format(TG))
        
        
        
        
        print('gdt = tana:\t{}'.format(gdt))
        
        print('resX:\t{}'.format(resX))
        print('resY:\t{}'.format(resY))
        print('zDim:\t{}'.format(zDim))
        print('Bottom:\t{}'.format(bottom))
        print('Top:\t{}'.format(top))
        
        print('')   
        print('maxG:\t{}'.format(maxG))
        print('rt:\t{}'.format(rt))
        print('TRslc:\t{}'.format(TRslc))

        print('')
        print('df:\t{}'.format(df))
        print('rft:\t{}'.format(rft))
        print('dtz:\t{}'.format(dtz))
        print('dtz1:\t{}'.format(dtz1))
        print('dtz11:\t{}'.format(dtz11))
        print('')
        
        print('dt:\t{}'.format(dt))
        print('dtx:\t{}'.format(dtx))
        print('Gx:\t{}'.format(Gx))
        print('dtx1:\t{}'.format(dtx1))
        print('Gx1:\t{}'.format(Gx1))
        print('')

        print('dty:\t{}'.format(dty))
        print('Gy:\t{}'.format(Gy))
        print('dty1:\t{}'.format(dty1))
        print('Gy1:\t{}'.format(Gy1))
        print('')
        print('TE:\t{}'.format(self.Te))
        print('TEl:\t{}'.format(TEl))
        print('TEr:\t{}'.format(TEr))        
        print('TD:\t{}'.format(TD))
        print('TC:\t{}'.format(TC))
        print('TB:\t{}'.format(TB))
        print('TA:\t{}'.format(TA))
        print('TF:\t{}'.format(TF))
        print('TG:\t{}'.format(TG))
        print('TR:\t{}'.format(self.TR))
        print('gammabar:\t{}'.format(self.gammabar))
        

        
        
        
        # cout<<"Times in the acquisition of one slice starting from the RF pulse (in s)"<<endl;
        # cout<<"the slice selection gradient is done TA="<<TA<<endl;
        # cout<<"the phase encode gradient starts dephasing TB="<<TB<<endl;
        # cout<<"the phase encode gradient stops dephasing, and the read-out gradient starts dephasing TC="<<TC<<endl;
        # cout<<"the read-out gradient stops dephasing,begining of the read-out period TD="<<TD<<endl;
        # cout<<"echo time self.Te="<<self.Te<<endl;
        # cout<<"end of the read-out period and begining of the crushers TF="<<TF<<endl;
        # cout<<"end of the crushers TG="<<TG<<endl;
        # cout<<"end of the acquisition of one slice TRslc="<<TRslc<<endl;       
        
        TRF=0
        
        ###############################################
        ##         First loop to calculate size      ##
        ###############################################
        t=0 # start time
        step=1 # Row number in the matrix
        
        for a in range(nVolumes):
            for b in range(nSlices):
            
                #Slice Selection Gradient Rises
                t+=dtz
                step+=1
                #RF pulse turns on, SS gradient remains on, taken to mid line of RF pulse
                t+=rft/2
                step+=1
                TRF=t # Set this as the Time of the RF pulse
                #RF pulse finishes Gradient remains on
                t+=rft/2
                step+=1
                #Gradient turns off
                t+=dtz
                step+=1
                #Gradient goes negative to remove phase accumulation
                t+=dtz1/2
                step+=1
                #Negative gradient returns to zero
                t+=dtz1/2
                step+=1
                # From TRF, when do we start the frequency and phase encoding
                t=TRF+TB
                step+=1
                # Account for Phase Encoding
                t+=dty1/2
                step+=1
                t+=dty1/2
                step+=1
                
                t+=dtx1/2
                step+=1
                t+=dtx1/2
                step+=1
                
              
                # Now simulate sampling k space through frequency and phase
                for c in range(bottom+1+top):
                    # Now raise the initial readout gradient
                    if c==0:
                        # if we're just starting, just apply x gradient
                        t+=dt
                        step+=1
                    else:
                        # Otherwise it's a new slice and we need to incrament y
                        # Turn On or off Y Gradient
                        t+=dty/2
                        step+=1
                        #Turn Off Y Gradient...and something?
                        t+=dt-dty/2
                        step+=1
                    # Now loop through the readout
                    for d in range(resX-1):
                        # Gradient is on already, just start stepping
                        t+=dtx
                        step+=1
                    
                    # If we're at the last slice
                    if c==bottom+top:
                        # Add an x gradient DT
                        t+=dt
                        step+=1
                    else:
                        #Otherwise we have more slices to go, switch the x gradient
                        t+=dt-dty/2
                        step+=1
                        #and turn on Y Gradient
                        t+=dty/2
                        step+=1
                        
                
                # Now apply the Crushers              
                t+=rt
                step+=1
                t+=tcrush
                step+=1
                t+=rt
                step+=1
                
                # Account for previous volumes (a) and the current slice (b)
                t=TRslc*(b+1)+a*self.TR
                step+=1
            
            tt=t
            t=self.TR*(a+1)
            
            if t-tt>1e-6:
                step+=1
            if t-tt<-1e6:
                print ("Warning TR is shorter then Nslc*TRslc")
            
        ###############################################
        ##                  Main Loop                ##
        ###############################################
        
        nreadp=nVolumes*nSlices*resX*resY
        readstep=-1
        
        Pmatrix=np.zeros((step,8))
        #H: (1)=time in s,(2)=rf angle,(3)=rf frequency bandwidth df(Hz),(4)=rf center frequency fc(Hz),(5)=readout 1/0 (6)=x gradient(T/m),(7)=y gradient(T/m),(8)=z gradient(T/m)
        step=0
        t=0.0
        
        # Making matrix to save k space coordinates
        coord=np.zeros((2,nreadp))
        tindex=0
        
        #        if slcdir=='z+':
        #     sdindex=8 = cc
        # if phasedir=='y+':
        #     pdindex=7 = bb
        # if readdir=='x+':
        #     rdindex=6 = aa
        bhelp=0
        RefGrid=[]
        for a in range(nVolumes):
            for b in range(nSlices):
                kx=0
                ky=0
                kz=0
                
                # sdindex=cc
                # 
                
                #Slice Selection Gradient Rises
                t+=dtz;step+=1 # 1      #line1 (In Figure 1)
                Pmatrix[step,0]=t;Pmatrix[step,sdindex]=Gz 
                # Half the pulse time (Time to peak pulse) and set phase angle
                t+=rft/2;step+=1 # 2    # Line2
                Pmatrix[step,0]=t;
                Pmatrix[step,1]=angle_rad;
                Pmatrix[step,2]=df;
                Pmatrix[step,3]=fc[bhelp+simdir*b];
                Pmatrix[step,sdindex]=Gz
                TRF=t
                print ('TRF:\t{}'.format(TRF))
                #Finish the other half of the pulse time
                t=t+rft/2 #  3      # Line3
                step+=1
                Pmatrix[step,0]=t
                Pmatrix[step,sdindex]=Gz
                kz+=Pmatrix[step,sdindex]*rft/2 # Move K space by the GZ*dt
                # Turn Off Gradient
                t+=dtz  # 4     # Line4
                step+=1
                Pmatrix[step,0]=t
                kz=kz+Pmatrix[step,sdindex]*dtz/2
                #Begin Negative Z Gradient
                t+=dtz1/2 # 5       # Line5
                step+=1
                Pmatrix[step,0]=t
                Pmatrix[step,sdindex]=-Gz1
                kz=kz+Pmatrix[step,sdindex]*dtz1/4
                # Turn Off Negative Gradient
                t+=dtz1/2  # 6      # Line 6 - TA
                step+=1
                Pmatrix[step,0]=t
                kz=kz+Pmatrix[step-1,sdindex]*dtz1/4
                
                #  This was for Gradient Echo !!!
                
                # dty1=np.sqrt(np.abs(resY/2-c+1))*dty; #Recalculate ulate dty1 and Gy1 - Honestly I'm not really sure why
                # # New dty1 
                # Gy1=np.sign(resY/2-c+1)*dty1*gdt/2;
                # TB=TC-dty1;
                
                ##### END OF SLICE SELECTION ####
                
                # Move time forward to TB, where kx ky space movement begins
                t=TRF+TB  # 7       # Line 7
                print ("TRF+TB=\t{}".format(t))
                step+=1
                Pmatrix[step,0]=t # TB
                #Begin moving through Ky space
                t+=dty1/2 # 8       # Line 8
                step+=1
                Pmatrix[step,0]=t
                Pmatrix[step,pdindex]=-phdir*Gy1
                ky=ky+Pmatrix[step,pdindex]*dty1/4
                #Turn of Gradient
                t+=dty1/2   # 9         # Line 9
                step+=1 # TC
                Pmatrix[step,0]=t
                ky=ky+Pmatrix[step-1,pdindex]*dty1/4
                # Turn on X Gradient for initial K space setup
                t+=dtx1/2  # 10     # Line 10
                step+=1
                Pmatrix[step,0]=t
                Pmatrix[step,rdindex]=-redir*Gx1
                kx=kx+Pmatrix[step,rdindex]*dtx1/4                  # 1
                # Turn Off X Gradient
                t+=dtx1/2  # 11  # Line 11
                step+=1 # TD
                Pmatrix[step,0]=t
                kx=kx+Pmatrix[step-1,rdindex]*dtx1/4
                print('kx at start of readout:\t{}'.format(kx))
                print "t at start of redout for volume {}: {}".format(a,t)
                
                #### END OF K SPACE INITIALIZATION ####
                ####          BEGIN READOUT        ####
                print bottom+1+top
                for c in range(bottom+1+top):
                    # If it's the first line of the slice
                    if c==0:
                        #Ramp the X Gradient up
                        t+=dt # 12      # Line 12
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,4]=1 # Read on
                        Pmatrix[step,rdindex]=redir*Gx
                        kx=kx+Pmatrix[step,rdindex]*dt/2
                        # Update K space Coordinates
                        readstep+=1
                        coord[0,readstep]=kx*self.gammabar
                        coord[1,readstep]=ky*self.gammabar
                        
                    elif dt-dty/2>=0: # If the y gradient can rise and fall enough in the time between x gradient shifts:
                        # If we've made it here and it's not the first line, we must be switching to a new line, and the y gradient is already on
                        # Ramp down the y gradient while also ramping the x in the current read direction
                        #print('In the elif')
                        t+=dty/2 # 13       # Line 16
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,rdindex]=np.power(-1,c)*dty*gdt/2
                        ky=ky+dty*Pmatrix[step-1,pdindex]/4 #Change ramping down
                        kx=kx+Pmatrix[step,rdindex]*dty/4 # X change while y was ramping down
                        
                        # Y is ramped down, but x still has changing to do
                        t+=dt-dty/2 # 14         #Line 17
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,4]=1 # Turn on read gradient
                        Pmatrix[step,rdindex]=np.power(-1,c)*redir*Gx
                        kx=kx+(Pmatrix[step,rdindex]+Pmatrix[step-1,rdindex])*(dt-dty/2)/2
                        readstep=readstep+1
                        coord[0,readstep]=kx*self.gammabar
                        coord[1,readstep]=ky*self.gammabar
                    else: # If the y gradient will take longer to rise and fall:
                        #print('in the else')
                        t+=dty/2-dt # Begin lowering the y gradient, leave x at 0
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,4]=1
                        Pmatrix[step,pdindex]=Gy-(phdir*(dty/2-dt)*gdt) # Decrease the y gradient as much as posible during dty/2-dt
                        ky+=1/2*(dty/2-dt)*(Gy+Pmatrix[step,pdindex])
                        
                        t+=dt # Step how long till Gx reaches peak
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,rdindex]=np.power(-1,c)*redir*Gx
                        ky+=1/2*dt*Pmatrix[step-1,pdindex]
                        kx+=1/2*dt*Pmatrix[step,rdindex]
                        readstep=readstep+1
                        coord[0,readstep]=kx*self.gammabar
                        coord[1,readstep]=ky*self.gammabar                       
                        
                    #print('kx at start of line {} :\t{}'.format(c,kx)) 
                        
                        
                        #Between lines 12 and 13
                    #print resX-1
                        
                    for d in range(resX-1):
                        # Loop through the read line
                        t+=dtx #  15     
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,4]=1 # Turn on Read Gradient
                        #Pmatrix[step,rdindex]=np.power(-1,c)*redir*Gx # switch direction with each line

                        Pmatrix[step,rdindex]=np.power(-1,c)*redir*Gx # switch direction with each line
                        kx=kx+Pmatrix[step,rdindex]*dtx
                        readstep+=1
                        # If we've reached the middle of k space
                        if c+1==bottom+1 and (d+1)==resX/2:
                            print('------')
                            #print 'readstep:\t{}'.format(readstep)
                            #print('step:\t{}'.format(step))
                            print('Time at center or k is:\t{}'.format(t-(a)*self.TR-dtz-rft/2))
                            print('t={}'.format(t))
                            print('a={}'.format(a))
                            #print('TR={}'.format(self.TR))
                            #print('dtz={}'.format(dtz))
                            #print('rft={}'.format(rft))
                            #print('CurrentM={}'.format(Pmatrix[step,rdindex]))
                            print ('')
                            print('Time we want is:\t{}'.format(self.Te))
                            print('Center of kspace for VolNum {} and slice num {} is (kx,ky)=({},{})'.format(a,b,kx*self.gammabar,ky*self.gammabar))
                            print('-------')
                        coord[0,readstep]=kx*self.gammabar
                        coord[1,readstep]=ky*self.gammabar
                        
                    # If we're on the top line
                    if c+1==bottom+1+top:
                        t+=dt # 16      # Ramp down the X gradient
                        step+=1
                        Pmatrix[step,0]=t
                        kx=kx+Pmatrix[step-1,rdindex]*dt/2 # TF
                    # Otherwise switch gradient directions
                    elif dt-dty/2>=0: # If the y gradient can rise and fall enough in the time between x gradient shifts:
                        #Begin lowering the x gradieng
                        #print 'in the elif'
                        t+=dt-dty/2# 17      # At some point while the x gradient is lowering, begin raising the y gradient so it peaks when x=0
                        step+=1 # Line 14
                        Pmatrix[step,0]=t
                        Pmatrix[step,rdindex]=np.power(-1,c)*dty*gdt/2 # Gradient at this point is equavalent to raising at gdt for dty seconds
                        kx=kx+(Pmatrix[step-1,rdindex]+ Pmatrix[step,rdindex])*(dt-dty/2)/2 # Triangle area subtraction
                        # Begin Raising the y gradient while still lowering x
                        t+=dty/2 # 18       #line 15
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,pdindex]=phdir*Gy
                        ky=ky+dty*Pmatrix[step,pdindex]/4
                        kx=kx+Pmatrix[step-1,rdindex]*dty/4 # TG
                            
                    else:
                        #print('in the else')
                        t+=dt # Lower the x gradient
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,pdindex]=phdir*dt*gdt # Increase the y gradient as much as posible during dt
                        kx+=1/2*dt*Pmatrix[step-1,rdindex]
                        ky+=1/2*dt*Pmatrix[step,pdindex]
                        
                        t+=dty/2-dt # Step how long till Gy reaches peak
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,pdindex]=phdir*Gy
                        ky+=1/2*(dty/2-dt)*(Pmatrix[step-1,pdindex]+Pmatrix[step,pdindex])
 
                print 't at end of readout: {}'.format(t)           
                # Crushers
                t+=rt
                step+=1
                Pmatrix[step,0]=t
                Pmatrix[step,rdindex]=maxG
                Pmatrix[step,pdindex]=maxG
                Pmatrix[step,sdindex]=maxG
                t+=tcrush
                step+=1
                Pmatrix[step,0]=t
                Pmatrix[step,rdindex]=maxG
                Pmatrix[step,pdindex]=maxG
                Pmatrix[step,sdindex]=maxG
                t+=rt
                step+=1
                Pmatrix[step,0]=t
                
                t=TRslc*(b+1)+(a)*self.TR
                step=step+1
                Pmatrix[step,0]=t
                
            t=self.TR*(a+1)
            if t-Pmatrix[step,0]>1e-6:
                step=step+1
                Pmatrix[step,0]=t
            if t-Pmatrix[step,0]<-1e-6:
                print('WARNING TR is shorter than Nslc*TRslc')
            
            # pl.plot(coord[0,:],coord[1,:],'-o')
            # pl.show()
        np.savetxt('/home/dparker/Desktop/My_kCoord.txt',coord)
        
        
        #  Create a reference K matrix for the X/Y plane

        
        Kxref=coord[0,0:resX*resY]        
        Kyref=coord[1,0:resY*resY]  
        return(Pmatrix,Kxref,Kyref)        
                            
class Scanner:
    def __init__(self,B0=1,target=Target()):
        self.gamma=42.58*1e6   #MHz/T
        self.B0=B0
        self.Target=target
        self.G=Vector(np.zeros((3)))
        self.grf=Vector(np.zeros(3))
        self.oldG=self.G
        self.GintRF=self.G  # This tracks the integral of the gradients since the last RFpulse      
        
        self.theta=0
        self.a=[0,0,0]
        self.R=self.G.MakeRotMat(self.theta,self.a)
        self.T=Vector(np.zeros(3))

        self.Bwrec=1e5        
        self.TR=3.0
        self.angle=90
        
        self.Nx=target.Lx
        self.Ny=target.Ly
        self.Nz=target.Lz
        
        self.maxG=5.5e-2 #T/m
        self.risetime=2.2e-4 #s
        
        # The target image may be larger than the fmri in the future.  For now they are the same.
        self.resX=self.Nx
        self.resY=self.Ny
        self.resZ=self.Nz
        self.TRslc=self.TR/self.Nz
        
        self.xDim=target.xDim
        self.yDim=target.yDim
        self.zDim=target.zDim
        
        self.posx=np.zeros(self.Nx)
        self.posy=np.zeros(self.Ny)
        self.posz=np.zeros(self.Nz)
        
        # Set up x,y,z mid coordinates and the extending coordinate system
        self.xxx=-1*(self.Nx-1)/2.0 # Starting point for x
        self.posx=[(self.xxx+i)*self.xDim for i in range(self.Nx)]
        self.yyy=-1*(self.Ny-1)/2.0
        self.posy=[(self.yyy+i)*self.yDim for i in range(self.Ny)]
        self.zzz=-1*(self.Nz-1)/2.0
        self.posz=[(self.zzz+1)*self.zDim for i in range(self.Nz)]
        
        self.nSlices=self.Nz
        self.nVolumes=1
        
        #Slice Selection - only 2d for now
        self.ss=0
        self.zc=[self.ss] # list of slice centers
        
        #Number of lines of k-space bellow and above the central line?
        self.top=int(0)
        self.bottom=int(0)
        self.startkspace=1
        
        # Currently the whole ROI of the target is the entire target
        self.cover=100
        self.dt=0
        self.time=0
        self.TRF=0
        
        self.dkx=0
        self.dky=0
        self.dkz=0
        
        
        if self.resY%2==0:  # If the number of voxels in y is an even number
            self.bottom=int(round((self.cover-50)*self.resY/100)) # the bottom number of voxels is the total number in y times the percentage divided by 100, giving a fraction of voxels
            self.top=int(self.resY/2.0-1)
            self.startkspace=self.resY/2-self.bottom+1 # Set the kspace starting point to half the y voxels minus the number on the bottom plus one (for cover =100, this =1) 
        else:
            self.bottom=int(round((self.cover-50)*(self.resY-1)/100))
            self.top=int((self.resY-1)/2)
            self.startkspace=(self.resY-1)/2.0-self.bottom+1
        
        self.pulse=Pulse(self.TR,self.gamma,90,8e-2)
        
    def CalcPulse(self):            
        Pmat=self.pulse.episequence(self.nVolumes,self.zc,self.nSlices,self.resZ,'z+','y+','x+',self.resX,self.resY,self.bottom,self.top,
                                self.Bwrec,self.TRslc,self.risetime,self.maxG,self.Nx,self.Ny,self.xDim,self.yDim,self.zDim)
        return Pmat
    
    def set_time(self,newt):
        self.dt=newt-self.time
        self.time=newt
        
    def set_G(self,newG):
        self.oldG=self.G
        self.G=newG
        self.dkx,self.dky,self.dkz=self.modK(self.G,self.oldG)
        
    def set_R(self,newR):
        self.R=newR
        
    def set_T(self,newT):
        self.T=newT
        
    def get_time(self):
        return(self.time)
        
    def CalcPhase(self,V=voxel()):
        dot1=np.dot(self.G.v,V.s.xfm(self.T.v,self.theta,self.a))
        dot2=np.dot(self.oldG.v,V.s.xfm(self.T.v,self.theta,self.a))
        
        
        #print V.s.v
        # print dot
        # print type(dot)
        dPhi=-1*self.gamma*1/2*(dot1+dot2)*self.dt
        #dPhi=-1*self.gamma*dot1*self.dt
        Phi=V.get_Phi()+dPhi
        V.set_Phi(Phi)
        # dPhi=self.gamma*dot
        # V.set_Phi(dPhi)        
        # if V.MM.v[2]>0:            
        #     print dPhi
        #print 'G.v:{}'.format(self.G.v)
        #print 'V.s xfm: {}'.format(V.s.xfm(self.T.v,self.theta,self.a))
        return(Phi)
    
    def Calc_TargetPhase(self):
        rp=0
        for i,V in np.ndenumerate(self.Target.obj):
            dot1=np.dot(self.G.v,V.s.xfm(self.T.v,self.theta,self.a))
            dot2=np.dot(self.oldG.v,V.s.xfm(self.T.v,self.theta,self.a))

            #dPhi=-1*self.gamma*dot1*self.dt
            dPhi=-1*self.gamma*1/2*(dot1+dot2)*self.dt
            Phi=V.get_Phi()+dPhi
            V.set_Phi(Phi)
            # dPhi=self.gamma*dot
            # V.set_Phi(dPhi)
            if V.MM.v[-1]!=0:
                rp=Phi
                #print rp
        return(rp)
        
    
    def calcMxy(self,V=voxel()):    
        
        Phi=self.CalcPhase(V)
        Mxy=V.Mxy
        # if V.MM.v[2]>0:
        #     print Mxy
        return(Mxy,Phi)
    
    def CalculateVolume(self):
        SigReal=[]
        SigImag=[]
        rp=0
        for i,V in np.ndenumerate(self.Target.obj):            
            Mxy,Phi=self.calcMxy(V)                         # Calculates Bulk Mxyz
            Fx=0.5*self.gamma*self.xDim*(self.GintRF.v[0])*2*np.pi    # Simulate gradient across voxel (MRI simulator with object-specific field map calculations, Yoder et al, eq 24 amd eq 20 in possum)
            Fy=0.5*self.gamma*self.xDim*(self.GintRF.v[1])*2*np.pi    
            Fz=0.5*self.gamma*self.xDim*(self.GintRF.v[2])*2*np.pi       
            #SigReal.append(self.xDim*self.yDim*self.zDim*np.abs(Mxy)*np.sin(Fx)/Fx*np.sin(Fy)/Fy*np.sin(Fz)/Fz*np.cos(Phi*2*np.pi))# eQ 20 in possum
            #SigImag.append(self.xDim*self.yDim*self.zDim*np.abs(Mxy)*np.sinc(Fx)*np.sinc(Fy)*np.sinc(Fz)*np.sin(Phi*2*np.pi))
            SigReal.append(self.xDim*self.yDim*self.zDim*Mxy*np.cos(Phi*2*np.pi))# eQ 20 in possum
            SigImag.append(self.xDim*self.yDim*self.zDim*Mxy*np.sin(Phi*2*np.pi))
            # SigReal.append(self.xDim*self.yDim*self.zDim*Mxy*np.cos(-1*self.gamma*self.B0*self.time-Phi))# eQ 20 in possum
            # SigImag.append(self.xDim*self.yDim*self.zDim*Mxy*np.sin(-1*self.gamma*self.B0*self.time-Phi))
            #print Phi
            if V.MM.v[-1]!=0:
                rp=Phi
                #print rp
        return(SigReal,SigImag,rp)
    
    def CalculateVolume_R(self):
        Sig=[]
        for i,V in np.ndenumerate(self.Target.obj):
            Mxy,Phi=self.calcMxy(V)
            Sig.append(Mxy)
            self.Target.obj[i].set_Phi(Phi)
            self.Target.obj[i].set_Mxy(Mxy)
        return(Sig)
    
    def modK(self,G1=Vector(),G2=Vector()):
        # Assumes that G never crosses zero in the middle of a step
        x1,y1,z1=G1.get_v()
        x2,y2,z2=G2.get_v()
        dx=0.5*self.dt*(x1+x2)*self.gamma
        dy=0.5*self.dt*(y1+y2)*self.gamma
        dz=0.5*self.dt*(z1+z2)*self.gamma
        return(dx,dy,dz)
        
    def CalculateTimeSeries(self,Pmat,Rotate=None,Translate=None):
        xstart=0
        xend=self.Nx
        ystart=0
        yend=self.Ny
        zend=self.Nz
        sszz_slc=1
        
        # Slice Selection
        slcdir=1
        if np.abs(slcdir)==1:
            sszdim=self.zDim
            ssNz=self.Nz
        # Skipping a lot of z slice selection
        
        MyPhi=[0]
        MyMxy=[0]
        
        # No Motion
        if Rotate==None and Translate==None:
            nreadp=self.nVolumes*self.nSlices*self.resX*self.resY
            Sig=np.zeros((2,nreadp))
            sreal=np.zeros(nreadp)
            simag=np.zeros(nreadp)
            print nreadp
            
            voxelCounter=0
            cxyz=self.xDim*self.yDim*self.zDim
            
            Nxx=len(self.posx)
            
            numpoints=Pmat.shape[0]
            readstep=0
            
            
            Kx=[0]
            Ky=[0]
            Time=Pmat[1:,0]
            
            for it,t in enumerate(Time):
                  
                self.set_time(t)
                self.set_G(Vector(Pmat[it+1,5:8]))
                self.angle=Pmat[it+1,1]*180/np.pi
                

                
                # If there is an RF pulse
                if Pmat[it+1,1]!=0:     
                    self.TRF=t                              # Mark this as the RF time
                    self.GintRF=Vector()                    # Reset the gradient Integrals
                    self.Target.reset_phase()
                    m=self.Target.excite_Voxels(self.angle) # Excite the target
                    if m!=None:
                        MyMxy.append(m)
                        print('woo')
                    self.dt=0
                else:
                    m=self.Target.recover_Voxels(self.time-self.TRF)
                    if m!=None:
                        MyMxy.append(m)
                # Calculate movement in Kspace due to gradients
                
                Kx.append(Kx[-1]+self.dkx)
                Ky.append(Ky[-1]+self.dky)                
                
                # if self.oldG.get_v()[0]!=0 or self.G.get_v()[0]!=0:
                #     self.GintRF.v[0]+=dkx
                # if self.oldG.get_v()[1]!=0 or self.G.get_v()[1]!=0:
                #     self.GintRF.v[1]+=dkx                
                # if self.oldG.get_v()[2]!=0 or self.G.get_v()[2]!=0:
                #     self.GintRF.v[2]+=dkx
                
                # Update the gradient integrals
                self.GintRF.v[0]+=self.dkx
                self.GintRF.v[1]+=self.dky                
                self.GintRF.v[2]+=self.dkz  
                
                
                # If there is readout
                if Pmat[it+1,4]==1:
                    Vreal,Vimag,ph=self.CalculateVolume()
                    sreal[readstep]=np.sum(Vreal)
                    #print np.sum(Vreal)
                    simag[readstep]=np.sum(Vimag)
                    MyPhi.append(ph)
                    readstep+=1
                else:
                    ph=self.Calc_TargetPhase()
                    MyPhi.append(ph)

            print self.TRF
            return(sreal,simag,Kx,Ky,MyPhi,MyMxy)
        
        
        elif Rotate==None:
            print ('Translation only Code')
            return []
        
        elif Translate==None:
            print('Rotation Only Code')
            return []
        
        else:
            print('rotation and translation code')
            return []

    def interpolation_gradients(self,a,b,c):
        #interpolate between a (at t=ta) and b (t=tb), at time t=c
        # NOTE: ta and tb are stored in the first elements of a and b
        # rowvectors are from EPI sequence
        p=np.zeros(8)
        p[0]=c;
        if (np.abs(b[0]-a[0])<1e-12):
            print "Warning: gradients in the EPI sequence are spaced too close to each other"
        else:
            p[5]=(c-a[0])*(b[5]-a[5])/(b[0]-a[0])+a[5];
            p[6]=(c-a[0])*(b[6]-a[6])/(b[0]-a[0])+a[6];
            p[7]=(c-a[0])*(b[7]-a[7])/(b[0]-a[0])+a[7];
        
        return p;
      
    def PySorter(self,pulse,motion):
        
        dimMot=motion.shape[0]
        dimPul=pulse.shape[0]
        
        newT=[]
        
        tp=0
        tm=0
        for tm in range(dimMot):
        
            while pulse[tp,0]<motion[tm,0]:
                newT.append(pulse[tp,0])
                tp+=1
            newT.append(motion[tm,0])
            # 
            # if np.abs(motion[tm,0]-pulse[tp,0])>1e-06:
            #     newT.append(motion[tm,0])
        
        oldT=pulse[:,0]
        
        NewPulse=np.zeros((len(newT),pulse.shape[-1]))
        NewPulse[:,0]=newT
        for i in range(1,pulse.shape[-1]):
            f=ipt.interp1d(oldT,pulse[:,i])
            NewPulse[:,i]=f(newT)
            
        
        
        print "PySorter Len:\t{}".format(np.shape(newT))
        return(NewPulse)
                
        
        
    
    def sorter(self,pulse, motion):
        #matrix mainmatrix M  is the output of this function
        #(1)=time (s),
        #(2)=rf angle(rad),(3)=rf frequency bandwidth df(Hz),(4)=rf center frequecy fc(Hz),
        #(5)=readout (1/0),
        #[5]=x gradient (T/m),(7)=y gradient (T/m),(8)=z gradient (T/m),
        #(9)=Tx translation (m),(10)=Ty translation (m), (11)=Tz translation (m), 
        #(12)=b angle of rotation (rad),(13)=Bx,(14)=By,(15)=Bz rotation axis (m)---rotation of the interpolated motion point between A(k) and A(k+1)--relative to A(m)  
        #(16)=a angle of rotation (rad),(17)=Ax,(18)=Ay,(19)=Az rotation axis (m)---rotation at the control motion point A(k)
        
        #cout<<"Started the sorter"<<endl;
        dimp=pulse.shape[0]#size in time for pulse
        tp=0;# counter for the pulse seq
        dimm=motion.shape[0]#size in time for motion
        #Counting the size of the new matrix
        ts=0
        newT=[]
        for tm in range(dimm):
        
            if (tp<dimp):
            
                # while the difference between the motion time point and pulse time point is less greater than 1e-6
                while (tp<dimp) and (motion[tm,0]-pulse[tp,0]>1e-6):
                    #Incrament the pulse timepoint until they're close
                    ts+=1;tp+=1
                    #newT.append(pulse[tp,0])
                    
                ts+=1;
                
                if (tp<dimp)and (np.abs(motion[tm,0]-pulse[tp,0])<1e-06):                  
                    tp+=1
                    
          
        
        for k in range(tp,dimp):
            ts+=1

        dimnew=ts
        #Storing the order of the rows from pulse and motion into one column. Positive int tp shows where the pulse rows go and negative int tm shows where the new rows go
        tsort=np.zeros(dimnew)
        ts=-1;tp=0;
        for tm in range(dimm):
            if (tp<dimp):
          
                while (tp<dimp) and (motion[tm,0]-pulse[tp,0]>1e-6):
            
                    ts+=1
                    tsort[ts-1]=tp
                    tp+=1
            
            
                ts+=1
                tsort[ts-1]=-tm
            
                if (tp<dimp) and (np.abs(motion[tm,0]-pulse[tp,0])<1e-06):
                    tp+=1

        for k in range(tp,dimp):
            ts+=1
            tsort[ts-1]=k

        tsort=tsort.astype(int)
        NewPulse=np.zeros((dimnew,8))
        print "dimnew:\t{}".format(dimnew)
        print 'tsort[-1]:\t{}'.format(tsort[-1])
        print 'tmax:\t{}'.format(np.amax(pulse[:,0]))
        # pl.plot(tsort);
        # pl.show()
        if (dimnew!=dimp):
            for ii in range(dimnew-2,-1,-1):
                if (tsort[ii]>0):

                    NewPulse[ii+1,0]=pulse[tsort[ii],0]
                    for kk in range(1,8):
                        NewPulse[ii+1,kk]=pulse[tsort[ii],kk]


                if (tsort[ii]<0)and(ii>=0):
                    NewPulse[ii+1,0]=motion[-tsort[ii],0]
                    print motion[-tsort[ii],0]
                    # print tsort[ii-1]
                    # print tsort[ii]
                    # print tsort[ii+1]
                    a=np.zeros(8)
                    b=np.zeros(8)
                    G=np.zeros(8)
                    b=np.array([NewPulse[ii+1,0],NewPulse[ii+1,1],NewPulse[ii+1,2],NewPulse[ii+1,3],NewPulse[ii+1,4],NewPulse[ii+1,5],NewPulse[ii+1,6],NewPulse[ii+1,7]])
                    a=np.array([NewPulse[ii,0],NewPulse[ii,1],NewPulse[ii,2],NewPulse[ii,3],NewPulse[ii,4],NewPulse[ii,5],NewPulse[ii,6],NewPulse[ii,7]])

                    G=self.interpolation_gradients(a,b,motion[-tsort[ii],0]) 
                    for kk in range(1,8):
                        NewPulse[ii+1,kk]=G[kk]
        return(NewPulse)


    def CalculateKVector_Zrotation(self,Pmat,MotMat):
        xstart=0
        xend=self.Nx
        ystart=0
        yend=self.Ny
        zend=self.Nz
        sszz_slc=1
        
        # Slice Selection
        slcdir=1
        if np.abs(slcdir)==1:
            sszdim=self.zDim
            ssNz=self.Nz
        # Skipping a lot of z slice selection
        
        MyPhi=[0]
        MyMxy=[0]
        
        # No Motion
        nreadp=self.nVolumes*self.nSlices*self.resX*self.resY
        print nreadp
        
        voxelCounter=0
        cxyz=self.xDim*self.yDim*self.zDim            
        Nxx=len(self.posx)            
        numpoints=Pmat.shape[0]
        readstep=0
        
        
        Kx=[]
        Ky=[]
        Time=Pmat[:,0]
        
        Zrot=MotMat[:,6]
        rotTime=MotMat[:,0]
        if Time[-1]>rotTime[-1]:
            rotTime=np.hstack((rotTime,Time[-1]+1))
            Zrot=np.hstack((Zrot,Zrot[-1]))
        
        Zrot_Hf=np.interp(Time,rotTime,Zrot)
        # pl.plot(Time,Zrot_Hf)
        # pl.show()
        
        Zrot_Debug=[]
        Zrot_Ref=Zrot_Hf[0]
        runningKx=0
        runningKy=0
        NewGx=[]
        NewGy=[]
        NewGz=[]
        NewTime=[]
        rfpTime=0
        
        FullKx=[]
        FullKy=[]
        #np.savetxt('/home/dparker/Desktop/Time.txt',Time)
        
        for it,t in enumerate(Time[1:]):
              
            self.set_time(t)
            
            self.angle=Pmat[it+1,1]*180/np.pi
            
            NewG=Vector(Pmat[it+1,5:8])

            # If there is an RF pulse
            if Pmat[it+1,1]!=0:
                if Pmat[it,1]==0:
                    rfpTime=t
                    Zrot_Ref=Zrot_Hf[it+1]
                    print 'Zrot_Ref={}'.format(Zrot_Ref)
                    # Kx[-1]=0
                    # Ky[-1]=0
                    runningKx=0
                    runningKy=0
                    
                #Zrot_Ref=Zrot_Hf[it]
                
                
                self.TRF=t                              # Mark this as the RF time
                self.GintRF=Vector()                    # Reset the gradient Integrals
                #self.Target.reset_phase()
                #m=self.Target.excite_Voxels(self.angle) # Excite the target
                #if m!=None:
                    #MyMxy.append(m)
                    #print('woo')
                self.dt=0
            #else:
                #m=self.Target.recover_Voxels(self.time-self.TRF)
                #if m!=None:
                    #MyMxy.append(m)
            # Calculate movement in Kspace due to gradients
            Zrot_angle=(Zrot_Hf[it]-Zrot_Ref)
            #Zrot_angle=Zrot_Hf[it]
            #Zrot_Debug.append(Zrot_angle)
            
            NewG.set_v(NewG.rotate(1*Zrot_angle*180/np.pi,[0,0,1]))
            #NewG.set_v(NewG.rotate(1*Zrot_angle,[0,0,1]))

            self.set_G(NewG)
            runningKx+=self.dkx
            runningKy+=self.dky
            NewGx.append(self.G.v[0])
            NewGy.append(self.G.v[1])
            NewGz.append(self.G.v[2])
               
            
            # if self.oldG.get_v()[0]!=0 or self.G.get_v()[0]!=0:
            #     self.GintRF.v[0]+=dkx
            # if self.oldG.get_v()[1]!=0 or self.G.get_v()[1]!=0:
            #     self.GintRF.v[1]+=dkx                
            # if self.oldG.get_v()[2]!=0 or self.G.get_v()[2]!=0:
            #     self.GintRF.v[2]+=dkx
            
            # Update the gradient integrals
            self.GintRF.v[0]+=self.dkx
            self.GintRF.v[1]+=self.dky                
            self.GintRF.v[2]+=self.dkz  
            FullKx.append(runningKx)
            FullKy.append(runningKy)
            
            
            # If there is readout
            if Pmat[it+1,4]==1:
                NewTime.append(t-rfpTime)
                #Vreal,Vimag,ph=self.CalculateVolume()
                #sreal[readstep]=np.sum(Vreal)
                #print np.sum(Vreal)
                #simag[readstep]=np.sum(Vimag)
                #MyPhi.append(ph)
                readstep+=1
                Kx.append(runningKx)
                Ky.append(runningKy)
                Zrot_Debug.append(Zrot_angle)
            #else:
                #ph=self.Calc_TargetPhase()
                #MyPhi.append(ph)

        print self.TRF
        # pl.plot(Time,Zrot_Debug)
        # pl.figure()
        # pl.plot(Kx,Ky,'-o')
        # pl.show()
        np.savetxt('/home/dparker/Desktop/Zrot_ByTime.txt',Zrot_Debug)
        np.savetxt('/home/dparker/Desktop/Time.txt',NewTime)

        
        return Kx,Ky,NewGx,NewGy,NewGz,Zrot_Hf


    def CalculateKVector_Zrotation_New2(self,Pmat,MotMat):
        xstart=0
        xend=self.Nx
        ystart=0
        yend=self.Ny
        zend=self.Nz
        sszz_slc=1
        
        # Slice Selection
        slcdir=1
        if np.abs(slcdir)==1:
            sszdim=self.zDim
            ssNz=self.Nz
        # Skipping a lot of z slice selection
        
        MyPhi=[0]
        MyMxy=[0]
        
        # No Motion
        nreadp=self.nVolumes*self.nSlices*self.resX*self.resY
        print nreadp
        
        voxelCounter=0
        cxyz=self.xDim*self.yDim*self.zDim            
        Nxx=len(self.posx)            
        numpoints=Pmat.shape[0]
        readstep=0
        
        
        Kx=[]
        Ky=[]
        Time=Pmat[:,0]
        
        Zrot=MotMat[:,6]
        rotTime=MotMat[:,0]
        if Time[-1]>rotTime[-1]:
            rotTime=np.hstack((rotTime,Time[-1]+1))
            Zrot=np.hstack((Zrot,Zrot[-1]))
        
        Zrot_Hf=np.interp(Time,rotTime,Zrot)
        # pl.plot(Time,Zrot_Hf)
        # pl.show()
        
        Zrot_Debug=[]
        Zrot_Ref=Zrot_Hf[0]
        runningKx=0
        runningKy=0
        NewGx=[]
        NewGy=[]
        NewGz=[]
        NewTime=[]
        rfpTime=0
        
        FullKx=[]
        FullKy=[]
        #np.savetxt('/home/dparker/Desktop/Time.txt',Time)
        
        g=np.matrix(np.zeros((4,3)))
        
        grf1=0
        grf2=0
        grf3=0
        grf4=0
        rnew=[0,0,0,0]
        rmnew=[0,0,0,0]
        
        for it,t in enumerate(Time[1:]):
              
            self.set_time(t)
            told=Time[it]
            self.angle=Pmat[it+1,1]#*180/np.pi
            
            NewG=Vector(Pmat[it+1,5:8])
            OldG=Vector(Pmat[it,5:8])
            # If there is an RF pulse
            if Pmat[it+1,1]!=0:
                if Pmat[it,1]==0:
                    rfpTime=t
                    Zrot_Ref=Zrot_Hf[it+1]
                    print 'Zrot_Ref={}'.format(Zrot_Ref)
                    print it+1
                    rmnew=[Zrot_Ref,0,0,1]
                    # Kx[-1]=0
                    # Ky[-1]=0
                    runningKx=0
                    runningKy=0
                    
                #Zrot_Ref=Zrot_Hf[it]
                
                
                self.TRF=t                              # Mark this as the RF time
                self.GintRF=Vector()                    # Reset the gradient Integrals
                #self.Target.reset_phase()
                #m=self.Target.excite_Voxels(self.angle) # Excite the target
                #if m!=None:
                    #MyMxy.append(m)
                    #print('woo')
                self.dt=0
            #else:
                #m=self.Target.recover_Voxels(self.time-self.TRF)
                #if m!=None:
                    #MyMxy.append(m)
            # Calculate movement in Kspace due to gradients
            #Zrot_angle=Zrot_Hf[it]-Zrot_Ref
            Zrot_angle=Zrot_Hf[it+1]
            Zrot_old=Zrot_Hf[it]
            rnew=[Zrot_angle,0,0,1]
            
            
            g[0,0]+=i1(OldG[0],NewG[0],told,t)
            g[1,0]+=i2(OldG[0],NewG[0],Zrot_old,Zrot_angle,told,t)
            g[2,0]+=i1(OldG[0],NewG[0],told,t)-i2(OldG[0],NewG[0],Zrot_old,Zrot_angle,told,t)
            g[3,0]+=i4(OldG[0],NewG[0],0,0,told,t)
            
            g[0,1]+=i1(OldG[1],NewG[1],told,t)
            g[1,1]+=i2(OldG[1],NewG[1],Zrot_old,Zrot_angle,told,t)
            g[2,1]+=i1(OldG[1],NewG[1],told,t)-i2(OldG[0],NewG[0],Zrot_old,Zrot_angle,told,t)
            g[3,1]+=i4(OldG[1],NewG[1],0,0,told,t)
            
            g[0,2]+=i1(OldG[2],NewG[2],told,t)
            g[1,2]+=i2(OldG[2],NewG[2],Zrot_old,Zrot_angle,told,t)
            g[2,2]+=i1(OldG[2],NewG[2],told,t)-i2(OldG[0],NewG[0],Zrot_old,Zrot_angle,told,t)
            g[3,2]+=i4(OldG[2],NewG[2],0,0,told,t)
            

            g1=I(0,rnew,rmnew,g)
            g2=I(1,rnew,rmnew,g)
            g3=I(2,rnew,rmnew,g)
            g4=1#I(3,rnew,rmnew,g)
            #Zrot_Debug.append(Zrot_angle)
            
            
            gg1=g1-grf1
            gg2=g2-grf2
            gg3=g3-grf3
            gg4=g4-grf4
            
            
            
            if Pmat[it+1,1]!=0:
                if Pmat[it,1]==0:
                    grf1=gg1
                    grf2=gg2
                    grf3=gg3
                    grf4=gg4
            
            #NewG.set_v(NewG.rotate(1*Zrot_angle*180/np.pi,[0,0,1]))
            NewG.set_v(NewG.rotate(1*Zrot_angle,[0,0,1]))

            self.set_G(NewG)
            runningKx=self.gamma*gg1
            runningKy=self.gamma*gg2
            NewGx.append(self.G.v[0])
            NewGy.append(self.G.v[1])
            NewGz.append(self.G.v[2])
               
            
            # if self.oldG.get_v()[0]!=0 or self.G.get_v()[0]!=0:
            #     self.GintRF.v[0]+=dkx
            # if self.oldG.get_v()[1]!=0 or self.G.get_v()[1]!=0:
            #     self.GintRF.v[1]+=dkx                
            # if self.oldG.get_v()[2]!=0 or self.G.get_v()[2]!=0:
            #     self.GintRF.v[2]+=dkx
            
            # Update the gradient integrals
            self.GintRF.v[0]+=self.dkx
            self.GintRF.v[1]+=self.dky                
            self.GintRF.v[2]+=self.dkz  
            FullKx.append(runningKx)
            FullKy.append(runningKy)
            
            
            # If there is readout
            if Pmat[it+1,4]==1:
                NewTime.append(t-rfpTime)
                #Vreal,Vimag,ph=self.CalculateVolume()
                #sreal[readstep]=np.sum(Vreal)
                #print np.sum(Vreal)
                #simag[readstep]=np.sum(Vimag)
                #MyPhi.append(ph)
                readstep+=1
                Kx.append(runningKx)
                Ky.append(runningKy)
                Zrot_Debug.append(Zrot_angle)
            #else:
                #ph=self.Calc_TargetPhase()
                #MyPhi.append(ph)

        print self.TRF
        # pl.plot(Time,Zrot_Debug)
        # pl.figure()
        # pl.plot(Kx,Ky,'-o')
        # pl.show()
        np.savetxt('/home/dparker/Desktop/Zrot_ByTime.txt',Zrot_Debug)
        np.savetxt('/home/dparker/Desktop/Time.txt',NewTime)
        FileHandle.close()
        
        return Kx,Ky,NewGx,NewGy,NewGz,Zrot_Hf
        
        # 
        # elif Rotate==None:
        #     print ('Translation only Code')
        #     return []
        # 
        # elif Translate==None:
        #     print('Rotation Only Code')
        #     return []
        # 
        # else:
        #     print('rotation and translation code')
        #     return []



    def CalculateKVector_Zrotation_New(self,Pmat,MotMat):
            xstart=0
            xend=self.Nx
            ystart=0
            yend=self.Ny
            zend=self.Nz
            sszz_slc=1
            
            # Slice Selection
            slcdir=1
            if np.abs(slcdir)==1:
                sszdim=self.zDim
                ssNz=self.Nz
            # Skipping a lot of z slice selection
            
            MyPhi=[0]
            MyMxy=[0]
            
            # No Motion
            nreadp=self.nVolumes*self.nSlices*self.resX*self.resY
            print nreadp
            
            voxelCounter=0
            cxyz=self.xDim*self.yDim*self.zDim            
            Nxx=len(self.posx)            
            numpoints=Pmat.shape[0]
            readstep=0
            
            
            Kx=[]
            Ky=[]
            Time=Pmat[:,0]
            
            grf1=0
            grf2=0
            grf3=0
            grf4=0
            
            gg1=0
            gg2=0
            gg3=0
            gg4=0
            
            Zrot=MotMat[:,6]
            rotTime=MotMat[:,0]
            if Time[-1]>rotTime[-1]:
                rotTime=np.hstack((rotTime,Time[-1]+1))
                Zrot=np.hstack((Zrot,Zrot[-1]))
            
            Zrot_Hf=np.interp(Time,rotTime,Zrot)
            # pl.plot(Time,Zrot_Hf)
            # pl.show()
            
            Zrot_Debug=[]
            Zrot_Ref=Zrot_Hf[0]
            runningKx=0
            runningKy=0
            NewGx=[]
            NewGy=[]
            NewGz=[]
            NewTime=[]
            rfpTime=0
            #np.savetxt('/home/dparker/Desktop/Time.txt',Time)
            IGX=[]
            
            g=np.matrix(np.zeros((4,3)))
            g1motion=np.zeros(numpoints)
            g2motion=np.zeros(numpoints)
            g3motion=np.zeros(numpoints)
            g4motion=np.zeros(numpoints)
            rmnew=np.array([0,0,0,1])
            trf=0
            
            for it,t in enumerate(Time[1:]):
                  
                self.set_time(t)
                
                self.angle=Pmat[it+1,1]*180/np.pi
                
                NewG=Vector(Pmat[it+1,5:8])
    
                # If there is an RF pulse
                if Pmat[it+1,1]!=0:
                    if Pmat[it,1]==0:
                        rfpTime=t
                        trf=t
                        Zrot_Ref=Zrot_Hf[it+1]
                        rmnew=np.array([Zrot_Ref,0,0,1])
                        print 'Zrot_Ref={}'.format(Zrot_Ref)
                        # Kx[-1]=0
                        # Ky[-1]=0
                        runningKx=0
                        runningKy=0
                        
                        
                        
                        
                    
                aold=Zrot_Hf[it]
                anew=Zrot_Hf[it+1]                
                rnew=np.array([Zrot_Hf[it+1],0,0,1])
                gxold=Pmat[it,5];#gradients at told 
                gyold=Pmat[it,6];#
                gzold=Pmat[it,7];#
                gxnew=Pmat[it+1,5];# gradients at tnew
                gynew=Pmat[it+1,6];#
                gznew=Pmat[it+1,7];#
                trold1=0;#translation at told
                trold2=0;#
                trold3=0;
                trnew1=0;#translation at tnew
                trnew2=0;#
                trnew3=0;#
                tnew=t
                told=Time[it]
                igx=i1(gxold,gxnew,told,tnew);
                IGX.append(igx)
                isingx=i2(gxold,gxnew,aold,anew,told,tnew)
                icosgx=i3(gxold,gxnew,aold,anew,told,tnew)
                g1=np.sin(Zrot_Ref)*(igx-isingx-icosgx)+np.cos(Zrot_Ref)*(igx+isingx-icosgx)
                g2=0
                g3=0
                

                
                if (gyold!=0 or gynew!=0):
                    # g[0,1]+=i1(gyold,gynew,told,tnew);
                    # g[1,1]+=i2(gyold,gynew,aold,anew,told,tnew);                    
                    # g[2,1]+=(i1(gyold,gynew,told,tnew)- i3(gyold,gynew,aold,anew,told,tnew))                    
                    # g[3,1]+=i4(gyold,gynew,trold2,trnew2,told,tnew);
                    igy=i1(gyold,gynew,told,tnew);
                    isingy=i2(gyold,gynew,aold,anew,told,tnew)
                    icosgy=i3(gyold,gynew,aold,anew,told,tnew)
                    g2=np.sin(Zrot_Ref)*(igy-isingy-icosgy)+np.cos(Zrot_Ref)*(igy+isingy-icosgy)
                
                if (gzold!=0 or gznew!=0):
                    igz=i1(gzold,gznew,told,tnew);
                    isingz=i2(gzold,gznew,aold,anew,told,tnew)
                    icosgz=i3(gzold,gznew,aold,anew,told,tnew)
                    g3=np.sin(Zrot_Ref)*(igz-isingz-icosgz)+np.cos(Zrot_Ref)*(igz+isingz-icosgz)
                    # g[0,2]+=i1(gzold,gznew,told,tnew);
                    # g[1,2]+=i2(gzold,gznew,aold,anew,told,tnew);                    
                    # g[2,2]+=i1(gzold,gznew,told,tnew)- i3(gzold,gznew,aold,anew,told,tnew);                    
                    # g[3,2]+=i4(gzold,gznew,trold3,trnew3,told,tnew);
                
                #Matrix R(3,3);
                #Matrix A(3,3);
                #R=rotmat(rmnew);#control matrix, changes only when the axis changes 
                #A=axismat(rnew);#moving matrix, controls rotation between control matrices
                #g1=I(0,rnew,rmnew,g);
        
                # print"g1=I(1,rnew,rmnew,g)= {}".format(g1)
                # print"rnew= {}".format(rnew)
                # print"rmnew= {}".format(rmnew)
                # print"g matrix "
                # print g
                
                # g2=I(1,rnew,rmnew,g);
                # g3=I(2,rnew,rmnew,g);
                # g4=g[3,0]+g[3,1]+g[3,2];
                g4=0
                g1motion[it]=g1;
                g2motion[it]=g2;
                g3motion[it]=g3;
                g4motion[it]=g4;

                gg1+=g1-grf1;
                gg2+=g2-grf2;
                gg3+=g3-grf3;
                gg4+=g4-grf4;
              
                tt=tnew-trf;

                
                
                if Pmat[it+1,1]!=0:
                    if Pmat[it,1]==0:
                        grf1=g1
                        trf=tnew
                        grf2=g2
                        grf3=g3
                        grf4=g4
                        
                if Pmat[it+1,4]==1:
                    Kx.append(gg1*self.gamma)
                    Ky.append(gg2*self.gamma)
                    # if (told>=timecourse[actstep] && actstep<=(Nact-2)){
                    # coeff(activation[actstep],activation[actstep+1],timecourse[actstep],timecourse[actstep+1],dT2_1,dT2_2);
                    # dT2_1=dT2_1*iT2*iT2;
                    # dT2_2=dT2_2*iT2*iT2;
                    # actstep=actstep+1;
                    # }
                    # actint+=(dT2_1+dT2_2*(tnew+told)/2)*(tnew-told);
                    # if(opt_test==1 && readstep%4096==2081 && v==1){
                    # cout.precision(20);
                    # cout<<"actstep= "<<actstep<<"; actval= "<<activation[actstep]<<"; acttime="<<timecourse[actstep]<<"; dT2_1= "<<dT2_1<<"; dT2_2= "<<dT2_2<<"; iT2= "<<iT2<<"; actint= "<<actint<<endl;
                    # }
                    # phase=gama*(gg1*x+gg2*y+gg3*z+gg4+(b0+chshift)*tt);
                    # if (fabs(rfangle)>1e-05){
                    # excitation=0;
                    # df=H(step,3);//frequency width
                    # fc=H(step,4);//center frequency
                    # rfstep=rfstep+1;
                    # if (v==1){
                    # //trnew1=H(step,9);//translation at tnew
                    # //trnew2=H(step,10);//
                    # //trnew3=H(step,11);//
                    # RowVector gradnew(3);
                    # gradnew <<gxnew<<gynew<<gznew;
                    # RowVector rr=gammabar*gradnew*(rotmat(rnew)*rotmat(rmnew));
                    # rr1=rr(1);rr2=rr(2);rr3=rr(3);
                    # cout<<"Assigning g values to motionRV"<<endl;
                    # 
                    # cout<<"Done"<<endl;
                    # 
                    # 
                    # trr=gammabar*(gxnew*trnew1+gynew*trnew2+gznew*trnew3);
                    # if (opt_test==1 && readstep%4096==0 && v==1) {
                    # cout<<"gxnew= "<<gxnew<<"; trnew1= "<<trnew1<<"; gammabar= "<<gammabar<<endl;
                    # cout<<"gynew= "<<gynew<<"; trnew2= "<<trnew2<<"; gammabar= "<<gammabar<<endl;
                    # cout<<"gznew= "<<gznew<<"; trnew3= "<<trnew3<<"; gammabar= "<<gammabar<<endl;
                    # cout<<"trr=gammabar*(gxnew*trnew1+gynew*trnew2+gznew*trnew3)= "<<trr<<endl;
                    # }
                    # rotmotion1[rfstep-1]=rr1;
                    # rotmotion2[rfstep-1]=rr2;
                    # rotmotion3[rfstep-1]=rr3;
                    # transmotion[rfstep-1]=trr;
                    # }
                    # else {
                    # rr1=rotmotion1[rfstep-1];
                    # rr2=rotmotion2[rfstep-1];
                    # rr3=rotmotion3[rfstep-1];
                    # trr=transmotion[rfstep-1];
                    # }
                    # f=rr1*x+rr2*y+rr3*z+trr+(b0+chshift)*gammabar;//gammabar is already included and grad included in trr
                    # fval=(f-fc)/df;
                    # off=(fval-dslcp_first)/dslcp;
                    # int nf=(int) off;
                    # //int nf=(int) (round_ivana(((f-fc)/df-dslcp_first)/dslcp,0));
                    # if (opt_test==1 && readstep%4096==0 && v==1 ){
                    # cout<<"fc_slc= "<<fc<<"; df_slc= "<<df<<endl;
                    # cout<<"rr1*x+rr2*y+rr3*z= "<<rr1*x+rr2*y+rr3*z<<endl;
                    # cout<<"trr= "<<trr<<endl;
                    # cout<<"(b0+chshift)*gammabar= "<<(b0+chshift)*gammabar<<endl;
                    # cout<<"fc_vox=rr1*x+rr2*y+rr3*z+trr+(b0+chshift)*gammabar= "<<f<<endl;
                    # cout<<"f in the table  nf= (int)((f-fc)*321/df+400+0.5)= "<<nf<<endl;
                    # }
                    # if (nf>=0 && nf<=(Nslc-2)) { 
                    # off-=nf;
                    # ts=table_slcprof[nf];
                    # sx=(table_slcprof[nf+1]-ts)*off + ts;
                    # rfangle_f=sx*rfangle*RFtrans;//RFtrans are values 0 to 1 to derscribe the inhomogeneity f the receive RF field. 1 is for perfectly homog;
                    # if (opt_test==1 && readstep%4096==0 && v==1 ){
                    # cout<<"table_slcprof[nf]= "<<sx<<"; rfangle= "<<rfangle<<"; RFtrans= "<<RFtrans<<endl;
                    # cout<<"rfangle_f=table_slcprof[nf]*rfangle*RFtrans= "<<rfangle_f<<endl;
                    # }
                    # // if (fc-df/2<=f && f<=fc+df/2) {
                    # if (fabs(rfangle_f)>1e-06){//new stuff mon dec 19 //Edit: 29.11.12
                    # excitation=1;
                    # if (opt_test==1 && readstep%4096==0 && readstep>7*4096){ 
                    # cout<<free_cout(m,tt,tissue,phase,actint)<<endl;
                    # }
                    # m=free(m,tt,tissue,phase,actint);
                    # //new stuff mon dec 19
                    # //due to crushers or any gradient induced dephasing over the voxel a new initial magnetisation is introduced which is the average of the magnetisations over the voxel  
                    # xvalrf=fabs(glo_cx*(gg1+b0x*tt));
                    # yvalrf=fabs(glo_cy*(gg2+b0y*tt));
                    # zvalrf=fabs(glo_cz*(gg3+b0z*tt));
                    # xyzrf=Sinc(xvalrf)*Sinc(yvalrf)*Sinc(zvalrf);
                    # m(1)=m(1)*xyzrf;
                    # m(2)=m(2)*xyzrf;
                    # m=rot(rfangle_f,"x")*m;
                    # //new stuff
                    # m00=sqrt(m(1)*m(1)+m(2)*m(2));
                    # if (opt_test==1 && readstep%4096==0 && v==1){ 
                    # cout<<"Projection of the magnetisation vector into the xy plane after flipping is "<<m00<<endl;
                    # }
                    # trf=tnew;
                    # 
                    # actint=0.0;
                    # //}
                    # }//new stuff
                    # }
                    # }
            #         
            #         self.TRF=t                              # Mark this as the RF time
            #         self.GintRF=Vector()                    # Reset the gradient Integrals
            #         #self.Target.reset_phase()
            #         #m=self.Target.excite_Voxels(self.angle) # Excite the target
            #         #if m!=None:
            #             #MyMxy.append(m)
            #             #print('woo')
            #         self.dt=0
            #     #else:
            #         #m=self.Target.recover_Voxels(self.time-self.TRF)
            #         #if m!=None:
            #             #MyMxy.append(m)
            #     # Calculate movement in Kspace due to gradients
            #     Zrot_angle=Zrot_Hf[it+1]-Zrot_Ref
            #     #Zrot_Debug.append(Zrot_angle)
            #     
            #     NewG.set_v(NewG.rotate(1*Zrot_angle*180/np.pi,[0,0,1]))
            #     self.set_G(NewG)
            #     runningKx+=self.dkx
            #     runningKy+=self.dky
            #     NewGx.append(self.G.v[0])
            #     NewGy.append(self.G.v[1])
            #     NewGz.append(self.G.v[2])
            #        
            #     
            #     # if self.oldG.get_v()[0]!=0 or self.G.get_v()[0]!=0:
            #     #     self.GintRF.v[0]+=dkx
            #     # if self.oldG.get_v()[1]!=0 or self.G.get_v()[1]!=0:
            #     #     self.GintRF.v[1]+=dkx                
            #     # if self.oldG.get_v()[2]!=0 or self.G.get_v()[2]!=0:
            #     #     self.GintRF.v[2]+=dkx
            #     
            #     # Update the gradient integrals
            #     self.GintRF.v[0]+=self.dkx
            #     self.GintRF.v[1]+=self.dky                
            #     self.GintRF.v[2]+=self.dkz  
            #     
            #     
            #     # If there is readout

            #         NewTime.append(t-rfpTime)
            #         #Vreal,Vimag,ph=self.CalculateVolume()
            #         #sreal[readstep]=np.sum(Vreal)
            #         #print np.sum(Vreal)
            #         #simag[readstep]=np.sum(Vimag)
            #         #MyPhi.append(ph)
            #         readstep+=1
            #         Kx.append(runningKx)
            #         Ky.append(runningKy)
            #         Zrot_Debug.append(Zrot_angle)
            #     #else:
            #         #ph=self.Calc_TargetPhase()
            #         #MyPhi.append(ph)
            # 
            # print self.TRF
            # # pl.plot(Time,Zrot_Debug)
            # # pl.figure()
            # # pl.plot(Kx,Ky,'-o')
            # # pl.show()
            # np.savetxt('/home/dparker/Desktop/Zrot_ByTime.txt',Zrot_Debug)
            # np.savetxt('/home/dparker/Desktop/Time.txt',NewTime)
            # pl.plot(g1motion)
            # pl.plot(g2motion)
            # pl.plot(g3motion)
            # pl.plot(g4motion)
            # pl.show()
            
            pl.plot(IGX)
            pl.show()
            return g1motion, g2motion,NewGx,NewGy,NewGz,Zrot_Hf
            #return Kx,Ky,NewGx,NewGy,NewGz,Zrot_Hf
            
            # 
            # elif Rotate==None:
            #     print ('Translation only Code')
            #     return []
            # 
            # elif Translate==None:
            #     print('Rotation Only Code')
            #     return []
            # 
            # else:
            #     print('rotation and translation code')
            #     return []





    def ReshapeSig(self,SigReal,SigImag):
            Npts=len(SigReal)
            Nvxl=self.resX*self.resY*self.resZ
            
            if Npts!=Nvxl:
                print'Npts:\t{}\nNvxl:\t{}'.format(Npts,Nvxl)
                return()
            Img=np.zeros(self.Target.obj.shape,'complex')
            
            readCount=0
            xCount=0
            yCount=0
            Xmod=-1
            for y in range(self.resY):
                Xmod=Xmod*-1
                for x in range(self.resX):
                    Img[xCount,y]=SigReal[readCount]+1j*SigImag[readCount]
                    xCount+=Xmod
                    readCount+=1
                if xCount==self.resX:
                    xCount-=1
                elif xCount==-1:
                    xCount+=1
             
    
            return(Img)
    
        



t=np.zeros((112,112,1))
t[5,2,0]=1
# #t[1,1,0]=2
# t[9,9,0]=2

# t[2:8,1,0]=2
# t[5,2,0]=1
# t[2:8,3,0]=2
# 
# t[2,5,0]=2
# t[4:8,5,0]=1
# 
# t[2:6,7,0]=1
# t[8,7,0]=2


def testNewRot():

    tar=Target(t)
    
    NVols=7
    t0=0
    
    baseDir='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord3'
    
    scan=Scanner(3,tar)
    scan.nVolumes=NVols
    Pmat,KxRef,KyRef=scan.CalcPulse()
    MotMat=np.loadtxt(os.path.join(baseDir,'motion'))
    #PyT=scan.PySorter(Pmat, MotMat)
    
    NewPmat=scan.sorter(Pmat, MotMat)
    
    np.savetxt('/home/dparker/Desktop/MyNewPmat.txt',NewPmat)
    baseDir='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord3'
    
    
    tmat=np.loadtxt(baseDir+'/pulse.dmat2')
    fmat=np.loadtxt(baseDir+'/pulse.fmat2')
    fmatRS=np.reshape(fmat,(-1,len(tmat))).T
    tmat=tmat.reshape(1,-1)
    
    MyPmat=np.loadtxt('/home/dparker/Desktop/MyNewPmat.txt')
    print tmat.shape
    print fmatRS.shape
    print MyPmat.shape
    
    MotMat=np.loadtxt(os.path.join(baseDir,'motion'))
    print MotMat.shape
    
    
    
    

    MotTime=MotMat[:,0]
   
    PosxGrad=np.loadtxt(os.path.join(baseDir,'signal_proc_0_Grad1_Mot_ascii'))
    PosyGrad=np.loadtxt(os.path.join(baseDir,'signal_proc_0_Grad2_Mot_ascii'))
    PoszGrad=np.loadtxt(os.path.join(baseDir,'signal_proc_0_Grad3_Mot_ascii'))

    
    pl.plot(fmatRS[:,4])
    pl.plot(NewPmat[:,5])
    pl.title('yaxisGradients')
    pl.figure()
        
    pl.plot(fmatRS[:,5])
    pl.plot(NewPmat[:,6])
    pl.title('yaxisGradients')
    
    pl.show()
    
    
    PoszRot=fmatRS[:,10]
    pl.plot()
    #kx,ky,gx,gy,gz,ZrotHF=scan.CalculateKVector_Zrotation(NewPmat,MotMat)
    kx,ky,gx,gy,gz,ZrotHF=scan.CalculateKVector_Zrotation_New2(NewPmat,MotMat)
    
    pl.plot(np.array(kx)/scan.gamma,'--*')
    pl.plot(PosxGrad,'-')
    pl.legend(['Myg1','Posg1'])
    pl.figure()
    
    pl.plot(np.array(ky)/scan.gamma,'--*')
    pl.plot(PosyGrad,'-')
    pl.legend(['Myg2','Posg2'])
    pl.show()
    
    pl.plot(PoszRot)
    pl.plot(ZrotHF)
    pl.figure()
    pl.plot(PoszRot-ZrotHF)
    pl.show()
    
    
    
    RefKs=np.vstack((KxRef,KyRef))
    np.savetxt('/home/dparker/Desktop/kRef.txt',RefKs)
    MotKs=np.vstack((kx,ky))
    np.savetxt('/home/dparker/Desktop/kMot.txt',MotKs)
    np.savetxt('/home/dparker/Desktop/MyPmat.txt',Pmat)
    
    print('SAVED NEW MOTION FILES')
    
    ###################################################
    # View My Kspace vs Possums Kspace
    ################################################
    
    Myk=np.loadtxt('/home/dparker/Desktop/kMot.txt')
    Posk=np.loadtxt(os.path.join(baseDir,'Kcoord_Mot_ascii'))
    print Myk.shape
    print Posk.shape#
    pl.close()
    # pl.plot(Posk[0])
    # pl.figure()
    # pl.plot(np.diff(Posk[1]))
    inds=np.where(np.abs(np.diff(Posk[1]))>300)
    print inds[0]
    gap=112*112
    for i,ii in enumerate(inds[0]):
        pl.plot(Myk[0,i*gap:ii+1]+600*i,Myk[1,i*gap:ii+1],'*-')
        #pl.plot(Posk[0,i*gap:ii+1]+600*i,Posk[1,i*gap:ii+1],'o--')
    i+=1
    # pl.plot(Myk[0,ii+1:]+600*i,Myk[1,ii+1:],'*-')
    # pl.plot(Posk[0,ii+1:]+600*i,Posk[1,ii+1:],'o--')
    
    pl.show()
    
    
    Myk=Myk[:,0:112*112]
    Posk=Posk[:,0:112*112]
    
    pl.plot(Myk[0],Myk[1],'*-')
    pl.plot(Posk[0],Posk[1],'o--')
    pl.legend(['Calculated Kspace','Possum Kspace'])
    pl.show()
    



def testOld():
        
    
    
    t=np.zeros((10,10))
    t[5,5]=1
    tar=Target(t)
    
    NVols=1
    t0=0
    
    # scan=Scanner(3,tar)
    # scan.nVolumes=NVols
    # Pmat=scan.CalcPulse()
    # MotMat=np.loadtxt('/home/dparker/Desktop/MyOutput/Possum/TestImage12/motion')
    # scan.CalculateKVector_Zrotation(Pmat,MotMat)
    # 
    # Myk=np.loadtxt('/home/dparker/Desktop/My_kCoord.txt')
    # Posk=np.loadtxt('/home/dparker/Desktop/MyOutput/Possum/TestImage12_NoMotion/pulse_kcoord_ascii')
    # 
    # Myk=Myk[:,0:112*112]
    # Posk=Posk[:,0:112*112]
    baseDir='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord3'
    
    scan=Scanner(3,tar)
    scan.nVolumes=NVols
    Pmat,KxRef,KyRef=scan.CalcPulse()
    MotMat=np.loadtxt(os.path.join(baseDir,'motion'))
    #PyT=scan.PySorter(Pmat, MotMat)
    
    NewPmat=scan.sorter(Pmat, MotMat)
    
    np.savetxt('/home/dparker/Desktop/MyNewPmat.txt',NewPmat)
    baseDir='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord3'
    
    
    tmat=np.loadtxt(baseDir+'/pulse.dmat2')
    fmat=np.loadtxt(baseDir+'/pulse.fmat2')
    fmatRS=np.reshape(fmat,(-1,len(tmat))).T
    tmat=tmat.reshape(1,-1)
    
    MyPmat=np.loadtxt('/home/dparker/Desktop/MyNewPmat.txt')
    print tmat.shape
    print fmatRS.shape
    print MyPmat.shape
    
    MotMat=np.loadtxt(os.path.join(baseDir,'motion'))
    print MotMat.shape
    
    
    
    
    # for i in range(fmatRS.shape[-1]):
    #     pl.plot(fmatRS[:,i])
    #     pl.title('i={}'.format(i))
    #     pl.show()
    
    # # # MyTime=MyPmat[:,0]
    # # # PosTime=tmat[0,:]
    # # # 
    MotTime=MotMat[:,0]
    # # # NewMot=np.zeros((np.shape(NewPmat)[0],np.shape(MotMat)[-1]))
    # # # 
    # # # 
    # # # Motz=MotMat[:,-1]
    # # # Moty=MotMat[:,-2]
    # # # Motx=MotMat[:,-3]
    # # # f=ipt.interp1d(MotTime,Motz)
    # # # Newz=f(MyTime)
    # # # 
    # # # f=ipt.interp1d(MotTime,Moty)
    # # # Newy=f(MyTime)
    # # # 
    # # # f=ipt.interp1d(MotTime,Motz)
    # # # Newz=f(MyTime)
    # # # 
    PosxGrad=np.loadtxt(os.path.join(baseDir,'signal_proc_0_Grad1_Mot_ascii'))
    PosyGrad=np.loadtxt(os.path.join(baseDir,'signal_proc_0_Grad2_Mot_ascii'))
    PoszGrad=np.loadtxt(os.path.join(baseDir,'signal_proc_0_Grad3_Mot_ascii'))
    # # # 
    # # # 
    # # # MyxGrad=MyPmat[:,5]
    # # # #PosxGrad=fmatRS[:,4]
    # # # MyyGrad=MyPmat[:,6]
    # # # MyzGrad=MyPmat[:,7]
    # # # 
    # # # 
    # # # 
    # # # 
    # # # # pl.plot(PosTime,'-.')
    # # # # pl.plot(MyTime,'--o')
    # # # # pl.show()
    # # # # 
    # # # # pl.plot(PosTime-MyTime,'-.')
    # # # # pl.show()
    # # # 
    # # # pl.plot(PosTime,PosxGrad,'-.')
    # # # pl.plot(MyTime,MyxGrad,'--o')
    # # # pl.title('X')
    # # # pl.figure()
    # # # pl.plot(PosTime,PosyGrad,'-.')
    # # # pl.plot(MyTime,MyyGrad,'--o')
    # # # pl.title('Y')
    # # # pl.figure()
    # # # pl.plot(PosTime,PoszGrad,'-.')
    # # # pl.plot(MyTime,MyzGrad,'--o')
    # # # pl.title('Z')
    # # # pl.figure()
    # # # pl.plot
    # # # 
    # # # pl.show()
    # # # exit
    # # # pl.plot(PosxGrad-MyxGrad)
    # # # pl.show()
    # # # 
    PoszRot=fmatRS[:,10]
    # # # #pl.plot(PosTime,PoszRot,'-.')
    # # # #pl.plot(MyTime,Newz)
    # # # pl.plot(PoszRot-Newz)
    # # # pl.title('Zrotation')
    # # # pl.show()
    # # # 
    # # # pl.plot(fmatRS[:,14])
    # # # pl.plot(fmatRS[:,10])
    # # # pl.plot(fmatRS[:,16])
    # # # pl.plot(fmatRS[:,17])
    # # # pl.legend(['angle','axis15','axis16','axis17'])
    # # # 
    # # # pl.figure()
    # # # pl.plot(NewPmat[:,5])
    # # # pl.plot(NewPmat[:,6])
    # # # pl.plot(NewPmat[:,7])
    # # # 
    # # # pl.show()
    
    
    
    #kx,ky,gx,gy,gz,ZrotHF=scan.CalculateKVector_Zrotation(NewPmat,MotMat)
    kx,ky,gx,gy,gz,ZrotHF=scan.CalculateKVector_Zrotation(NewPmat,MotMat)
    #kx,ky,gx,gy,gz,ZrotHF=scan.CalculateKVector_Zrotation(NewPmat,MotMat)

    pl.plot(PoszRot)
    pl.plot(ZrotHF)
    pl.figure()
    pl.plot(PoszRot-ZrotHF)
    pl.show()
    
    
    
    RefKs=np.vstack((KxRef,KyRef))
    np.savetxt('/home/dparker/Desktop/kRef.txt',RefKs)
    MotKs=np.vstack((kx,ky))
    np.savetxt('/home/dparker/Desktop/kMot.txt',MotKs)
    np.savetxt('/home/dparker/Desktop/MyPmat.txt',Pmat)
    
    print('SAVED NEW MOTION FILES')
    
    ###################################################
    # View My Kspace vs Possums Kspace
    ################################################
    
    Myk=np.loadtxt('/home/dparker/Desktop/kMot.txt')
    Posk=np.loadtxt(os.path.join(baseDir,'Kcoord_Mot_ascii'))
    print Myk.shape
    print Posk.shape#
    pl.close()
    # pl.plot(Posk[0])
    # pl.figure()
    # pl.plot(np.diff(Posk[1]))
    inds=np.where(np.abs(np.diff(Posk[1]))>300)
    print inds[0]
    gap=112*112
    for i,ii in enumerate(inds[0]):
        pl.plot(Myk[0,i*gap:ii+1]+600*i,Myk[1,i*gap:ii+1],'*-')
        pl.plot(Posk[0,i*gap:ii+1]+600*i,Posk[1,i*gap:ii+1],'o--')
    i+=1
    # pl.plot(Myk[0,ii+1:]+600*i,Myk[1,ii+1:],'*-')
    # pl.plot(Posk[0,ii+1:]+600*i,Posk[1,ii+1:],'o--')
    
    pl.show()
    
    
    Myk=Myk[:,0:112*112]
    Posk=Posk[:,0:112*112]
    
    pl.plot(Myk[0],Myk[1],'*-')
    pl.plot(Posk[0],Posk[1],'o--')
    pl.legend(['Calculated Kspace','Possum Kspace'])
    pl.show()
    
    
    
    
    
    print len(kx)
    Myk=np.loadtxt('/home/dparker/Desktop/My_kCoord.txt')
    Posk=np.loadtxt(os.path.join(baseDir,'pulse_kcoord_ascii'))
    # 
    Myk=Myk[:,0:112*112]
    Posk=Posk[:,0:112*112]
    
    pl.plot(Myk[0],Myk[1],'*-')
    pl.plot(Posk[0],Posk[1],'o--')
    pl.legend(['Calculated Kspace','Possum Kspace'])
    pl.show()
    
    Nii=nb.load(os.path.join(baseDir,'image_abs.nii.gz'))
    data=Nii.get_data()
    hdr=Nii.get_header()
    aff=Nii.get_affine()
    
    RMX,RMY=np.meshgrid(KxRef,KyRef)
    
    
    nx,ny,nz,nt=data.shape
    
    
    nC=np.array([KxRef,KyRef]).T
    NewData=np.zeros(data.shape)
    
    
    
    # for i in range(nt):
    # 
    #     Slice=np.squeeze(data[:,:,:,i])
    #     print Slice.shape
    #     FftSlice=np.fft.fftshift(np.fft.fft2(Slice))
    #     FftSliceImag=np.imag(FftSlice).reshape(-1)
    #     FftSliceReal=np.real(FftSlice).reshape(-1)
    #     #pl.matshow(np.squeeze(np.real(FftSlice)))
    #     #pl.figure()
    #     #pl.matshow(np.squeeze(Slice))
    #     SliceKx=kx[i*nx*ny:(i+1)*nx*ny]
    #     SliceKy=ky[i*nx*ny:(i+1)*nx*ny]
    #     SliceMX,SliceMY=np.meshgrid(SliceKx,SliceKy)
    #     C=np.array([SliceKx,SliceKy]).T
    # 
    #     N=len(FftSliceReal)
    #     Ndim = 2
    #     Nask = N  # N Nask 1e5: 24 sec 2d, 27 sec 3d on mac g4 ppc
    #     Nnear = 4  # 8 2d, 11 3d => 5 % chance one-sided -- Wendel, mathoverflow.com
    #     leafsize = 16
    #     eps = .1  # approximate nearest, dist <= (1 + eps) * true nearest
    #     p = 1  # weights ~ 1 / distance**p
    #     cycle = .25
    #     seed = 1
    # 
    # 
    # #...............................................................................
    #     invdisttree = ivd.Invdisttree( C, FftSliceReal, leafsize=leafsize, stat=1 )
    #     fReal = invdisttree( nC, nnear=Nnear, eps=eps, p=p )   
    #     
    #     invdisttree = ivd.Invdisttree( C, FftSliceImag, leafsize=leafsize, stat=1 )
    #     fImag = invdisttree( nC, nnear=Nnear, eps=eps, p=p )   
    #     #print nz.shape
    # 
    #     # pl.matshow(np.reshape(nz,(nx,ny)))
    #     # pl.show()
    #     
    #     # fReal=ipt.interp2d(SliceKx,SliceKy,np.real(FftSlice),kind='linear',bounds_error=False,fill_value=0)
    #     # fImag=ipt.interp2d(SliceKx,SliceKy,np.imag(FftSlice),kind='linear',bounds_error=False,fill_value=0)
    #     # 
    #     NewFslice=fReal+1j*fImag
    #     
    #     NewFslice=np.reshape(NewFslice,(nx,ny))
    #     
    #     NewSlice=np.abs((np.fft.ifft2(NewFslice)))
    #     NewData[:,:,0,i]=NewSlice
    # 
    #     # pl.figure()
    #     # pl.matshow(np.abs(NewSlice))
    #     # pl.show()
        
        
    NewNii=nb.Nifti1Image(NewData,aff,hdr)
    nb.loadsave.save(NewNii,os.path.join(baseDir,'image_abs_Reconstruct.nii.gz'))
    
    
    
    
    
    # diff=[]
    # for i in range(Myk.shape[-1]):
    #     diff.append(np.sqrt((Myk[0,i]-Posk[0,i])**2+(Myk[1,i]-Posk[1,i])**2))
    # 
    # diff=np.array(diff).reshape(112,112)
    # 
    # X,Y=np.meshgrid(range(112),range(112))
    # 
    # fig=pl.figure()
    # ax=fig.gca(projection='3d')
    # surf=ax.plot_surface(X,Y,diff,cmap=cm.coolwarm,linewidth=1,antialiased=False)
    # pl.show()
    
    
    
    
    # np.savetxt('/home/dparker/Desktop/MyPulse.txt',Pmat)
    # 
    r,c=np.shape(Pmat)
    print np.shape(Pmat)
    pl.figure()
    
    for ic in range(c):
        #pl.figure()
        pl.subplot(c,1,ic+1)
        if ic==0:
            pl.plot(Pmat[:,ic])
        else: 
            pl.plot(Pmat[:,0],Pmat[:,ic])
        pl.title('Pmat Row {}'.format(ic))
        #pl.xlim([0,.035])
    
    pl.figure()
    pl.subplot(3,1,1)
    pl.plot(Pmat[:-1,0],gx)
    pl.subplot(3,1,2)
    pl.plot(Pmat[:-1,0],gy)
    
    pl.subplot(3,1,3)
    pl.plot(Pmat[:-1,0],gz)
    
    
    pl.show()
    tmat=np.loadtxt('/home/dparker/Desktop/MyOutput/Possum/TestImage12_NoMotion/pulse.dmat')
    fmat=np.loadtxt('/home/dparker/Desktop/MyOutput/Possum/TestImage12_NoMotion/pulse.fmat')
    fmatRS=np.reshape(fmat,(-1,len(tmat)))
    tmat=tmat.reshape(1,-1)
    
    pmat2=np.vstack((tmat,fmatRS))
    pmat2=pmat2.T
    pl.figure()
    
    r,c=np.shape(pmat2)
    print np.shape(pmat2)
    
    for ic in range(3,c):
        #pl.figure()
        pl.subplot(c,1,ic+1)
        if ic==0:
            pl.plot(Pmat[:,ic])
            pl.plot(pmat2[:,ic],'o--')
        else:
            pl.plot(Pmat[:,0],Pmat[:,ic],'*-')
            pl.plot(pmat2[:,0],pmat2[:,ic],'o--')
        pl.legend(['Calculated Gradients','PosGradients'])
        pl.title('Pmat Row {}'.format(ic))
        #pl.xlim([0,.035])
    pl.show()
    
    
    # 
    # 
    # #scan.set_G(Vector([.5,0,0]))
    # 
    # rsig,isig,Kx,Ky,ph,mx=scan.CalculateTimeSeries(Pmat)
    # # print rsig
    # # print isig
    # # rsig=range(len(rsig))
    # # isig=np.zeros(len(isig))
    # # rsig[0]=rsig[-1]
    # # rsig[-1]=0
    # # rsig[11]=0
    # # rsig[12]=100
    # print len(ph)
    # rsig=rsig*1e6
    # isig=isig*1e6
    # Sig=scan.ReshapeSig(rsig,isig)
    # #Sig=np.rot90(Sig)
    # pl.matshow(np.abs(Sig[:,:,0]))
    # fSig2D=np.fft.fftshift(np.fft.ifft2(Sig[:,:,0]))
    # 
    # # # print fSig2D
    # # # print np.shape(fSig2D)
    # # pl.matshow((np.abs(fSig2D)))
    # # pl.matshow(t[:,:,0])
    # # 
    # # 
    # # pl.figure()
    # # pl.plot(Kx,Ky)
    # # pl.title('Kspace')
    # # pl.figure()
    # # pl.plot((rsig))
    # # pl.title('realSig')
    # # pl.figure()
    # # pl.plot(ph)
    # # pl.title('phi')
    # # pl.figure()
    # # pl.plot(mx)
    # # pl.title('mxy')
    # # pl.show()
    # 
    # Line1=fSig2D[5,:]
    # 
    # t[5,9,0]=1
    # 
    # tar=Target(t)
    # 
    # NVols=161
    # t0=0
    # 
    # scan=Scanner(3,tar)
    # Pmat=scan.CalcPulse()
    # rsig,isig,Kx,Ky,ph,mx=scan.CalculateTimeSeries(Pmat)
    # rsig=rsig*1e6
    # isig=isig*1e6
    # Sig=scan.ReshapeSig(rsig,isig)
    # pl.matshow(np.abs(Sig[:,:,0]))
    # fSig2D=np.fft.fftshift(np.fft.ifft2(Sig[:,:,0]))
    # Line2=fSig2D[5,:]
    # 
    # t=np.zeros((13,13,1))
    # t[5,9,0]=1
    # 
    # tar=Target(t)
    # 
    # NVols=161
    # t0=0
    # 
    # scan=Scanner(3,tar)
    # Pmat=scan.CalcPulse()
    # rsig,isig,Kx,Ky,ph,mx=scan.CalculateTimeSeries(Pmat)
    # rsig=rsig*1e6
    # isig=isig*1e6
    # Sig=scan.ReshapeSig(rsig,isig)
    # pl.matshow(np.abs(Sig[:,:,0]))
    # fSig2D=np.fft.fftshift(np.fft.ifft2(Sig[:,:,0]))
    # Line3=fSig2D[5,:]
    # 
    # 
    # pl.figure()
    # pl.plot(Line1)
    # pl.plot(Line3)
    # pl.plot(Line2)
    # pl.legend(['Pos1','Pos2','Pos1+2'])
    # 
    # pl.figure()
    # pl.plot((Line1+Line3)-Line2)
    # pl.title('difference')
    # pl.show()
    # 
    # # for it,ir in zip(t,Rotate):
    # #     dt=it-Told
    # # 
    # #     Mxy,Phi=calcMxy(scan.Target.M0[7,0,0],t0,it,scan.Target.T2s[7,0,0],scan.Target.T1[7,0,0],scan,[9,0,0],scan.Target.phi[7,0,0],dt)
    # # 
    # #     Sig.append(Mxy)
    # #     scan.Target.Set_Mxy(Mxy,7,0,0)
    # #     scan.Target.Set_phi(Phi,7,0,0)
    # #     
    # #     Told=it
    # 
    # 
    # 
    # 
    # # pl.plot(np.real(Sig))
    # # pl.figure()
    # # s=np.abs(np.fft.fftshift(np.fft.fft(Sig)))
    # # pl.plot(s)
    # # pl.figure()
    # # # newsig=np.reshape(s,(15,5))
    # # # pl.imshow(newsig)
    # # 
    # # pl.show()
    # 
    # 
    # 
    # 
    # # def calcPhase(gam,dt,G,R,T,s,Phi0=0):
    # # 
    # #     
    # #     Phi=Phi0+gam*np.dot(G,np.dot(R,s)+T)   
    # #     return(Phi)
    # # 
    # # 
    # # def makeRotd(ax,ay,az,theta):
    # #     A=[[0,-az,ay],[az,0,-ax],[-ay,ax,0]]
    # #     R=np.eye(3)+np.sin(theta*np.pi/180)*np.array(A)+(1-np.cos(theta*np.pi/180))*np.dot(A,A)
    # #     return R
    # # 
    # # def calcMxy(Mxy0,t0,t1,T2s,T1,scanner,s,Phi=0,dt=None):
    # #     if dt==None:
    # #         dt=t1-t0    
    # #     gamma=46.6e6   #MHz/T
    # #     
    # #     mm=scanner.Target.cor2mil(s[0],s[1],s[2])
    # # 
    # #     Phi=calcPhase(gamma,dt,scanner.G,scanner.R,scanner.T,mm,Phi)
    # #     Mxy=np.exp(-(t1-t0)/T2s)*np.abs(Mxy0)*np.exp(-1j*Phi)
    # #     return(Mxy,Phi)
    # 
    # 
    # 
    # 
    # 
    #     
    # 
    # # d=45
    # # R=makeRotd(1,0,0,d)
    # # print R
    # # V=np.array([0,1,0])
    # # print np.dot(R,V)

# t=np.zeros((11,11,1))
# t[4:6,4:6,0]=1
# 
# pl.matshow(t[:,:,0])
# 
# tar=Target(t)
# 
# NVols=1
# t0=0
# 
# scan=Scanner(3,tar)
# scan.nVolumes=NVols
# Pmat,KxRef,KyRef=scan.CalcPulse()
# print 'Tmat:{}'.format(np.shape(Pmat))
# print Pmat
# rsig,isig,Kx,Ky,ph,mx=scan.CalculateTimeSeries(Pmat)
# rsig=rsig*1e6
# isig=isig*1e6
# Sig=scan.ReshapeSig(rsig,isig)
# pl.matshow(np.abs(Sig[:,:,0]))
# pl.title('mag kspace')
# 
# pl.matshow(np.real(Sig[:,:,0]))
# pl.title('real kspace')
# 
# pl.matshow(np.imag(Sig[:,:,0]))
# pl.title('imag kspace')
# pl.figure()
# 
# 
# 
# IndADC=np.where(Pmat[:,4]==1)
# print IndADC
# t=Pmat[:,0]
# t=t[IndADC]
# fSig2D=np.fft.fftshift(np.fft.ifft2(Sig[:,:,0]))
# Line3=fSig2D[5,:]
# pl.matshow(np.abs(fSig2D))
# pl.title('mag reconstruction')
# 
# pl.matshow(np.real(fSig2D))
# pl.title('real reconstruction')
# 
# pl.matshow(np.imag(fSig2D))
# pl.title('imag reconstruction')
# 
# #t=Pmat[:,0]
# pl.figure()
# pl.plot(t,rsig,label='real')
# pl.plot(t,isig,label='imag')
# pl.plot(t,np.sqrt(rsig*rsig+isig*isig),label='mag')
# pl.legend()
# 
# pl.figure()
# f,ax=pl.subplots(8,1)
# for i,a in enumerate(ax):
#     a.plot(Pmat[:,i])
# 
# pl.show()





#testOld()

testNewRot()

























