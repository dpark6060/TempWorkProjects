#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb
import scipy.ndimage as spnd
import scipy as scp

basedir='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast'
Img=os.path.join(basedir,'reference.nii.gz')
Nii=nb.load(Img)
Data=Nii.get_data()
Zs=np.loadtxt('/home/dparker/Desktop/Zrot_ByTime.txt')
zi=5
Zs=Zs[0+(zi*12544):12544+zi*12544]
AveCube=np.zeros((16,16))
AveCube[3:13,3:13]=1

time=np.loadtxt('/home/dparker/Desktop/Time.txt')
time=time[0+(zi*12544):12544+zi*12544]
print scp.__version__

#data=spnd.interpolation.rotate(Data,angle=Zs[0]*180/np.pi,reshape=False)

gsCmap=sb.light_palette("black",n_colors=256,as_cmap=True,reverse=True)

ZpadFft=np.zeros((224,224),dtype=complex)


DataFft=np.fft.fft2(Data)
ZpadFft[56:168,56:168]=np.fft.fftshift(DataFft)
ZPFdata=np.fft.ifft2(np.fft.ifftshift((ZpadFft)))
NewDataFft=np.fft.fftshift(np.fft.fft2(ZPFdata,s=(2240,2240)))

##################################################################################3

RefK=np.loadtxt('/home/dparker/Desktop/kRef.txt')
MotK=np.loadtxt('/home/dparker/Desktop/kMot.txt')

Refkx=RefK[0,:]
Refky=RefK[1,:]

Motkx=MotK[0,:]
Motky=MotK[1,:]

zi=5

print np.shape(MotK)
Motkx=Motkx[0+(zi*12544):12544+zi*12544]
Motky=Motky[0+(zi*12544):12544+zi*12544]

print "len Refkx:\t{}".format(len(Refkx))
print "len Motkx:\t{}".format(len(Motkx))
# Refkx=RefK[0,:]
# Refky=RefK[1,:]
# 
# Motkx=MotK[0,:]
# Motky=MotK[1,:]

# pl.plot(Motkx,Motky,'-og')
# pl.plot(Refkx,Refky,'-or')
# pl.show()
IMot=np.vstack((Motkx,Motky)).T
IRef=np.vstack((Refkx,Refky)).T


dkx=Refkx[20]-Refkx[19]
dky=Refky[112]-Refky[111]

didkx=1.0/dkx
didky=1.0/dky

#print dky
# pl.plot(Refky)
# pl.figure()
# pl.plot(Refkx)
# pl.show()

k2ix=didkx*10
k2iy=didky*10
corr=[]
offset=0
#for offset in range(-10,11):

xStart=560+560+offset
yStart=560+560+offset
print k2ix*dkx
print np.amin(Refkx)
print np.amin(Refkx)/dkx


RKReal=np.zeros(len(Refkx))
RKImag=np.zeros(len(Refkx))

CurrentX=xStart
CurrentY=yStart

#NewDataFft=np.zeros((2240,2240))





for i in range(len(Refkx)):
    
    #print [xStart+int(np.round(Refkx[i]*k2ix)),xStart+int(np.round((Refkx[i]+dkx)*k2ix)),yStart+int(np.round(Refky[i]*k2iy)),yStart+int(np.round((Refky[i]+dky)*k2iy))]
    # RKReal[i]=np.mean(np.real(NewDataFft[xStart+int(np.round(Refkx[i]*k2ix)) : xStart+int(np.round((Refkx[i]+dkx)*k2ix)),yStart+int(np.round(Refky[i]*k2iy)) : yStart+int(np.round((Refky[i]+dky)*k2iy))]))
    # RKImag[i]=np.mean(np.imag(NewDataFft[xStart+int(np.round(Refkx[i]*k2ix)) : xStart+int(np.round((Refkx[i]+dkx)*k2ix)),yStart+int(np.round(Refky[i]*k2iy)) : yStart+int(np.round((Refky[i]+dky)*k2iy))]))

    # RKReal[i]=np.real(NewDataFft[xStart+int(np.round((Refkx[i]*k2ix+ (Refkx[i]+dkx)*k2ix)/2)),yStart+int(np.round((Refky[i]*k2iy+(Refky[i]+dky)*k2iy)/2))]) 
    # RKImag[i]=np.imag(NewDataFft[xStart+int(np.round((Refkx[i]*k2ix+ (Refkx[i]+dkx)*k2ix)/2)),yStart+int(np.round((Refky[i]*k2iy+(Refky[i]+dky)*k2iy)/2))])
    

    
   # RKReal[i]=np.real(NewDataFft[xStart+int(np.round((Motkx[i]*k2ix+ (Motkx[i]+dkx)*k2ix)/2)),yStart+int(np.round((Motky[i]*k2iy+(Motky[i]+dky)*k2iy)/2))]) 
   # RKImag[i]=np.imag(NewDataFft[xStart+int(np.round((Motkx[i]*k2ix+ (Motkx[i]+dkx)*k2ix)/2)),yStart+int(np.round((Motky[i]*k2iy+(Motky[i]+dky)*k2iy)/2))])
    
    #////////////////////////////////////////////
    #// Method 2
    #/////////////////////////////////////////////
    
    # realtemp=np.real(NewDataFft[xStart+int(np.round((Refkx[i]*k2ix))),yStart+int(np.round((Refky[i]*k2iy)))])
    # imagtemp=np.imag(NewDataFft[xStart+int(np.round((Refkx[i]*k2ix))),yStart+int(np.round((Refky[i]*k2iy)))])
    # #realtemp=realtemp*np.exp(-1*time[i]/0.05)
    # # cptemp=realtemp+1j*imagtemp
    # # mag=np.abs(cptemp)
    # # phase=np.angle(cptemp)
    # # mag=mag*np.exp((-1*time[i])/0.050)
    # # realtemp=np.cos(phase)*mag
    # # realimag=np.sin(phase)*mag
    # RKReal[i]=realtemp
    # RKImag[i]=imagtemp
    
    RKReal[i]=np.real(NewDataFft[xStart+int(np.round((Motkx[i]*k2ix))),yStart+int(np.round((Motky[i]*k2iy)))]) 
    RKImag[i]=np.imag(NewDataFft[xStart+int(np.round((Motkx[i]*k2ix))),yStart+int(np.round((Motky[i]*k2iy)))])
    # 
    #NewDataFft[xStart+int(np.round(Refkx[i]*k2ix)) : xStart+int(np.round((Refkx[i]+dkx)*k2ix)),yStart+int(np.round(Refky[i]*k2iy)) : yStart+int(np.round((Refky[i]+dky)*k2iy))]=1+i
    
print i
print Zs[i]
# 
# 
# 
# 
# 

# for i in range(len(Refkx)):
#     
#     print [xStart+int(np.round(Refkx[i]*k2ix)),xStart+int(np.round((Refkx[i]+dkx)*k2ix)),yStart+int(np.round(Refky[i]*k2iy)),yStart+int(np.round((Refky[i]+dky)*k2iy))]
#     RKReal[i]=np.mean(np.real(NewDataFft[xStart+int(np.round(Refkx[i]*k2ix)) : xStart+int(np.round((Refkx[i]+dkx)*k2ix)),yStart+int(np.round(Refky[i]*k2iy)) : yStart+int(np.round((Refky[i]+dky)*k2iy))]))
#     RKImag[i]=np.mean(np.imag(NewDataFft[xStart+int(np.round(Refkx[i]*k2ix)) : xStart+int(np.round((Refkx[i]+dkx)*k2ix)),yStart+int(np.round(Refky[i]*k2iy)) : yStart+int(np.round((Refky[i]+dky)*k2iy))]))
#     
#     RKReal[i]=np.real(NewDataFft[xStart+int(np.round((Refkx[i]*k2ix+ (Refkx[i]+dkx)*k2ix)/2)),yStart+int(np.round((Refky[i]*k2iy+(Refky[i]+dky)*k2iy)/2))])
#     RKImag[i]=np.imag(NewDataFft[xStart+int(np.round((Refkx[i]*k2ix+ (Refkx[i]+dkx)*k2ix)/2)),yStart+int(np.round((Refky[i]*k2iy+(Refky[i]+dky)*k2iy)/2))])
#     
#     NewDataFft[xStart+int(np.round(Refkx[i]*k2ix)) : xStart+int(np.round((Refkx[i]+dkx)*k2ix)),yStart+int(np.round(Refky[i]*k2iy)) : yStart+int(np.round((Refky[i]+dky)*k2iy))]=1+i
#     
# print i
# 
RK=RKReal+1j*RKImag


nx=112
ny=112


xDir=1
xCount=0
RK_grid=np.zeros((nx,ny))+1j*np.zeros((nx,ny))
iCount=0
for iy in range(ny):
    
    for ix in range(nx):
        
        RK_grid[xCount,iy]=RK[iCount]
        xCount+=xDir
        iCount+=1
    xDir*=-1
    xCount+=xDir
    
#corr.append(np.correlate(np.ravel(np.abs(RK_grid)),np.ravel(np.abs(np.fft.fftshift(DataFft)))))

#ax=sb.heatmap(np.abs(RK_grid),cmap=gsCmap,cbar=False)

ax=pl.matshow(np.log(np.abs(RK_grid)))
ax.axes.set_title('RK_grid,Offset: {}'.format(offset))
# # #pl.figure()
# # 
# # 
# # #pl.plot(range(-10,11),corr)
# # 
# # #pl.figure()
# # #sb.heatmap(Data,cmap=gsCmap)
# # #pl.figure()
# # #sb.heatmap(np.abs(np.fft.fftshift(DataFft)),cmap=gsCmap,cbar=False)
# # ax=pl.matshow(np.log(np.abs(np.fft.fftshift(DataFft))))
# # pl.title('DataFft')
# # #pl.figure()
# # # sb.heatmap(np.abs(NewData),cmap=gsCmap)
# # # pl.figure()
# # #pl.matshow(np.abs(NewDataFft),cmap=gsCmap,vmin=-10,vmax=10)
# # #pl.figure()
# # pl.matshow(np.abs(np.fft.ifft2(RK_grid)),cmap=gsCmap)
# # pl.title('RK_grid')
# # 
# # pl.matshow(np.squeeze(Data),cmap=gsCmap)
# # pl.title('Original')
# # 
# # pl.matshow(np.abs(np.fft.ifft2(RK_grid))-Data)
# # pl.title('diff')
# # #pl.show()
# # 
# # print Motkx[-1]
# # print Motky[-1]
# # 
# # inds=(np.array(xStart+np.round((Motkx*k2ix)),dtype=int),np.array(yStart+np.round((Motky*k2iy)),dtype=int))
# # #inds=(np.array(xStart+np.round((Refkx*k2ix)),dtype=int),np.array(yStart+np.round((Refky*k2iy)),dtype=int))
# # 
# # # print inds
# # # print inds.shape
# # NewDataFft[inds]=3e5
# # pl.matshow(np.abs(NewDataFft))
# # pl.show()


RK_grid_Image=np.abs(np.fft.ifft2(RK_grid))

MeshRefX,MeshRefY=np.meshgrid(Refkx,Refky)
MeshMotX,MeshMotY=np.meshgrid(Motkx,Motky)
MeshRefX=MeshRefX.reshape(-1)
MeshRefY=MeshRefY.reshape(-1)
MeshMotX=MeshMotX.reshape(-1)
MeshMotY=MeshMotY.reshape(-1)

print np.shape(MeshMotY)
print np.shape(RK_grid.reshape(-1))
print IMot.shape

pl.matshow(np.abs(RK_grid))
pl.show()

ReGridReal=scp.interpolate.griddata(IMot,np.real(RK_grid.reshape(-1)),IRef,method='linear',fill_value=0)
ReGridImag=scp.interpolate.griddata(IMot,np.imag(RK_grid.reshape(-1)),IRef,method='linear',fill_value=0)

# fReal=scp.interpolate.interp2d(Motkx,Motky,np.real(RK_grid.reshape(-1)),kind='linear')
# fImag=scp.interpolate.interp2d(Motkx,Motky,np.imag(RK_grid.reshape(-1)),kind='linear')
#
# ReGridReal=fReal(Refkx,Refky)
# ReGridImag=fImag(Refkx,Refky)


ReGrid=ReGridReal+1j*ReGridImag
ReGrid2D=np.zeros((112,112))+1j*np.zeros((112,112))


ix=0
iy=0

dx=-1
ix=-1
ic=0
for iy in range(112):
    dx*=-1
    ix+=dx
    for ii in range(112):

        ReGrid2D[int(ix),int(iy)]=ReGridReal[ic]+1j*ReGridImag[ic]
        ix+=dx
        ic+=1
        
        
ReGrid2D[0,0]=np.amax(ReGrid2D)
pl.matshow(np.abs(ReGrid2D))
ReGrid_Image=np.abs(np.fft.ifft2(ReGrid2D))
pl.matshow(ReGrid_Image,cmap=gsCmap)
pl.show()











































