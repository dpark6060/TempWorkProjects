#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb
import scipy.ndimage as spnd
import scipy as scp
from matplotlib.colors import LogNorm
from scipy.optimize import minimize
from matplotlib import cm


#gam=42.6e6
gam=42.58e6
gama=2*np.pi*gam

def VecNorm(q):
	x=len(q);
	qsum=np.sum(np.square(q))	
	norm_q=np.sqrt(qsum)
	return norm_q

def Trans(x,y,z):
	Translate=[[1,0,0,x],[0,1,0,y],[0,0,1,z],[0,0,0,1]]
	return Translate

def Rotx(theta):
	rotx_mat=[[1,0,0,0],[0,np.cos(theta),-1*np.sin(theta),0],[0,1*np.sin(theta),np.cos(theta),0],[0,0,0,1]]
	return rotx_mat

def Roty(theta):
	roty_mat=[[np.cos(theta),0,1*np.sin(theta),0],[0,1,0,0],[-1*np.sin(theta),0,np.cos(theta),0],[0,0,0,1]]
	return roty_mat

def Rotz(theta):
	rotz_mat=[[np.cos(theta),-1*np.sin(theta),0,0],[1*np.sin(theta),np.cos(theta),0,0],[0,0,1,0],[0,0,0,1]]
	return rotz_mat


def Combine(MatList):
	Mat=MatList.pop(-1)
	
	while MatList:
		Mat=np.dot(Mat,MatList.pop(-1))
	
	return Mat

def MakeRotMat(rx=0,ry=0,rz=0):
	Rx=Rotx(rx)
	Ry=Roty(ry)
	Rz=Rotz(rz)
	R=Combine([Rx,Ry,Rz])
	return(R)


def axismat(angleaxis):
	# returns A where R = I + sin(angle) A + (1 - cos(angle)) A^2
	axis=angleaxis[1:]
	norm_axis=VecNorm(axis)
	if (abs(norm_axis-1)>1e-12) :
		if (abs(norm_axis)>1e-12):
			axis=np.array(axis)/norm_axis
		
		# else:
		# 	print('Warning in axismatm: Norm of the axis is ZERO!')

	m=np.zeros((3,3))
	m=np.matrix([[0.0,-1*axis[2],axis[1]],
				 [axis[2],0.0,-1*axis[0]],
				 [-1*axis[1],axis[0],0.0]])
		
	return m


def rotmat(angleaxis):
	#// returns R where R = I + sin(angle) A + (1 - cos(angle) A^2
	m=np.zeros((3,3));
	d=np.matrix(np.eye(3));
	A=axismat(angleaxis);
	angle=angleaxis[0];
	m=d+np.sin(angle)*A+(1-np.cos(angle))*A*A;
	
	return m;



def loadPmat(PosDir):
	print "Loading Pmat"
	
	tmatfile=os.path.join(PosDir,'pulse.dmat_mot')
	fmatfile=os.path.join(PosDir,'pulse.fmat_mot')
	RowKeys={'RFOn':0,'RFFlip':1,'RFOther':2,'Read':3,'Xgrad':4,'Ygrad':5,'Zgrad':6,'TransX':7,'TransY':8,'TransZ':9,'Rot':10,'RXax':11,'RYax':12,'RZax':13,'Rotref':14,'RotXref':15,'RotYref':16,'RotZref':17}
	if not os.path.exists(tmatfile):
		tmatfile=os.path.join(PosDir,'pulse.dmat')
		fmatfile=os.path.join(PosDir,'pulse.fmat')
		RowKeys={'RFOn':0,'RFFlip':1,'RFOther':2,'Read':3,'Xgrad':4,'Ygrad':5,'Zgrad':6}
		
		
	tmat=np.loadtxt(tmatfile)
	fmat=np.loadtxt(fmatfile)
	fmatRS=np.reshape(fmat,(-1,len(tmat))).T
	r,c=np.shape(fmatRS)
	print r
	print c
	return(tmat,fmatRS,RowKeys)


# def EstPmatForFile(Nx,Ny,fovX,fovY,te,Xrise=0,Yrise=0,GxMax=0,GyMax=0):
# 	
# 	
# 	
# 	
# 	
# 	
# 	pass



def FindVolStartInds(fmat,RowKeys):
	print "FindVolStartInds"
	rkval='RFFlip'
	inds=np.where(fmat[:,RowKeys[rkval]]>0)
	inds=inds[0]
	return(inds)

def coeff(xold,xnew,told,tnew):#{//needs improvement
	#// return slope and intercept of a line
	#//cout<<"xold="<<xold<<" xnew="<<xnew<<" told="<<told<<" tnew="<<tnew<<" a="<<a<<" b="<<b<<endl;
	if ((tnew-told)>1e-12):
		a=xold-told*(xnew-xold)/(tnew-told)#	//intercept
		b=(xnew-xold)/(tnew-told)#			//slope
	else:
		return(0,0)
	return(a,b)

def i1( gold, gnew, told, tnew):
  #// integral: i1 = \int G(t) dt

  g1=0.0;g2=0.0;
  g1,g2=coeff(gold,gnew,told,tnew)#;               // g1 = Intercept, g2 = Slope
  #//i11=tnew*(g1+g2*tnew/2)-told*(g1+g2*told/2);

#//tejas-changed 26.10.12
  i11=(tnew-told)*g1+(tnew-told)*(tnew+told)*g2/2; # // s*T/m+s^2*T/m
#//tejas-end
  return (i11)

# def I1(t1,t2,a,b):
#     dt=(t2-t1)/2.0
#     i=(a+b)*dt
#     return(i)

def i4(gold,gnew,trold,trnew,told,tnew):
 # // integral: i4 = \int T(t) G(t) dt    : T(t) is translation

  g1,g2=coeff(gold,gnew,told,tnew);
  tr1,tr2=coeff(trold,trnew,told,tnew);
  e=tnew-told;
  a=g1*tr1;
  b=(g1*tr2+g2*tr1)/2;
  c=g2*tr2/3;
  i44=e*(a+e*(b+e*c))+told*e*(2*b+3*c*(e+told));
  
  return(i44)    



def i2(gold,gnew,aold, anew, told,tnew):
	# integral: i2 = \int sin(\alpha(t)) G(t) dt
   
	g1,g2=coeff(gold,gnew,told,tnew);
	
	a1=0.0;a2=0.0;
	a1,a2=coeff(aold,anew,told,tnew);
	#if ((tnew-told)>0.1)cout<<a2<<endl;
	if (abs(a2)*(tnew-told)<0.01):
		i22=(2*g1*np.cos(a2*(tnew-told)/4)*np.sin(a1+a2*(told+tnew)/2)+g2*tnew*np.sin(a1+a2*(3*tnew+told)/4)+g2*told*np.sin(a1+a2*(tnew+3*told)/4))*(np.sinc(a2*(tnew-told)/(4*np.pi))*(tnew-told)/2);#teylor done for sin(o(1e-04)) error expected to be less than 0.0016%
	#i22=sin(a1)*i1(gold,gnew,told,tnew);
	
	else:
		i22=g1*2*(np.sin(a2*(tnew-told)/2)/a2)*np.sin(a1+a2*(tnew+told)/2)+g2*(np.sin(a1)*(tnew*np.sin(a2*tnew)/a2-told*np.sin(a2*told)/a2-2*(np.sin(a2*(tnew-told)/2)/a2)*(np.sin(a2*(tnew+told)/2)/a2))+np.cos(a1)*(-tnew*np.cos(a2*tnew)/a2+told*np.cos(a2*told)/a2+2*(np.sin(a2*(tnew-told)/2)/a2)*(np.cos(a2*(tnew+told)/2)/a2)));
		# if (abs(a2)<0.00001):
		#     print "WARNING check: a2={} i22={}".format(a2,i22)
	#i22=(-(g1+g2*tnew)*cos(a1+a2*tnew)+(g1+g2*told)*cos(a1+a2*told)+(g2*sin(a1+a2*tnew)-g2*sin(a1+a2*told))/a2)/a2;

	
	return i22


def i3( gold, gnew, aold, anew, told, tnew):
	# integral: i3 = \int cos(\alpha(t)) G(t) dt
	
	g1,g2=coeff(gold,gnew,told,tnew);
	a1,a2=coeff(aold,anew,told,tnew);
	if (abs(a2)*(tnew-told)<0.01):
		i33=(2*g1*np.cos(a2*(tnew-told)/4)*np.cos(a1+a2*(told+tnew)/2)+g2*tnew*np.cos(a1+a2*(3*tnew+told)/4)+g2*told*np.cos(a1+a2*(tnew+3*told)/4))*(np.sinc(a2*(tnew-told)/(4*np.pi))*(tnew-told)/2);#teylor done for sin(o(1e-04))
	#i33=np.cos(a1)*i1(gold,gnew,told,tnew);

	else:
		i33=g1*2*(np.sin(a2*(tnew-told)/2)/a2)*np.cos(a1+a2*(tnew+told)/2)+g2*(np.sin(a1)*(tnew*np.cos(a2*tnew)/a2-told*np.cos(a2*told)/a2-2*(np.sin(a2*(tnew-told)/2)/a2)*(np.cos(a2*(tnew+told)/2)/a2))+np.cos(a1)*(tnew*np.sin(a2*tnew)/a2-told*np.sin(a2*told)/a2-2*(np.sin(a2*(tnew-told)/2)/a2)*(np.sin(a2*(tnew+told)/2)/a2)));
	# if (abs(a2)<0.00001):
	#     print "WARNING check: a2={} i33={}".format(a2,i33)
	#i33=((g1+g2*tnew)*np.sin(a1+a2*tnew)-(g1+g2*told)*sin(a1+a2*told)+(g2*np.cos(a1+a2*tnew)-g2*cos(a1+a2*told))/a2)/a2;
	
	return i33






def I(h,r1,r2,g):
	##Matrix M=rotmat(r2);
	M=rotmat(r2)  #; // current rotation
	A=axismat(r1) #; // control point rotation
	AM=A*M;
	A2M=A*AM;
	v=g[0,:]*M[:,h]+g[1,:]*AM[:,h]+g[2,:]*A2M[:,h]
	#print v
	return v[0,0]








def CalcKspace(tmat,fmat,RowKeys,VolStartInds,Voln=0):
	gx='Xgrad'
	gy='Ygrad'
	gz='Zgrad'

	Xgrad=fmat[:,RowKeys[gx]]
	Ygrad=fmat[:,RowKeys[gy]]
	
	Lvol=12886
	vi=VolStartInds[Voln]
	
	Kx=[]
	Ky=[]
	x=0
	y=0
	
	
	
	for v in range(vi,vi+Lvol):
		
		t1=tmat[v]
		t2=tmat[v+1]
		
		ax=Xgrad[v]
		bx=Xgrad[v+1]
		
		ay=Ygrad[v]
		by=Ygrad[v+1]
		
		ix=I1(t1,t2,ax,bx)
		iy=I1(t1,t2,ay,by)
		
		x=x+ix
		y=y+iy
		
		Kx.append(x*gam)
		Ky.append(y*gam)
		
	return(Kx,Ky)
		

def CalcGrad_Trans_Effect_new(tmat,fmat,RowKeys,VolStartInds):
	
	xdim=0.224
	ydim=0.224
	zdim=0.004
	
	glo_cx=gam*xdim; #Hz*m/T)
	glo_cy=gam*ydim;
	glo_cz=gam*zdim;
	
	rf='RFOn'
	
	tx='TransX'
	ty='TransY'
	tz='TransZ'
	gx='Xgrad'
	gy='Ygrad'
	gz='Zgrad'
	
	rot='Rot'
	
	rx='RXax'
	ry='RYax'
	rz='RZax'
	
	#'Rotref':14,'RotXref':15,'RotYref':16,'RotZref':17
	refrot='Rotref'
	refx='RotXref'
	refy='RotYref'
	refz='RotZref'
	
	
	RF=fmat[:,RowKeys[rf]]
	
	GradX=fmat[:,RowKeys[gx]]
	GradY=fmat[:,RowKeys[gy]]
	GradZ=fmat[:,RowKeys[gz]]
	
	TransX=fmat[:,RowKeys[tx]]
	TransY=fmat[:,RowKeys[ty]]
	TransZ=fmat[:,RowKeys[tz]]
	
	RefRotMag=fmat[:,RowKeys[refrot]]
	refXax=fmat[:,RowKeys[refx]]
	refYax=fmat[:,RowKeys[refy]]
	refZax=fmat[:,RowKeys[refz]]    
	
	refXax=np.multiply(refXax,RefRotMag)
	refYax=np.multiply(refYax,RefRotMag)
	refZax=np.multiply(refZax,RefRotMag)
	
	RotMag=fmat[:,RowKeys[rot]]
	RotXax=fmat[:,RowKeys[rx]]
	RotYax=fmat[:,RowKeys[ry]]
	RotZax=fmat[:,RowKeys[rz]]
	
	
	
	
	dt=np.diff(tmat)
	#dt=1
	dTransX=np.diff(TransX)*dt
	dTransY=np.diff(TransY)*dt
	dTransZ=np.diff(TransZ)*dt
	# dTransX=fmat[:,RowKeys[tx]]
	# dTransY=fmat[:,RowKeys[ty]]  
	# dTransZ=fmat[:,RowKeys[tz]]

	GTx=np.zeros(len(GradX))
	GTy=np.zeros(len(GradX))
	GTz=np.zeros(len(GradX))

	kx=np.zeros(len(GradX))
	ky=np.zeros(len(GradX))    
	
	
	cgtx=0
	cgty=0
	cgtz=0
	othercgtx=0
	
	GSx=0
	GSy=0
	GSz=0
	
	g1=0
	g2=0
	g3=0
	
	g=np.matrix(np.zeros((4,3)))

	gtrans=np.matrix(np.zeros((4,3)))
	
	print range(len(VolStartInds)-1)
	for vi in range(len(VolStartInds)-1):
		

		
		vend=VolStartInds[vi+1]-1
		GSx=g1
		GSy=g2
		GSz=g3
		
		
	  
		for i in range(VolStartInds[vi]+1,vend):
			
			
			gxnew=GradX[i]
			gxold=GradX[i-1]
			
			gynew=GradY[i]
			gyold=GradY[i-1]
			gznew=GradZ[i]
			gzold=GradZ[i-1]

			told=tmat[i-1]
			tnew=tmat[i]
			
			aold=RotMag[i-1]
			anew=RotMag[i]
			
			troldx=TransX[i-1]
			trnewx=TransX[i]
			#print trnewx
	
			troldy=TransY[i-1]
			trnewy=TransY[i]
			
			troldz=TransZ[i-1]
			trnewz=TransZ[i]
			
			rnew=[RotMag[i],RotXax[i],RotYax[i],RotZax[i]]
			rmnew=[RefRotMag[i],refXax[i],refYax[i],refZax[i]]#<H(step,16)<<H(step,17)<<H(step,18)<<H(step,19);//rotation at control motion point at tnew (angle & axis)
			
			
			
			
			g[0,0]=g[0,0]+i1(gxold,gxnew,told,tnew);
			g[1,0]=g[1,0]+i2(gxold,gxnew,aold,anew,told,tnew);
			
			#a1,a2=coeff(aold,anew,told,tnew)            
			g[2,0]=g[2,0]+i1(gxold,gxnew,told, tnew)- i3(gxold,gxnew,aold,anew,told,tnew);            
			g[3,0]=g[3,0]+i4(gxold,gxnew,troldx,trnewx,told,tnew);
			gtrans[3,0]=gtrans[3,0]+i4(gxold,gxnew,troldx,trnewx,told,tnew);
			
			if (gyold!=0 or gynew!=0):
				g[0,1]=g[0,1]+i1(gyold,gynew,told,tnew);
				g[1,1]=g[1,1]+i2(gyold,gynew,aold,anew,told,tnew);
				
				#a1,a2=coeff(aold,anew,told,tnew)            
				g[2,1]=g[2,1]+i1(gyold,gynew,told, tnew)- i3(gyold,gynew,aold,anew,told,tnew);            
				g[3,1]=g[3,1]+i4(gyold,gynew,troldy,trnewy,told,tnew);
				gtrans[3,1]=gtrans[3,1]+i4(gyold,gynew,troldy,trnewy,told,tnew);
				
			if (gzold!=0 or gznew!=0):
				g[0,2]=g[0,2]+i1(gzold,gznew,told,tnew);
				g[1,2]=g[1,2]+i2(gzold,gznew,aold,anew,told,tnew);
				
				#a1,a2=coeff(aold,anew,told,tnew)            
				g[2,2]=g[2,2]+i1(gzold,gznew,told, tnew)- i3(gzold,gznew,aold,anew,told,tnew);            
				g[3,2]=g[3,2]+i4(gzold,gznew,troldz,trnewz,told,tnew);
				gtrans[3,2]=gtrans[3,2]+i4(gzold,gznew,troldz,trnewz,told,tnew);
			#Matrix R(3,3);
			#Matrix A(3,3);
			#R=rotmat(rmnew);//control matrix, changes only when the axis changes 
			#A=axismat(rnew);//moving matrix, controls rotation between control matrices

			
			g1=I(0,rnew,rmnew,g);
			g2=I(1,rnew,rmnew,g);
			g3=I(2,rnew,rmnew,g);
			
			g1trans=I(0,rnew,rmnew,gtrans)
			g2trans=I(1,rnew,rmnew,gtrans)
			g3trans=I(2,rnew,rmnew,gtrans)
			
			ix=i4(gxold,gxnew,troldx,trnewx,told,tnew)
			othercgtx=othercgtx+ix*gam
			#print GradX[i]*dt[i]
			#GSx=GSx+GradX[i]
			GTx[i]=cgtx    
			# 
			# if troldx!=0:
			# #     
			#     print g
			#     print g1
			#     print g[3,0]*gam
			#     print othercgtx
			# 

			
			gg1=g1-GSx
			gg2=g2-GSy
			gg3=g3-GSz
			
			kx[i]=gg1*gam
			ky[i]=gg2*gam
			
			
			# GSx=g1
			# GSy=g2
			# GSz=g3

			#cgtx=cgtx+gg1*gam
			cgtx=g[3,0]*gam
			GTx[i]=cgtx

			#cgty=cgty+gg2*gam
			cgty=g[3,1]*gam
			GTy[i]=cgty
			
			#cgtz=cgtz+gg3*gam
			cgtz=g[3,2]*gam
			GTz[i]=cgtz
		



	vi=VolStartInds[-1]+1
	cgtx=0
	cgty=0
	cgtz=0
	
	for i in range(vi,len(GradX)-1):

		gxnew=GradX[i]
		gxold=GradX[i-1]
		gynew=GradY[i]
		gyold=GradY[i-1]
		gznew=GradZ[i]
		gzold=GradZ[i-1]

		told=tmat[i-1]
		tnew=tmat[i]
		
		aold=RotMag[i-1]
		anew=RotMag[i]
		
		troldx=TransX[i-1]
		trnewx=TransX[i]

		troldy=TransY[i-1]
		trnewy=TransY[i]
		
		troldz=TransZ[i-1]
		trnewz=TransZ[i]
		
		rnew=[RotMag[i],RotXax[i],RotYax[i],RotZax[i]]
		rmnew=[RefRotMag[i],refXax[i],refYax[i],refZax[i]]#<H(step,16)<<H(step,17)<<H(step,18)<<H(step,19);//rotation at control motion point at tnew (angle & axis)
		
		
		
		
		g[0,0]=g[0,0]+i1(gxold,gxnew,told,tnew);
		g[1,0]=g[1,0]+i2(gxold,gxnew,aold,anew,told,tnew);
		
		#a1,a2=coeff(aold,anew,told,tnew)            
		g[2,0]=g[2,0]+i1(gxold,gxnew,told, tnew)- i3(gxold,gxnew,aold,anew,told,tnew);            
		g[3,0]=g[3,0]+i4(gxold,gxnew,troldx,trnewx,told,tnew);
	   
		if (gyold!=0 or gynew!=0):
			g[0,1]=g[0,1]+i1(gyold,gynew,told,tnew);
			g[1,1]=g[1,1]+i2(gyold,gynew,aold,anew,told,tnew);
			
			#a1,a2=coeff(aold,anew,told,tnew)            
			g[2,1]=g[2,1]+i1(gyold,gynew,told, tnew)- i3(gyold,gynew,aold,anew,told,tnew);            
			g[3,1]=g[3,1]+i4(gyold,gynew,troldy,trnewy,told,tnew);
		
		if (gzold!=0 or gznew!=0):
			g[0,2]=g[0,2]+i1(gzold,gznew,told,tnew);
			g[1,2]=g[1,2]+i2(gzold,gznew,aold,anew,told,tnew);
			
			#a1,a2=coeff(aold,anew,told,tnew)            
			g[2,2]=g[2,2]+i1(gzold,gznew,told, tnew)- i3(gzold,gznew,aold,anew,told,tnew);            
			g[3,2]=g[3,2]+i4(gzold,gznew,troldz,trnewz,told,tnew);
			
			
		
		#Matrix R(3,3);
		#Matrix A(3,3);
		#R=rotmat(rmnew);//control matrix, changes only when the axis changes 
		#A=axismat(rnew);//moving matrix, controls rotation between control matrices
		g1=I(0,rnew,rmnew,g);
		g2=I(1,rnew,rmnew,g);
		g3=I(2,rnew,rmnew,g);
		
		
		
		
		
		gg1=g1-GSx
		gg2=g2-GSy
		gg3=g3-GSz
		
		# GSx=g1
		# GSy=g2
		# GSz=g3
		
		kx[i]=gg1*gam
		ky[i]=gg2*gam
		
		#cgtx=cgtx+gg1*gam
		cgtx=g[3,0]*gam
		GTx[i]=cgtx

		#cgty=cgty+gg2*gam
		cgty=g[3,1]*gam
		GTy[i]=cgty
		
		#cgtz=cgtz+gg3*gam
		cgtz=g[3,2]*gam
		GTz[i]=cgtz

		
	
	
   
	return(GTx,GTy,GTz,np.array(kx),np.array(ky))


def CalcGrad_Trans_Effect(tmat,fmat,RowKeys,VolStartInds):
	
	tx='TransX'
	ty='TransY'
	tz='TransZ'
	gx='Xgrad'
	gy='Ygrad'
	gz='Zgrad'
	
	rot='Rot'
	
	rx='RXax'
	ry='RYax'
	rz='RZax'
	
	#'Rotref':14,'RotXref':15,'RotYref':16,'RotZref':17
	refrot='Rotref'
	refx='RotXref'
	refy='RotYref'
	refz='RotZref'
	
	
	GradX=fmat[:,RowKeys[gx]]
	GradY=fmat[:,RowKeys[gy]]
	GradZ=fmat[:,RowKeys[gz]]
	TransX=fmat[:,RowKeys[tx]]
	TransY=fmat[:,RowKeys[ty]]
	TransZ=fmat[:,RowKeys[tz]]
	
	RefRotMag=fmat[:,RowKeys[refrot]]
	refXax=fmat[:,RowKeys[refx]]
	refYax=fmat[:,RowKeys[refy]]
	refZax=fmat[:,RowKeys[refz]]    
	
	refXax=np.multiply(refXax,RefRotMag)
	refYax=np.multiply(refYax,RefRotMag)
	refZax=np.multiply(refZax,RefRotMag)
	
	RotMag=fmat[:,RowKeys[rot]]
	RotXax=fmat[:,RowKeys[rx]]
	RotYax=fmat[:,RowKeys[ry]]
	RotZax=fmat[:,RowKeys[rz]]
	
	
	
	
	dt=np.diff(tmat)
	#dt=1
	dTransX=np.diff(TransX)*dt
	dTransY=np.diff(TransY)*dt
	dTransZ=np.diff(TransZ)*dt
	# dTransX=fmat[:,RowKeys[tx]]
	# dTransY=fmat[:,RowKeys[ty]]  
	# dTransZ=fmat[:,RowKeys[tz]]

	GTx=np.zeros(len(GradX))
	GTy=np.zeros(len(GradX))
	GTz=np.zeros(len(GradX))
	
	
	
	print range(len(VolStartInds)-1)
	for vi in range(len(VolStartInds)-1):
		
		vend=VolStartInds[vi+1]-1
		cgtx=0
		cgty=0
		cgtz=0
		
		GSx=0
		GSy=0
		GSz=0
		
		
		
	  
		for i in range(VolStartInds[vi]+1,vend):
			
			Grad1=np.matrix([GradX[i-1],GradY[i-1],GradZ[i-1],0])
			Grad2=np.matrix([GradX[i],GradY[i],GradZ[i],0])
			
			Rots1=np.array([RotXax[i-1],RotYax[i-1],RotZax[i-1]])*RotMag[i-1]
			Rots2=np.array([RotXax[i],RotYax[i],RotZax[i]])*RotMag[i]
			Rot1=MakeRotMat(Rots1[0],Rots1[1],Rots1[2])
			Rot2=MakeRotMat(Rots2[0],Rots2[1],Rots2[2])  
			# Rot1=MakeRotMat(Rots1[0]+refXax[i-1],Rots1[1]+refYax[i-1],Rots1[2]+refZax[i-1])
			# Rot2=MakeRotMat(Rots2[0]+refXax[i],Rots2[1]+refYax[i],Rots2[2]+refZax[i])
			# 
			# Rot1=MakeRotMat(Rots1[0],Rots1[1],Rots1[2])
			# Rot2=MakeRotMat(Rots2[0],Rots2[1],Rots2[2])            
			#print Rot1.shape
			# print Grad2
			# print Grad2[0,2]
			# if Rots1[2]!=0:
			#     print Grad1
			
			Grad1=Grad1*Rot1
			Grad2=Grad2*Rot2
			
			
			# Rot1=MakeRotMat(Rots1[0]+refXax[i-1],Rots1[1]+refYax[i-1],Rots1[2]+refZax[i-1])
			# Rot2=MakeRotMat(Rots2[0]+refXax[i],Rots2[1]+refYax[i],Rots2[2]+refZax[i])              
			# Rot1=MakeRotMat(Rots1[0],Rots1[1],Rots1[2])
			# Rot2=MakeRotMat(Rots2[0],Rots2[1],Rots2[2])  
			
			Trans1=np.matrix([TransX[i-1],TransY[i-1],TransZ[i-1],0])
			Trans2=np.matrix([TransX[i],TransY[i],TransZ[i],0])
			
			Trans1=Trans1#*Rot1
			Trans2=Trans2#*Rot2
			# if Rots1[2]!=0:
			#     print Grad1
				
			# #if GradX[i]!=0: #and TransX[i]!=0:
			# g2=Grad2[0,0]
			# g1=Grad1[0,0]
			# tr2=TransX[i]
			# tr1=TransX[i-1]
			# t2=tmat[i]
			# t1=tmat[i-1]
			# ix=i4(g1,g2,tr1,tr1,t1,t2)
			# cgtx=cgtx+ix*gam
			# #print GradX[i]*dt[i]
			# #GSx=GSx+GradX[i]
			# GTx[i]=cgtx
			# 
			# #if GradY[i]!=0:# and TransY[i]!=0:
			# g1=Grad1[0,1]
			# g2=Grad2[0,1]
			# tr1=TransY[i-1]
			# tr2=TransY[i]
			# t1=tmat[i-1]
			# t2=tmat[i]
			# iy=i4(g1,g2,tr1,tr1,t1,t2)
			# cgty=cgty+iy*gam
			# #print GradX[i]*dt[i]
			# #GSy=GSy+GradX[i]
			# GTy[i]=cgty
			# 
			# g1=Grad1[0,2]
			# g2=Grad2[0,2]
			# tr1=TransZ[i]
			# tr2=TransZ[i-1]
			# t1=tmat[i]
			# t2=tmat[i-1]
			# iz=i4(g1,g2,tr1,tr1,t1,t2)
			# cgtz=cgtz+iz*gam
			# #print GradX[i]*dt[i]
			# #GSz=GSz+GradX[i]
			# GTz[i]=cgtz
			
			
			
# #if GradX[i]!=0: #and TransX[i]!=0:
#             g2=GradX[i]
#             g1=GradX[i-1]
#             tr2=TransX[i]
#             tr1=TransX[i-1]
#             t2=tmat[i]
#             t1=tmat[i-1]
#             ix=i4(g1,g2,tr1,tr1,t1,t2)
#             cgtx=cgtx+ix*gam
#             #print GradX[i]*dt[i]
#             #GSx=GSx+GradX[i]
#             GTx[i]=cgtx
#             
#             #if GradY[i]!=0:# and TransY[i]!=0:
#             g1=GradY[i-1]
#             g2=GradY[i]
#             tr2=TransY[i]
#             tr1=TransY[i-1]
#             t1=tmat[i-1]
#             t2=tmat[i]
#             iy=i4(g1,g2,tr1,tr1,t1,t2)
#             cgty=cgty+iy*gam
#             #print GradX[i]*dt[i]
#             #GSy=GSy+GradX[i]
#             GTy[i]=cgty
#             
#             g1=GradZ[i]
#             g2=GradZ[i-1]
#             tr1=TransZ[i]
#             tr2=TransZ[i-1]
#             t1=tmat[i-1]
#             t2=tmat[i]
#             iz=i4(g1,g2,tr1,tr1,t1,t2)
#             cgtz=cgtz+iz*gam
#             #print GradX[i]*dt[i]
#             #GSz=GSz+GradX[i]
#             GTz[i]=cgtz



#if GradX[i]!=0: #and TransX[i]!=0:
			g2=Grad2[0,0]
			g1=Grad1[0,0]
			tr2=Trans2[0,0]
			tr1=Trans1[0,0]
			t2=tmat[i]
			t1=tmat[i-1]
			ix=i4(g1,g2,tr1,tr2,t1,t2)
			cgtx=cgtx+ix*gam
			#print GradX[i]*dt[i]
			#GSx=GSx+GradX[i]
			GTx[i]=cgtx
			
			#if GradY[i]!=0:# and TransY[i]!=0:
			g1=Grad1[0,1]
			g2=Grad2[0,1]
			tr2=Trans2[0,1]
			tr1=Trans1[0,1]
			t1=tmat[i-1]
			t2=tmat[i]
			iy=i4(g1,g2,tr1,tr2,t1,t2)
			cgty=cgty+iy*gam
			#print GradX[i]*dt[i]
			#GSy=GSy+GradX[i]
			GTy[i]=cgty
			
			g1=Grad1[0,2]
			g2=Grad2[0,2]
			tr1=Trans1[0,2]
			tr2=Trans2[0,2]
			t1=tmat[i-1]
			t2=tmat[i]
			iz=i4(g1,g2,tr1,tr2,t1,t2)
			cgtz=cgtz+iz*gam
			#print GradX[i]*dt[i]
			#GSz=GSz+GradX[i]
			GTz[i]=cgtz




	vi=VolStartInds[-1]+1
	cgtx=0
	cgty=0
	cgtz=0
	
	for i in range(vi,len(GradX)-1):
		# g2=GradX[i]
		# g1=GradX[i-1]
		# tr2=TransX[i]
		# tr1=TransX[i-1]
		# t2=tmat[i]
		# t1=tmat[i-1]
		# ix=i4(g1,g2,tr1,tr1,t1,t2)
		# cgtx=cgtx+ix*gam
		# #print GradX[i]*dt[i]
		# #GSx=GSx+GradX[i]
		# GTx[i]=cgtx
		# 
		# #if GradY[i]!=0:# and TransY[i]!=0:
		# g1=GradY[i]
		# g2=GradY[i-1]
		# tr1=TransY[i]
		# tr2=TransY[i-1]
		# t1=tmat[i]
		# t2=tmat[i-1]
		# iy=i4(g1,g2,tr1,tr1,t1,t2)
		# cgty=cgty+iy*gam
		# #print GradX[i]*dt[i]
		# #GSy=GSy+GradX[i]
		# GTy[i]=cgty
		# 
		# g1=GradZ[i]
		# g2=GradZ[i-1]
		# tr1=TransZ[i]
		# tr2=TransZ[i-1]
		# t1=tmat[i]
		# t2=tmat[i-1]
		# iz=i4(g1,g2,tr1,tr1,t1,t2)
		# cgtz=cgtz+iz*gam
		# #print GradX[i]*dt[i]
		# #GSz=GSz+GradX[i]
		# GTz[i]=cgtz
		g2=Grad2[0,0]
		g1=Grad1[0,0]
		tr2=TransX[i]
		tr1=TransX[i-1]
		t2=tmat[i]
		t1=tmat[i-1]
		ix=i4(g1,g2,tr1,tr1,t1,t2)
		cgtx=cgtx+ix*gam
		#print GradX[i]*dt[i]
		#GSx=GSx+GradX[i]
		GTx[i]=cgtx
		
		#if GradY[i]!=0:# and TransY[i]!=0:
		g1=Grad1[0,1]
		g2=Grad2[0,1]
		tr2=TransY[i]
		tr1=TransY[i-1]
		t1=tmat[i-1]
		t2=tmat[i]
		iy=i4(g1,g2,tr1,tr1,t1,t2)
		cgty=cgty+iy*gam
		#print GradX[i]*dt[i]
		#GSy=GSy+GradX[i]
		GTy[i]=cgty
		
		g1=Grad1[0,2]
		g2=Grad2[0,2]
		tr1=TransZ[i]
		tr2=TransZ[i-1]
		t1=tmat[i-1]
		t2=tmat[i]
		iz=i4(g1,g2,tr1,tr1,t1,t2)
		cgtz=cgtz+iz*gam
		#print GradX[i]*dt[i]
		#GSz=GSz+GradX[i]
		GTz[i]=cgtz

			
	
	
   
	return(GTx,GTy,GTz)

def CalcGrad_Trans_Effect_old(tmat,fmat,RowKeys,VolStartInds):
	
	tx='TransX'
	ty='TransY'
	tz='TransZ'
	gx='Xgrad'
	gy='Ygrad'
	gz='Zgrad'
	
	GradX=fmat[:,RowKeys[gx]]
	GradY=fmat[:,RowKeys[gy]]
	GradZ=fmat[:,RowKeys[gz]]
	TransX=fmat[:,RowKeys[tx]]
	TransY=fmat[:,RowKeys[ty]]
	TransZ=fmat[:,RowKeys[tz]]
	
	dt=np.diff(tmat)
	dt=1
	dTransX=np.diff(TransX)*dt
	dTransY=np.diff(TransY)*dt
	dTransZ=np.diff(TransZ)*dt
	# dTransX=fmat[:,RowKeys[tx]]
	# dTransY=fmat[:,RowKeys[ty]]
	# dTransZ=fmat[:,RowKeys[tz]]
	
		
	GTx=np.zeros(len(GradX))
	GTy=np.zeros(len(GradX))
	GTz=np.zeros(len(GradX))
	
	print range(len(VolStartInds)-1)
	for vi in range(len(VolStartInds)-1):
		
		vend=VolStartInds[vi+1]-1
		cgtx=0
		cgty=0
		cgtz=0
		for i in range(VolStartInds[vi]+1,vend):
			if GradX[i]!=0: #and TransX[i]!=0:
				cgtx=cgtx+dTransX[i]
			GTx[i]=cgtx
			
			if GradY[i]!=0:# and TransY[i]!=0:
				cgty=cgty+dTransY[i]
			GTy[i]=cgty
			
			if GradZ[i]!=0:# and TransZ[i]!=0:
				cgtz=cgtz+dTransZ[i]
			GTz[i]=cgtz 
	
	vi=VolStartInds[-1]+1
	cgtx=0
	cgty=0
	cgtz=0
	
	for i in range(vi,len(GradX)-1):
			if GradX[i]!=0: #and TransX[i]!=0:
				cgtx=cgtx+dTransX[i]
			GTx[i]=cgtx
			
			if GradY[i]!=0:# and TransY[i]!=0:
				cgty=cgty+dTransY[i]
			GTy[i]=cgty
			
			if GradZ[i]!=0:# and TransZ[i]!=0:
				cgtz=cgtz+dTransZ[i]
			GTz[i]=cgtz   
	
	
   
	return(GTx,GTy,GTz)

def FindReadIdxs(fmat,RowKeys,VolStartInds):
	print "FindReadInds"
	read='Read'
	Read=fmat[:,RowKeys[read]]
	
	#SliceInds=[]
	VolReadInds=[]
	for vi in range(len(VolStartInds)-1):
		ReadInds=[]
		idxStart=VolStartInds[vi]
		idxStop=VolStartInds[vi+1]
		
		#slcind=range(VolStartInds[vi]+1,ColStartInds[vi+1]-1)
		MyChunk=Read[idxStart:idxStop]
		
		inds=np.where(MyChunk==1)
		inds=inds[0]
		inds=inds+idxStart
		#SliceInds.append(slcind)
		VolReadInds.append(inds)
	
	print np.shape(Read)
	print np.shape(VolStartInds)
	print VolStartInds[-1]
	
	MyChunk=Read[VolStartInds[-1]:]
	inds=np.where(MyChunk==1)
	inds=inds[0]
	inds=inds+VolStartInds[-1]
	VolReadInds.append(inds)
	#SliceInds.append(range(VolStartInds[-1]+1,len(Read)-1))
	
	return(VolReadInds)#, SliceInds)

def ExtractMotParFromRead_old(fmat,RowKeys,VolNum,VolReadInds):
	print "ExtractMotParFromRead"

	
	
	tx='TransX'
	ty='TransY'
	tz='TransZ'
	rx='RotX'
	ry='RotY'
	rz='RotZ'
	gx='Xgrad'
	gy='Ygrad'
	gz='Zgrad'
	
	
	ReadInds=VolReadInds[VolNum]
	
	TransX=fmat[ReadInds,RowKeys[tx]]
	TransY=fmat[ReadInds,RowKeys[ty]]
	TransZ=fmat[ReadInds,RowKeys[tz]]
	
	RotX=fmat[ReadInds,RowKeys[rx]]
	RotY=fmat[ReadInds,RowKeys[ry]]
	RotZ=fmat[ReadInds,RowKeys[rz]]
	
	GradX=fmat[ReadInds,RowKeys[gx]]
	GradY=fmat[ReadInds,RowKeys[gy]]
	GradZ=fmat[ReadInds,RowKeys[gz]]

	
	return(np.array(TransX),np.array(TransY),np.array(TransZ),np.array(RotX),np.array(RotY),np.array(RotZ))


def ExtractMotParFromRead(fmat,RowKeys,VolNum,VolReadInds,GTx,GTy,GTz,tmat=0):
	print "ExtractMotParFromRead"

	
	
	tx='TransX'
	ty='TransY'
	tz='TransZ'
	gx='Xgrad'
	gy='Ygrad'
	gz='Zgrad'
	
	rot='Rot'
	
	rx='RXax'
	ry='RYax'
	rz='RZax'
	
	
	
	RotMag=fmat[:,RowKeys[rot]]
	RotXax=fmat[:,RowKeys[rx]]
	RotYax=fmat[:,RowKeys[ry]]
	RotZax=fmat[:,RowKeys[rz]]
	
	RotX=np.multiply(RotMag,RotXax)
	RotY=np.multiply(RotMag,RotYax)
	RotZ=np.multiply(RotMag,RotZax)
	
	ReadInds=VolReadInds[VolNum]
	
	TransX=fmat[ReadInds,RowKeys[tx]]
	TransY=fmat[ReadInds,RowKeys[ty]]
	TransZ=fmat[ReadInds,RowKeys[tz]]
	
	# RotX=RotX[ReadInds]
	# RotY=RotY[ReadInds]
	# RotZ=RotZ[ReadInds]
	
	GradX=fmat[ReadInds,RowKeys[gx]]
	GradY=fmat[ReadInds,RowKeys[gy]]
	GradZ=fmat[ReadInds,RowKeys[gz]]
	
	GradTransX=GTx[ReadInds]
	GradTransY=GTy[ReadInds]
	GradTransZ=GTz[ReadInds]
	
	time=0
	if not isinstance(tmat,int):
		time=tmat[ReadInds]
	
	return(np.array(TransX),np.array(TransY),np.array(TransZ),np.array(RotX),np.array(RotY),np.array(RotZ),np.array(GradTransX),np.array(GradTransY),np.array(GradTransZ),time)

def TestExtraction(PosDir):
	tmat,fmat,RowKeys=loadPmat(PosDir)
	VolStartInds=FindVolStartInds(fmat,RowKeys)
	VolReadInds=FindReadIdxs(fmat,RowKeys,VolStartInds)
	
	print "VolReadInds:\t{}".format(np.shape(VolReadInds))
	print "VolStartInds:\t{}".format(np.shape(VolStartInds))
	
	GTx,GTy,GTz=CalcGrad_Trans_Effect(tmat,fmat,RowKeys,VolStartInds)
	dt=np.diff(tmat)
	pl.plot(tmat,fmat[:,RowKeys['Xgrad']],label='Xgrad')
	pl.plot(tmat,fmat[:,RowKeys['TransX']],label='TransX')
	pl.plot(tmat,GTx,label='GTx')
	pl.legend()
	pl.figure()
	
	pl.plot(tmat,fmat[:,RowKeys['Ygrad']],label='Ygrad')
	pl.plot(tmat,fmat[:,RowKeys['TransY']],label='TransY')
	pl.plot(tmat[:-1],np.diff(fmat[:,RowKeys['TransY']])*dt,label='DiffTransY')
	pl.plot(tmat,GTy,label='GTy')
	pl.legend()
	pl.figure()
	
	pl.plot(tmat,fmat[:,RowKeys['Zgrad']],label='Zgrad')
	pl.plot(tmat,fmat[:,RowKeys['TransZ']],label='TransZ')
	pl.plot(tmat,GTz,label='GTz')
	pl.legend()
	pl.show()
	


def MakeTransCorrectMat_old(Tx,Ty,Kx,Ky):
	print "MakeTransCorrectMat"
	lx,ly=np.shape(Kx)
	Kx=unravel_kspace(Kx)
	Ky=unravel_kspace(Ky)
	RavelG=ravel_kspace(Ty,(lx,ly))
	# pl.matshow(np.real(RavelG))
	# pl.show()

	if len(Kx)!=len(Tx):
		print "Len KX and Tx different: {} vs {}".format(len(Kx),len(Tx))
		return(0)
	PhaseCor=[]
	for kx,ky,tx,ty in zip(Kx,Ky,Tx,Ty):
		
		PhaseCor.append(np.exp(-1j*2*np.pi*(tx*kx+ty*ky)))
	PhaseCor=ravel_kspace(PhaseCor,(lx,ly))
	# pl.matshow(np.real(PhaseCor))
	# pl.matshow(np.imag(PhaseCor))
	# pl.show()
	
	print PhaseCor
	return(PhaseCor)


def MakeTransCorrectMat(GTx,GTy,Kx,Ky):
	print "MakeTransCorrectMat"
	lx,ly=np.shape(Kx)
	RavelG=ravel_kspace(GTy,(lx,ly))
	# pl.matshow(np.real(RavelG))
	# pl.show()
	
	Kx=unravel_kspace(Kx)
	Ky=unravel_kspace(Ky)
	if len(Kx)!=len(GTx):
		print "Len KX and GTx different: {} vs {}".format(len(Kx),len(Tx))
		return(0)
	PhaseCor=[]
	for kx,ky,tx,ty in zip(Kx,Ky,GTx,GTy):
		
		PhaseCor.append(np.exp(-1j*2*np.pi*(tx+ty)))
	PhaseCor=ravel_kspace(PhaseCor,(lx,ly))
	# pl.matshow(np.real(PhaseCor))
	# pl.matshow(np.imag(PhaseCor))
	# pl.show()
	
	#print PhaseCor
	return(PhaseCor)


def CorrectForTrans_old(Tx,Ty,Kx,Ky,Ks):
	print "CorrectForTrans"    
	
	PhaseCor=MakeTransCorrectMat_old(Tx,Ty,Kx,Ky)
	NewK=np.multiply(PhaseCor,Ks)
	
	return(NewK)

def CorrectForTrans(GTx,GTy,GTz,Kx,Ky,Ks):
	print "CorrectForTrans"
	
	
	PhaseCor=MakeTransCorrectMat(GTx,GTy,Kx,Ky)
	NewK=np.multiply(PhaseCor,Ks)
	# PhaseCor2=np.exp(-1j*2*np.pi*Ky*0.004)
	# NewK=np.multiply(PhaseCor2,NewK)
	return(NewK)
	


def plotGradients(baseDir):
	tmat,fmatRS,RowKeys=loadPmat(baseDir)
	
	keys=RowKeys=['RFOn','Read','Xgrad','Ygrad','Zgrad']
	
	for key in keys:
		pl.plot(tmat,fmatRS[:,RowKeys[key]],label=key)
	pl.legend()
	pl.show()
	pass
	
	
	

def plotPmat(baseDir):
	
	#baseDir='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord3'
	#baseDir='/share/dbp2123/dparker/Code/KSpaceMotion/Possum/Possum_10XYRot'

	# tmat=np.loadtxt(baseDir+'/pulse.dmat_mot')
	# fmat=np.loadtxt(baseDir+'/pulse.fmat_mot')
	# # 
	# # tmat=np.loadtxt(baseDir+'/pulse.dmat')
	# # fmat=np.loadtxt(baseDir+'/pulse.fmat')
	# fmatRS=np.reshape(fmat,(-1,len(tmat))).T
	# #tmat=tmat.reshape(1,-1)
	
	tmat,fmatRS,RowKeys=loadPmat(baseDir)
   
	print len(RowKeys)
	for ik,key in enumerate(RowKeys):
		
   
		pl.figure()
		# pl.subplot(c,1,ic+1)
		# if ic==0:
		#     pl.plot(Pmat[:,ic])
		#     pl.plot(pmat2[:,ic],'o--')
		# else:
		#     pl.plot(Pmat[:,0],Pmat[:,ic],'*-')
		#     pl.plot(pmat2[:,0],pmat2[:,ic],'o--')
		# pl.legend(['Calculated Gradients','PosGradients'])
		pl.plot(tmat,fmatRS[:,RowKeys[key]])
		pl.title(key)
		#pl.xlim([0,.035])
	pl.show()
	
	# pl.plot(tmat,fmatRS[:,3]*np.amax(fmatRS[:,5]),label='read')
	# #pl.plot(tmat,fmatRS[:,10])
	# pl.plot(tmat,fmatRS[:,0],label='Z')
	# pl.plot(tmat,fmatRS[:,4],label='X')
	# pl.plot(tmat,fmatRS[:,5],label='Y')
	# pl.legend()
	# pl.show()
	return()

	
	
	
	MyPmat=np.loadtxt('/home/dparker/Desktop/MyNewPmat.txt')
	print tmat.shape
	print fmatRS.shape
	print MyPmat.shape
	
	MotMat=np.loadtxt(os.path.join(baseDir,'motion'))
	print MotMat.shape
	
	# for i in range(fmatRS.shape[-1]):
	#     pl.plot(fmatRS[:,i])
	#     pl.title('i={}'.format(i))
	#     pl.show()
	
	MyTime=MyPmat[:,0]
	PosTime=tmat[0,:]
	
	MyxGrad=MyPmat[:,5]
	PosxGrad=fmatRS[:,4]
	
	pl.plot(PosTime,'-.')
	pl.plot(MyTime,'--o')
	pl.show()
	
	
	pl.plot(PosTime,PosxGrad,'-.')
	pl.plot(MyTime,MyxGrad,'--o')
	pl.show()
	
	pl.plot()































def phantom (matrix_size = 256, phantom_type = 'Modified Shepp-Logan', ellipses = None):
	"""
	Create a Shepp-Logan or modified Shepp-Logan phantom::
		phantom (n = 256, phantom_type = 'Modified Shepp-Logan', ellipses = None)
	:param matrix_size: size of imaging matrix in pixels (default 256)
	:param phantom_type: The type of phantom to produce.
		Either "Modified Shepp-Logan" or "Shepp-Logan". This is overridden
		if ``ellipses`` is also specified.
	:param ellipses: Custom set of ellipses to use.  These should be in
		the form::
			[[I, a, b, x0, y0, phi],
			[I, a, b, x0, y0, phi],
							...]
		where each row defines an ellipse.
		:I: Additive intensity of the ellipse.
		:a: Length of the major axis.
		:b: Length of the minor axis.
		:x0: Horizontal offset of the centre of the ellipse.
		:y0: Vertical offset of the centre of the ellipse.
		:phi: Counterclockwise rotation of the ellipse in degrees,
			measured as the angle between the horizontal axis and
			the ellipse major axis.
	The image bounding box in the algorithm is ``[-1, -1], [1, 1]``,
	so the values of ``a``, ``b``, ``x0``, ``y0`` should all be specified with
	respect to this box.
	:returns: Phantom image
	References:
	Shepp, L. A.; Logan, B. F.; Reconstructing Interior Head Tissue
	from X-Ray Transmissions, IEEE Transactions on Nuclear Science,
	Feb. 1974, p. 232.
	Toft, P.; "The Radon Transform - Theory and Implementation",
	Ph.D. thesis, Department of Mathematical Modelling, Technical
	University of Denmark, June 1996.
	"""

	if (ellipses is None):
		ellipses = _select_phantom (phantom_type)
	elif (np.size (ellipses, 1) != 6):
		raise AssertionError ("Wrong number of columns in user phantom")

	ph = np.zeros ((matrix_size, matrix_size),dtype=np.float32)

	# Create the pixel grid
	ygrid, xgrid = np.mgrid[-1:1:(1j*matrix_size), -1:1:(1j*matrix_size)]

	for ellip in ellipses:
		I   = ellip [0]
		a2  = ellip [1]**2
		b2  = ellip [2]**2
		x0  = ellip [3]
		y0  = ellip [4]
		phi = ellip [5] * np.pi / 180  # Rotation angle in radians

		# Create the offset x and y values for the grid
		x = xgrid - x0
		y = ygrid - y0

		cos_p = np.cos (phi)
		sin_p = np.sin (phi)

		# Find the pixels within the ellipse
		locs = (((x * cos_p + y * sin_p)**2) / a2
		+ ((y * cos_p - x * sin_p)**2) / b2) <= 1

		# Add the ellipse intensity to those pixels
		ph [locs] += I

	return ph

def _select_phantom (name):
	if (name.lower () == 'shepp-logan'):
		e = _shepp_logan ()
	elif (name.lower () == 'modified shepp-logan'):
		e = _mod_shepp_logan ()
	else:
		raise ValueError ("Unknown phantom type: %s" % name)
	return e

def _shepp_logan ():
	#  Standard head phantom, taken from Shepp & Logan
	return [[   2,   .69,   .92,    0,      0,   0],
			[-.98, .6624, .8740,    0, -.0184,   0],
			[-.02, .1100, .3100,  .22,      0, -18],
			[-.02, .1600, .4100, -.22,      0,  18],
			[ .01, .2100, .2500,    0,    .35,   0],
			[ .01, .0460, .0460,    0,     .1,   0],
			[ .02, .0460, .0460,    0,    -.1,   0],
			[ .01, .0460, .0230, -.08,  -.605,   0],
			[ .01, .0230, .0230,    0,  -.606,   0],
			[ .01, .0230, .0460,  .06,  -.605,   0]]

def _mod_shepp_logan ():
	#  Modified version of Shepp & Logan's head phantom,
	#  adjusted to improve contrast.  Taken from Toft.
	return [[   1,   .69,   .92,    0,      0,   0],
			[-.80, .6624, .8740,    0, -.0184,   0],
			[-.20, .1100, .3100,  .22,      0, -18],
			[-.20, .1600, .4100, -.22,      0,  18],
			[ .10, .2100, .2500,    0,    .35,   0],
			[ .10, .0460, .0460,    0,     .1,   0],
			[ .10, .0460, .0460,    0,    -.1,   0],
			[ .10, .0460, .0230, -.08,  -.605,   0],
			[ .10, .0230, .0230,    0,  -.606,   0],
			[ .10, .0230, .0460,  .06,  -.605,   0]]





def RotMat(deg):
	dx=deg[0]*np.pi/180
	dy=deg[1]*np.pi/180
	dz=deg[2]*np.pi/180
	
	# dx=deg[0]
	# dy=deg[1]
	# dz=deg[2]
	
	
	Rx=np.matrix([[1,0,0],[0,np.cos(dx),-1*np.sin(dx)],[0,np.sin(dx),np.cos(dx)]])
	Ry=np.matrix([[np.cos(dy),0,np.sin(dy)],[0,1,0],[-1*np.sin(dy),0,np.cos(dy)]])
	Rz=np.matrix([[np.cos(dz),-1*np.sin(dz),0],[np.sin(dz),np.cos(dz),0],[0,0,1]])
	
	# Rx=np.matrix([[1,0,0,0],[0,np.cos(dx),-1*np.sin(dx),0],[0,np.sin(dx),np.cos(dx),0],[0,0,0,1]])
	# Ry=np.matrix([[np.cos(dy),0,np.sin(dy),0],[0,1,0,0],[-1*np.sin(dy),0,np.cos(dy),0],[0,0,0,1]])
	# Rz=np.matrix([[np.cos(dz),-1*np.sin(dz),0,0],[np.sin(dz),np.cos(dz),0,0],[0,0,1,0],[0,0,0,1]])
	
	
	# print Rx
	# print Ry
	# print Rz
	
	R=Rz*Ry*Rx
	return(R)


def zero_pad_image(img,newsize):
	x,y=np.shape(img)
	xpad=(newsize-x)/2.0
	if np.mod(xpad,2)!=0:
		xpad=int((newsize+1-x)/2.0)
	xsize=int(xpad*2+x)
	
	ypad=(newsize-y)/2.0
	if np.mod(ypad,2)!=0:
		ypad=int((newsize+1-y)/2.0)
	ysize=int(ypad*2+x)
	
	new_image=np.zeros((xsize,ysize))
	new_image[int(xpad):int(xpad+x),int(ypad):int(ypad+y)]=img
	
	return(new_image)


def zero_pad_complex(img,newsize):
	ZpadR=zero_pad_image(np.real(img),newsize)
	ZpadI=zero_pad_image(np.imag(img),newsize)
	Zpad=ZpadR+1j*ZpadI
	del ZpadR
	del ZpadI
	return(Zpad)


def create_OOP_kspace(Nx,Ny,dx=1,dy=1,angle=[0],axtilt='X',sample_zero=False):
	
	Nk=Nx*Ny
	
	if len(angle)==1 and angle[0]!=0:
		angle=np.linspace(0,angle[0],Nk)
	elif len(angle)==1 and angle[0]==0:
		angle=np.zeros(Nk)
	elif len(angle)<Nk:
		NewAngle=np.zeros(Nk)
		NewAngle[0:len(angle)]=angle
		NewAngle[len(angle):]=angle[-1]
		angle=NewAngle
		
	
	
	
	Kx=[]
	Ky=[]
	
	xStart=-1*int(np.floor(Nx/2))
	yStart=-1*int(np.floor(Ny/2))
	
	if not sample_zero:
		if np.mod(Nx,2)==0:
			xStart+=0.5
			yStart+=0.5
	

	
	   
	ik=0
	rx=xStart
	ry=yStart
	xdir=1
	ydir=1
	if axtilt=='X':
	
		for iy in range(Ny):
			
			for ix in range(Nx):
				
				xx=rx
				yy=ry
				xdir=np.sign(xdir)*np.cos(angle[ik]*np.pi/180.0)
				Kx.append(xx)
				Ky.append(yy)
				
				ik+=1
				rx+=xdir
				
			xdir*=-1
			rx+=xdir        
			ry+=ydir
			
	elif axtilt=='Y':
		
		for iy in range(Ny):
			
			for ix in range(Nx):
				
				xx=rx
				yy=ry
				ydir=np.cos(angle[ik]*np.pi/180.0)
				Kx.append(xx)
				Ky.append(yy)
				
				ik+=1
				rx+=xdir
				
			xdir*=-1
			rx+=xdir        
			ry+=ydir        

	return(np.array(Kx)*dx,np.array(Ky)*dy)





   
def create_kspace(Nx,Ny,dx=1,dy=1,angle=[0],sample_zero=False,Norm=True):
	
	Nk=Nx*Ny
	
	if len(angle)==1 and angle[0]!=0:
		angle=np.linspace(0,angle[0],Nk)
	elif len(angle)==1 and angle[0]==0:
		angle=np.zeros(Nk)
	elif len(angle)<Nk:
		NewAngle=np.zeros(Nk)
		NewAngle[0:len(angle)]=angle
		NewAngle[len(angle):]=angle[-1]
		angle=NewAngle
		
	
	
	
	Kx=[]
	Ky=[]
	
	xStart=-1*int(np.floor(Nx/2))
	yStart=-1*int(np.floor(Ny/2))
	
	if not sample_zero:
		if np.mod(Nx,2)==0:
			xStart+=0.5
			yStart+=0.5
	

	
	   
	ik=0
	rx=xStart
	ry=yStart
	xdir=1
	
	for iy in range(Ny):
		
		for ix in range(Nx):
			
			xx=rx*np.cos(angle[ik]*np.pi/180)-ry*np.sin(angle[ik]*np.pi/180)
			yy=rx*np.sin(angle[ik]*np.pi/180)+ry*np.cos(angle[ik]*np.pi/180)
			
			Kx.append(xx)
			Ky.append(yy)
			
			ik+=1
			rx+=xdir
			
		xdir*=-1
		rx+=xdir        
		ry+=1
	
	
	if Norm:
		dx=1.0/Nx
		dy=1.0/Ny
		
	return(np.array(Kx)*dx,np.array(Ky)*dy)

def create_kspace2(Nx,Ny,dx=1,dy=1,angle=[0],sample_zero=False,Norm=True,centerX=-1,centerY=-1):
	
	Nk=Nx*Ny
	
	if len(angle)==1 and angle[0]!=0:
		angle=np.linspace(0,angle[0],Nk)
	elif len(angle)==1 and angle[0]==0:
		angle=np.zeros(Nk)
	elif len(angle)<Nk:
		NewAngle=np.zeros(Nk)
		NewAngle[0:len(angle)]=angle
		NewAngle[len(angle):]=angle[-1]
		angle=NewAngle
		
	
	
	
	Kx=[]
	Ky=[]
	
	xStart=-1*int(np.floor((Nx*dx)/2))
	yStart=-1*int(np.floor((Ny*dy)/2))
	
	if not sample_zero:
		if np.mod(Nx,2)==0:
			xStart+=0.5*dx
			yStart+=0.5*dy
	

	
	   
	ik=0
	rx=xStart
	ry=yStart
	xdir=1
	
	for iy in range(Ny):
		
		for ix in range(Nx):
			
			xx=rx*np.cos(angle[ik]*np.pi/180)-ry*np.sin(angle[ik]*np.pi/180)
			yy=rx*np.sin(angle[ik]*np.pi/180)+ry*np.cos(angle[ik]*np.pi/180)
			
			Kx.append(xx)
			Ky.append(yy)
			
			ik+=1
			rx+=xdir*dx
			
		xdir*=-1
		rx+=xdir*dx        
		ry+=1*dy
	
	
	if centerX!=-1:
		Kx=np.array(Kx)-Kx[centerX]
		Ky=np.array(Ky)-[centerY*Nx]
	
	if Norm:
		dx=1.0/Nx
		dy=1.0/Ny
		
	return(np.array(Kx)*dx,np.array(Ky)*dy)

def upsample_fft(image,UF):
	imx,imy=np.shape(image)
	US_image=np.fft.fft2(image,s=(imx*UF,imy*UF))
	return(US_image)

def resample_fft(imageF,shape,idx,idy):
	
	tracex,tracey=create_kspace(shape[0],shape[1],sample_zero=False)
	tracex-=np.min(tracex)
	tracey-=np.min(tracey)
	
	# pl.plot(tracex,tracey,'o-*')
	# pl.show()
	newimage=np.zeros(shape)+1j*np.zeros(shape)
	
	for kx,ky,ix,iy in zip(idx.astype(int),idy.astype(int),tracex.astype(int),tracey.astype(int)):
		if kx >=0 and kx<imageF.shape[0] and ky>=0 and ky<imageF.shape[1]:
			newimage[ix,iy]=imageF[kx,ky]
	
	return(newimage)


def zero_resample_fft(imageF,shape,idx,idy):
	
	tracex,tracey=create_kspace(shape[0],shape[1],sample_zero=False)
	tracex-=np.min(tracex)
	tracey-=np.min(tracey)
	
	# pl.plot(tracex,tracey,'o-*')
	# pl.show()
	newimage=np.zeros(imageF.shape)+1j*np.zeros(imageF.shape)
	
	for kx,ky,ix,iy in zip(idx.astype(int),idy.astype(int),tracex.astype(int),tracey.astype(int)):
		newimage[kx,ky]=imageF[kx,ky]
	pl.matshow(np.abs(newimage))
	pl.show()
	return(newimage)

def zero_resample_fft2(imageF,shape,idx,idy):
	
	tracex,tracey=create_kspace(shape[0],shape[1],sample_zero=False)
	tracex-=np.min(tracex)
	tracey-=np.min(tracey)
	
	# pl.plot(tracex,tracey,'o-*')
	# pl.show()
	newimage=np.zeros(imageF.shape)+1j*np.zeros(imageF.shape)
	
	for kx,ky,ix,iy in zip(idx.astype(int),idy.astype(int),tracex.astype(int),tracey.astype(int)):
		if kx >=0 and kx<imageF.shape[0] and ky>=0 and ky<imageF.shape[1]:
			newimage[kx,ky]=imageF[kx,ky]
	pl.matshow(np.abs(newimage))
	pl.show()
	return(newimage)


# def unravel_kspace(imageF,idx,idy):
#     incx=np.sign(np.diff(idx)).astype(int)
#     incy=np.sign(np.diff(idy)).astype(int)
#     newImg=np.zeros(len(idx),dtype=complex)
#     newImg[0]=imageF[0,0]
#     x=0
#     y=0
#     i=0
#     for ix,iy in zip(incx,incy):
#        i+=1
#        x+=ix
#        y+=iy
#        newImg[i]=imageF[x,y]
#     return(newImg)

# def ravel_kspace(image,idx,idy,shape):
#     
#     newImg=np.zeros(shape,dtype=complex)
#    
#     incx=np.sign(np.diff(idx)).astype(int)
#     incy=np.sign(np.diff(idy)).astype(int)
# 
#     newImg[0,0]=image[0]
#     x=0
#     y=0
#     i=0
#     for ix,iy in zip(incx,incy):
#        i+=1
#        x+=ix
#        y+=iy
#        newImg[x,y]=image[i]
#        
#     return(newImg)


def unravel_kspace(imageF,origin='upper'):
	
	if origin=='lower':
		imageF=np.rot90(imageF,k=-1)
	
	newarr=[]
	Lx,Ly=np.shape(imageF)
	ix=0
	iy=0
	xinc=1
	yinc=1
	
	
	for y in range(Ly):
		
		for x in range(Lx):
			newarr.append(imageF[ix,iy])
			ix+=xinc
		xinc*=-1
		ix+=xinc
		iy+=yinc
	return newarr

def ravel_kspace(image,shape,origin='upper'):

	
	Ly=shape[0]
	Lx=shape[1]
	NewImg=np.zeros((Lx,Ly),complex)
	xinc=1
	yinc=1
	
	imageCounter=0
	iy=0
	ix=0
		
	for y in range(Ly):
		
		for x in range(Lx):
			NewImg[ix,iy]=image[imageCounter]
			ix+=xinc
			imageCounter+=1
		xinc*=-1
		ix+=xinc
		iy+=yinc
	
	if origin=='lower':
		NewImg=np.rot90(NewImg,k=1)
	
	return(NewImg)


def simulate_kspace_sampling3(US_imageF,HR_size,orig_size,angle):
	# HR_size=np.shape(US_imageF)
	# HR_size=orig_size
	UpFactor=10
	
	HRpadx=(HR_size[0]-orig_size[0])/2.0
	HRpady=(HR_size[1]-orig_size[1])/2.0
	
	origkx,origky=create_kspace(orig_size[0],orig_size[1],angle=angle)
	refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
	
	
	

	
	# pl.plot(refkx,refky,'r-*')
	# pl.plot(origkx,origky,'g-o',markersize=3)
	# pl.show()
	# 
	
	origkx+=np.abs(np.amin(refkx))+HRpadx
	origky+=np.abs(np.amin(refky))+HRpady
	
	origkx=np.round(origkx*UpFactor).astype(int)
	origky=np.round(origky*UpFactor).astype(int)
 
	refkx+=np.abs(np.amin(refkx))+HRpadx
	refky+=np.abs(np.amin(refky))+HRpady
	
	refkx=np.round(refkx*UpFactor).astype(int)
	refky=np.round(refky*UpFactor).astype(int)   
	
	
	
	#=upsample_fft(HR_image,UpFactor)
	
	#pl.matshow(np.abs(US_imageF))    
	# pl.matshow(np.abs(np.fft.ifft2(US_imageF)))
	#pl.show()
	# 
	# pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
	# pl.plot(refkx,refky,'-o')
	# pl.plot(origkx,origky,'-*')
	# 
	# pl.show()
	#
	newimage=np.zeros(US_imageF.shape)
	
	# for ix,iy in zip(origkx,origky):
	#     newimage[ix,iy]=100+iy*10
	# # 
	# pl.matshow(newimage)
	# pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
	# pl.show()
	
	
	newfft=resample_fft(US_imageF,orig_size,origkx,origky)
	# pl.matshow(np.abs(newfft))
	# pl.show()
	# 
	
	
	return(newfft,origkx,origky,refkx,refky)

def ReshapeEpiSignal(signal,slcdir,nslc,phasedir,nphase,readdir,nread,startkspace,imgSize):
	
  
	n=7
	print n
	nsize=np.shape(signal)[-1]
	kspace_real=np.zeros((imgSize,imgSize,1,7))
	kspace_imag=np.zeros((imgSize,imgSize,1,7))
	print kspace_real.shape
	slchelp=0;
	simdir=1;
	zdir1=1;
	zdir2=1;  
	ydir1=1;
	ydir2=1; 
	xdir1=1; 
	xdir2=1;
	if np.sign(slcdir)<0:
		simdir=-1
		slchelp=nslc-1

	nphase_new=nphase-startkspace
	print nphase_new
	for nn in range(n):
		for nzz in range(nslc):
			k=nphase_new
			# k is the number of phase encoding positions, decremented by 2 for some reason.
			while k>=1:
			#for k=nphase_new;k>=1;k=k-2)
			
				#a=(nphase_new-k)*nread+(nzz-1)*nread*nphase_new+(nn-1)*nread*nphase_new*nslc+1;
				a=(nphase_new-k)*nread+(nzz)*nread*nphase_new+(nn)*nread*nphase_new*nslc;
				print a
				# a is essentiall the index we're at given a k space coordinate, slice, and volume
				#(nphase_new-k)*nread the number of phase lines minus k, times the number of read lines
				#(nzz)*nread*nphase_new - accounts for the number of sample points needed to skip to the correct slice
				# +(nn)*nread*nphase_new*nslc - the number of samples to skip to the correct volume
				
				#print a
				
				c=a+nread
				# c for some reason is a+the number of read points...It's how many away from a to fill one read line, I think
				
				# m will scroll through the read lines
				for m in range(nread):
					
					# if (np.abs(slcdir)==1):
					#     zdir1=slchelp+simdir*(nzz-1)
					#     zdir2=slchelp+simdir*(nzz-1)
					# 
					# if (np.abs(slcdir)==2):
					#     ydir1=slchelp+simdir*(nzz-1)
					#     ydir2=slchelp+simdir*(nzz-1)
					# 
					# if (np.abs(slcdir)==3):
					#     xdir1=slchelp+simdir*(nzz-1)
					#     xdir2=slchelp+simdir*(nzz-1)
					# 
					# if (phasedir==1):
					#     zdir1=(nphase-1)-(k-1)
					#     zdir2=(nphase-1)-(k-2)
					# 
					# if (phasedir==2):
					#     ydir1=(nphase-1)-(k-1)
					#     ydir2=(nphase-1)-(k-2)
					# 
					# if (phasedir==3):
					#     xdir1=(nphase-1)-(k-1)
					#     xdir2=(nphase-1)-(k-2)
					# 
					# if (readdir==1):
					#     zdir1=m-1
					#     zdir2=nread-m
					# 
					# if (readdir==2): 
					#     ydir1=m-1
					#     ydir2=nread-m
					# 
					# if (readdir==3):
					#     xdir1=m-1
					#     xdir2=nread-m;
					#     
						
					if (np.abs(slcdir)==1):
						zdir1=slchelp+simdir*(nzz)
						zdir2=slchelp+simdir*(nzz)
				
					if (np.abs(slcdir)==2):
						ydir1=slchelp+simdir*(nzz)
						ydir2=slchelp+simdir*(nzz)
				
					if (np.abs(slcdir)==3):
						xdir1=slchelp+simdir*(nzz)
						xdir2=slchelp+simdir*(nzz)
				
					if (phasedir==1):
						zdir1=(nphase-1)-(k-1)
						zdir2=(nphase-1)-(k-2)
				
					if (phasedir==2):
						#ydir...current y coord?  nphase-1-whatever k we're at -1
						# not sure what ydir 2 is about
						ydir1=(nphase-1)-(k-1)
						ydir2=(nphase-1)-(k-2)
						print 'ydir1:\t{}'.format(ydir1)
						print 'ydir2:\t{}'.format(ydir2)
						print 'nphase:\t{}'.format(nphase)
					  
					if (phasedir==3):
						xdir1=(nphase-1)-(k-1)
						xdir2=(nphase-1)-(k-2)
				
					if (readdir==1):
						zdir1=m
						zdir2=nread-m-1
				  
				
					if (readdir==2): 
						ydir1=m
						ydir2=nread-m-1
				
					if (readdir==3):
						xdir1=m
						xdir2=nread-m-1
						print 'xdir1:\t{}'.format(xdir1)
						print 'xdir2:\t{}'.format(xdir2)
					
					#OH MY FUCKING GOD I think what it does is fill up every OTHER line that goes L->R, THEN goes back and fills in the others that go R->L?????
				
					#kspace_real[xdir1,ydir1,zdir1,nn-1]=signal[1,a+m-1]
					print xdir1
					print ydir1
					print zdir1
					print nn
					print a+m
					kspace_real[xdir1,ydir1,zdir1,nn]=signal[0,a+m]
					
					
				   #      if (verbose.value()) {
				   #         cout<<signal(1,a+m-1)<<endl;
				   #         cout<<"xdir1="<<xdir1<<" ydir1="<<ydir1<<" zdir1="<<zdir1<<endl;
				   # cout<<kspace_real(xdir1,ydir1,zdir1,nn-1)<<endl;
				   # cout<<""<<endl;
				   #  }
					# kspace_imag[xdir1,ydir1,zdir1,nn-1]=signal[2,a+m-1]
					# if (c < nsize):
					#     kspace_real[xdir2,ydir2,zdir2,nn-1]=signal[1,c+m-1]
					#     kspace_imag[xdir2,ydir2,zdir2,nn-1]=signal[2,c+m-1]
					#
					
										#kspace_real[xdir1,ydir1,zdir1,nn-1]=signal[1,a+m-1]

					kspace_imag[xdir1,ydir1,zdir1,nn]=signal[1,a+m]
									
					if (c < nsize):
						
						print ''
						print xdir2
						print ydir2
						print zdir2
						print nn
						print c+m

						kspace_real[xdir2,ydir2,zdir2,nn]=signal[0,c+m]
						kspace_imag[xdir2,ydir2,zdir2,nn]=signal[1,c+m]
			 
				k=k-2
			
	return kspace_real,kspace_imag


def simulate_kspace_sampling(HR_image,orig_size,angle):
	HR_size=np.shape(HR_image)
	UpFactor=10
	
	HRpadx=(HR_size[0]-orig_size[0])/2.0
	HRpady=(HR_size[1]-orig_size[1])/2.0
	print HRpadx
	origkx,origky=create_kspace(orig_size[0],orig_size[1],angle=angle)
	refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
	
	
	
	# iix=refkx-np.amin(refkx)
	# 
	# iix=np.round((iix/np.amax(iix))*(HR_size[0]-1)*UpFactor)
	# iiy=refky-np.amin(refky)
	# iiy=np.round((iiy/np.amax(iiy))*(HR_size[1]-1)*UpFactor)
	iix=origkx-np.amin(origkx)

	iix=np.round((iix/np.amax(iix))*(HR_size[0]-1)*UpFactor)
	iiy=origky-np.amin(origky)
	iiy=np.round((iiy/np.amax(iiy))*(HR_size[1]-1)*UpFactor)    

	
	origkx+=np.abs(np.amin(refkx))+HRpadx
	origky+=np.abs(np.amin(refky))+HRpady
	
	origkx=np.round(origkx*UpFactor).astype(int)
	origky=np.round(origky*UpFactor).astype(int)
 
	refkx+=np.abs(np.amin(refkx))+HRpadx
	refky+=np.abs(np.amin(refky))+HRpady
	
	refkx=np.round(refkx*UpFactor).astype(int)
	refky=np.round(refky*UpFactor).astype(int)   
	
	
	
	
	US_imageF=upsample_fft(HR_image,UpFactor)
	
	
	pl.matshow(np.log(np.abs(np.fft.fftshift(US_imageF))),origin='lower')
	pl.plot(iix,iiy,'o',markersize=2,color='r')
	pl.title('KspaceResample')
	pl.matshow(np.log(np.abs(np.fft.fftshift(np.fft.fft2(HR_image)))))
	pl.title('OriginalFFT')

	pl.show()
	
	
	#pl.matshow(np.abs(US_imageF))    
	# pl.matshow(np.abs(np.fft.ifft2(US_imageF)))
	#pl.show()
	# 
	# pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
	# pl.plot(refkx,refky,'-o')
	# pl.plot(origkx,origky,'-*')
	# 
	# pl.show()
	#
	newimage=np.zeros(US_imageF.shape)
	
	# for ix,iy in zip(origkx,origky):
	#     newimage[ix,iy]=100+iy*10
	# # 
	# pl.matshow(newimage)
	# pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
	# pl.show()
	
	
	newfft=resample_fft(np.fft.fftshift(US_imageF),orig_size,origkx,origky)
	# pl.matshow(np.abs(newfft))
	# pl.show()
	# 
	
	
	return(newfft,origkx,origky,refkx,refky)


def simulate_kspace_sampling2(HR_image,orig_size,angle):
	HR_size=np.shape(HR_image)
	UpFactor=10
	
	HRpadx=(HR_size[0]-orig_size[0])/2.0
	HRpady=(HR_size[1]-orig_size[1])/2.0
	
	origkx,origky=create_kspace(orig_size[0],orig_size[1],angle=angle)
	refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
	
	
	

	
	# pl.plot(refkx,refky,'r-*')
	# pl.plot(origkx,origky,'g-o',markersize=3)
	# pl.show()
	# 
	
	origkx+=np.abs(np.amin(refkx))+HRpadx
	origky+=np.abs(np.amin(refky))+HRpady
	
	origkx=np.round(origkx*UpFactor).astype(int)
	origky=np.round(origky*UpFactor).astype(int)
 
	refkx+=np.abs(np.amin(refkx))+HRpadx
	refky+=np.abs(np.amin(refky))+HRpady
	
	refkx=np.round(refkx*UpFactor).astype(int)
	refky=np.round(refky*UpFactor).astype(int)
	
	
	
	US_imageF=upsample_fft(HR_image,UpFactor)
	
	# pl.matshow(np.abs(US_imageF))    
	# pl.matshow(np.abs(np.fft.ifft2(US_imageF)))
	# pl.show()
	# 
	# pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
	# pl.plot(refkx,refky,'-o')
	# pl.plot(origkx,origky,'-*')
	# 
	# pl.show()
	#
	newimage=np.zeros(US_imageF.shape)
	
	# for ix,iy in zip(origkx,origky):
	#     newimage[ix,iy]=100+iy*10
	# # 
	# pl.matshow(newimage)
	# pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
	# pl.show()
	
	
	newfft=zero_resample_fft(np.fft.fftshift(US_imageF),orig_size,origkx,origky)
	# pl.matshow(np.abs(newfft))
	# pl.show()
	# 
	
	
	return(newfft,origkx,origky,refkx,refky)


def simulate_kspace_sampling4(HR_image,orig_size,angle):
	HR_size=np.shape(HR_image)
	UpFactor=10
	
	HRpadx=(HR_size[0]-orig_size[0])/2.0
	HRpady=(HR_size[1]-orig_size[1])/2.0
	
	origkx,origky=create_kspace(orig_size[0],orig_size[1],angle=angle)
	refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
	
	
	

	
	# pl.plot(refkx,refky,'r-*')
	# pl.plot(origkx,origky,'g-o',markersize=3)
	# pl.show()
	# 
	
	origkx+=np.abs(np.amin(refkx))+HRpadx
	origky+=np.abs(np.amin(refky))+HRpady
	
	origkx=np.round(origkx*UpFactor).astype(int)
	origky=np.round(origky*UpFactor).astype(int)
 
	refkx+=np.abs(np.amin(refkx))+HRpadx
	refky+=np.abs(np.amin(refky))+HRpady
	
	refkx=np.round(refkx*UpFactor).astype(int)
	refky=np.round(refky*UpFactor).astype(int)
	
	
	
	US_imageF=upsample_fft(HR_image,UpFactor)
	
	# pl.matshow(np.abs(US_imageF))    
	# pl.matshow(np.abs(np.fft.ifft2(US_imageF)))
	# pl.show()
	# 
	# pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
	# pl.plot(refkx,refky,'-o')
	# pl.plot(origkx,origky,'-*')
	# 
	# pl.show()
	#
	newimage=np.zeros(US_imageF.shape)
	
	# for ix,iy in zip(origkx,origky):
	#     newimage[ix,iy]=100+iy*10
	# # 
	# pl.matshow(newimage)
	# pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
	# pl.show()
	
	
	newfft=zero_resample_fft2(np.fft.fftshift(US_imageF),orig_size,origkx,origky)
	# pl.matshow(np.abs(newfft))
	# pl.show()
	# 
	
	
	return(newfft,origkx,origky,refkx,refky)

def New_simulate_kspace_sampling(HR_image,orig_size,kmap,kx,ky):
	HR_size=np.shape(HR_image)
	UpFactor=10
	
	HRpadx=(HR_size[0]-orig_size[0])/2.0
	HRpady=(HR_size[1]-orig_size[1])/2.0
	print HRpadx
	origkx,origky=create_kspace(orig_size[0],orig_size[1],angle=angle)
	refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
	
	
	
	# iix=refkx-np.amin(refkx)
	# 
	# iix=np.round((iix/np.amax(iix))*(HR_size[0]-1)*UpFactor)
	# iiy=refky-np.amin(refky)
	# iiy=np.round((iiy/np.amax(iiy))*(HR_size[1]-1)*UpFactor)
	iix=origkx-np.amin(origkx)

	iix=np.round((iix/np.amax(iix))*(HR_size[0]-1)*UpFactor)
	iiy=origky-np.amin(origky)
	iiy=np.round((iiy/np.amax(iiy))*(HR_size[1]-1)*UpFactor)    

	
	origkx+=np.abs(np.amin(refkx))+HRpadx
	origky+=np.abs(np.amin(refky))+HRpady
	
	origkx=np.round(origkx*UpFactor).astype(int)
	origky=np.round(origky*UpFactor).astype(int)
 
	refkx+=np.abs(np.amin(refkx))+HRpadx
	refky+=np.abs(np.amin(refky))+HRpady
	
	refkx=np.round(refkx*UpFactor).astype(int)
	refky=np.round(refky*UpFactor).astype(int)   
	
	
	
	
	US_imageF=upsample_fft(HR_image,UpFactor)
	
	
	pl.matshow(np.log(np.abs(np.fft.fftshift(US_imageF))),origin='lower')
	pl.plot(iix,iiy,'o',markersize=2,color='r')
	pl.title('KspaceResample')
	pl.matshow(np.log(np.abs(np.fft.fftshift(np.fft.fft2(HR_image)))))
	pl.title('OriginalFFT')

	pl.show()
	
	
	#pl.matshow(np.abs(US_imageF))    
	# pl.matshow(np.abs(np.fft.ifft2(US_imageF)))
	#pl.show()
	# 
	# pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
	# pl.plot(refkx,refky,'-o')
	# pl.plot(origkx,origky,'-*')
	# 
	# pl.show()
	#
	newimage=np.zeros(US_imageF.shape)
	
	# for ix,iy in zip(origkx,origky):
	#     newimage[ix,iy]=100+iy*10
	# # 
	# pl.matshow(newimage)
	# pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
	# pl.show()
	
	
	newfft=resample_fft(np.fft.fftshift(US_imageF),orig_size,origkx,origky)
	# pl.matshow(np.abs(newfft))
	# pl.show()
	# 
	
	
	return(newfft,origkx,origky,refkx,refky)



def MyIfft(Kx,Ky,Xm,Ym,weights):
	# This take an array as an input
	mn=np.zeros((len(Xm)),complex)
	Xm=np.array(Xm)
	Ym=np.array(Ym)
	weights=np.array(weights)
	
	dx=np.amax(np.abs(np.diff(Xm)))
	dy=np.amax(np.abs(np.diff(Ym)))
	
	mx=np.amax(Xm)
	my=np.amax(Ym)
	
	# scalex=np.amax(Kx)-np.amin(Kx)
	# Kx=Kx/scalex#*(np.pi/dx)
	# # 
	# scaley=np.amax(Ky)-np.amin(Ky)
	# Ky=Ky/scaley#*(np.pi/dy)
	N=len(Kx)
	
	# Xm=Xm/mx
	# Ym=Ym/my
	
	for kx,ky,w in zip(Kx,Ky,weights):
		#print kx
		#mn+=[w*np.exp(1j*2*np.pi*(x*kx+y*ky)) for w,x,y in zip(weights,Xm,Ym)]
		mn+=w*np.exp(1j*2*np.pi*(Xm*kx+Ym*ky))
	
	return(mn)


def MyIfft2(Kx,Ky,Xm,Ym,weights):
	# This takes a matrix as an input
	
	
	# Xm=Xm/mx
	# Ym=Ym/my
	mn=np.zeros(Xm.shape,complex)
	for kx,ky,w in zip(Kx,Ky,weights):
		#print kx
		#mn+=[w*np.exp(1j*2*np.pi*(x*kx+y*ky)) for w,x,y in zip(weights,Xm,Ym)]
		mn+=w*np.exp(1j*2*np.pi*(Xm*(kx+np.pi/8)+Ym*(ky+np.pi/8)))
	mn/=len(mn)
	return(mn)


def MyIfft3(Kx,Ky,Xm,Ym,weights):
	# This takes a matrix as an input
	
	#print "MyIFFT3"
	# Xm=Xm/mx
	# Ym=Ym/my
	# Nx=len(Kx)
	# Ny=len(Ky)
	
	mn=np.zeros(Xm.shape,complex)
	for kx,ky,w in zip(Kx,Ky,weights):
		#print kx
		#mn+=[w*np.exp(1j*2*np.pi*(x*kx+y*ky)) for w,x,y in zip(weights,Xm,Ym)]
		#mn+=w*np.exp(1j*2*np.pi*(Xm*(kx+2*np.pi)+Ym*(ky))
		#mn+=w*np.exp(1j*2*np.pi*(Xm*(kx)/Nx+Ym*(ky)/Ny))Frav
		mn+=w*np.exp(1j*2*np.pi*(Xm*(kx)+Ym*(ky)))
	mn/=len(Kx)
	return(mn)

def MyIfft4(Kx,Ky,Xm,Ym,weights,Nx,Ny):
	# This takes a matrix as an input
	
	#print "MyIFFT3"
	# Xm=Xm/mx
	# Ym=Ym/my
	# Nx=len(Kx)
	# Ny=len(Ky)
	
	mn=np.zeros(Xm.shape,complex)
	for kx,ky,w in zip(Kx,Ky,weights):
		#print kx
		#mn+=[w*np.exp(1j*2*np.pi*(x*kx+y*ky)) for w,x,y in zip(weights,Xm,Ym)]
		#mn+=w*np.exp(1j*2*np.pi*(Xm*(kx+2*np.pi)+Ym*(ky))
		mn+=w*np.exp(1j*2*np.pi*(Xm*(kx)/Nx+Ym*(ky)/Ny))
		#mn+=w*np.exp(1j*2*np.pi*(Xm*(kx)+Ym*(ky)))
	mn/=len(Kx)
	return(mn)

	
	
def Myfft(Kx,Ky,Xm,Ym,weights):
	mn=np.zeros((len(Xm)),complex)
	
	for x,y,w in zip(Xm,Ym,weights):
		
		mn+=w*np.exp(-1j*np.pi*(Kx*x+Ky*y))
	return(mn)
	
	


def mapk2ind(refKx,refKy,orig_size,map_size,UpFactor):
	
	x,y=orig_size
	nx,ny=map_size
	
	xpad=(nx-x)/2.0
	if np.mod(xpad,2)!=0:
		xpad=int((nx+1-x)/2.0)
	#xsize=int(xpad*2+x)
	
	ypad=(ny-y)/2.0
	if np.mod(ypad,2)!=0:
		ypad=int((ny+1-y)/2.0)
	#ysize=int(ypad*2+x)
	
	spankx=np.amax(refKx)-np.amin(refKx)
	spanky=np.amax(refKy)-np.amin(refKy)
	
	xpad=xpad*UpFactor
	ypad=ypad*UpFactor
	
	spanx=(x-1)*UpFactor
	spany=(y-1)*UpFactor
	
	ind_per_kx=spanx/spankx
	ind_per_ky=spany/spanky

	ix=xpad-ind_per_kx*np.amin(refKx)#-UpFactor#np.floor(UpFactor/2)
	iy=ypad-ind_per_ky*np.amin(refKy)#-UpFactor#np.floor(UpFactor/2)
		
	return(ind_per_kx,ix,ind_per_ky,iy)



def testFFt():
	img=np.zeros((112,112))
	img[0:30,10:20]=1
	img[68:79,50:100]=2
	pl.matshow(img)
	Fimg=np.fft.fftshift(np.fft.fft2(img,s=(224,224)))
	OFimg=Fimg[56:168,56:168]
	oimg=np.fft.ifft2(OFimg)
	iimg=np.fft.ifft2(Fimg)
	pl.matshow(np.abs(iimg))
	pl.matshow(np.abs(oimg))
	pl.show()
	pass



def k_2_magphase(kspace):
	mag=np.abs(kspace)
	angle=np.angle(kspace)
	return(mag,angle)

def magphase_2_k(mag,phase):
	k=mag*np.cos(phase)+1j*mag*np.cos(phase)
	return(k)


def interpolate_Kspace(imgfft,sampkx,sampky,refkx,refky,orig_size,method='cubic'):
	points=np.zeros((len(sampkx),2))
	points[:,0]=sampkx
	points[:,1]=sampky

	values=unravel_kspace(imgfft,refkx,refky)
	kxGrid,kyGrid=np.meshgrid(refkx[0:orig_size[0]],refky[0::orig_size[0]])
	# pl.matshow(kxGrid)
	# pl.matshow(np.abs(imgfft))
	# pl.matshow(np.abs(np.fft.fftshift(np.fft.fft2(imgfft))))
	# 
	# #pl.plot(refkx[0:orig_size[0]],refky[0::orig_size[0]])
	# pl.show()
	# print kxGrid.shape
	
	# mag,phase=k_2_magphase(values)
	# 
	# ReGridMag=interpolate_image((sampkx,sampky),mag,kxGrid,kyGrid,method)    
	# ReGridPhase=interpolate_image((sampkx,sampky),phase,kxGrid,kyGrid,method)
	#     
	# ReGrid=magphase_2_k(ReGridMag,ReGridPhase)
	# #ReGrid=interpolate_image((sampkx,sampky),values,kxGrid,kyGrid,method)
	# #ReGrid=ravel_kspace(ReGridReal+1j*ReGridImag,refkx,refky,orig_size)
	
	ReGridReal=interpolate_image((sampkx,sampky),np.real(values),kxGrid,kyGrid,method)
	ReGridimag=interpolate_image((sampkx,sampky),np.imag(values),kxGrid,kyGrid,method)
	# print ReGridReal.shape
	# print ReGridimag.shape
	
	#ReGrid=ravel_kspace(ReGridReal+1j*ReGridimag,refkx,refky,orig_size)
	ReGrid=ReGridReal+1j*ReGridimag
	print np.amax(np.abs(ReGrid))
	
	return(ReGrid)

def interpolate_image(points,values,xGrid,yGrid,method='cubic'):
	interpolated=scp.interpolate.griddata(points,values,(xGrid,yGrid),method=method,fill_value=0)
	return(interpolated)
	



def copyKspaceQuadrent(image,q):
	# ____________
	# |    |      |
	# | q1 |  q3  | 
	# |____|______|
	# | q2 |  q4  |
	# |____|______\
	# 
	#pl.matshow(image)
	nx,ny=np.shape(image)
	xmid=np.round(nx/2)
	ymid=np.round(ny/2)
	
	if q==1:
	   quadcopy=image[0:xmid+1,0:ymid+1]
	   newimage=np.zeros(image.shape)
	   #newimage=np.copy(image)
	   newimage[0:xmid,0:ymid]=quadcopy
	   newimage[xmid:,0:ymid]=np.flipud(quadcopy)
	   newimage[xmid:,ymid:]=np.fliplr(np.flipud(quadcopy))
	   newimage[0:xmid,ymid:]=np.fliplr(quadcopy)
	
	# pl.matshow(newimage)
	# 
	# pl.show()

	return(newimage)




def twoDfftTest():
	
	ln=256
	image=np.zeros((ln,ln))
	
	image[20:60,5:10]=1
	image[100:115,180:230]=1
	image[160:165,60:80]=1
	image[155:160,80:100]=1
	image[160:165,100:120]=1
	
	F=np.fft.fftshift(np.fft.fft2(image))
	xline=F[:,128]
	yline=F[128,:]
	pl.matshow(np.log(np.abs(F)))
	
	f,ax=pl.subplots(3,2)
	a=ax[0,0]
	a.plot(np.real(xline))
	a.set_title('x real')
	a=ax[1,0]
	a.plot(np.imag(xline))
	a.set_title('x imag')
	a=ax[2,0]
	a.plot(np.abs(xline))
	
	a=ax[0,1]
	a.plot(np.real(yline))
	a.set_title('yreal')
	a=ax[1,1]
	a.plot(np.imag(yline))
	a.set_title('yimag')
	a=ax[2,1]
	a.plot(np.abs(yline))
	pl.show()
	
	
	lx,ly=np.shape(image)
	
	mx=np.mod(lx,2)
	my=np.mod(ly,2)
		
	lx=np.floor(lx/2.0).astype(int)
	ly=np.floor(ly/2.0).astype(int)+1
	
	halfsig=F[:,:ly]
	
	
	#realhalf=np.    
	realhalf=np.real(halfsig)
	imaghalf=np.imag(halfsig)
	
	
	print realhalf.shape
	print np.shape(np.fliplr(np.flipud(realhalf[:,1-my:-1])))
	print np.shape(realhalf[:,1-my:-1])
	
	
	realfullsig=np.hstack((realhalf,np.roll(np.fliplr(np.flipud(realhalf[:,1-my:-1])),1-mx,0)))
	imagfullsig=np.hstack((imaghalf,np.roll(np.fliplr(np.flipud(-1*imaghalf[:,1-my:-1])),1-mx,0)))
	fullsig=realfullsig+1j*imagfullsig    
	pl.matshow(np.log(np.abs(fullsig)))
	pl.title('Reconstcuct')
	pl.matshow(np.log(np.abs(F)))
	pl.title('original')    
	
	pl.matshow(image)
	reconstruct=np.fft.ifft2(np.fft.ifftshift(fullsig))
	pl.matshow(np.abs(reconstruct))
	pl.title('reconstruct mag')
	pl.matshow(image-np.abs(reconstruct))
	pl.title('image difference')
	pl.matshow(np.log(np.abs(realfullsig-np.real(F))))
	pl.title('realdiff')
	pl.matshow(np.log(np.abs(imagfullsig-np.imag(F))))
	pl.title('imagdiff')
	pl.show()
	
	
def QuadCopy2D(F):

	lx,ly=np.shape(F)
	
	mx=np.mod(lx,2)
	my=np.mod(ly,2)
		
	lx=np.floor(lx/2.0).astype(int)
	ly=np.floor(ly/2.0).astype(int)+1
	
	halfsig=F[:,:ly]
	
	
   
	realhalf=np.real(halfsig)
	imaghalf=np.imag(halfsig)
	
	
	print realhalf.shape
	print np.shape(np.fliplr(np.flipud(realhalf[:,1-my:-1])))
	print np.shape(realhalf[:,1-my:-1])
	
	
	realfullsig=np.hstack((realhalf,np.roll(np.fliplr(np.flipud(realhalf[:,1-my:-1])),1-mx,0)))
	imagfullsig=np.hstack((imaghalf,np.roll(np.fliplr(np.flipud(-1*imaghalf[:,1-my:-1])),1-mx,0)))
	fullsig=realfullsig+1j*imagfullsig    
	pl.matshow(np.log(np.abs(fullsig)))
	pl.title('Reconstcuct')
	pl.matshow(np.log(np.abs(F)))
	pl.title('original')    
	
	pl.matshow(image)
	reconstruct=np.fft.ifft2(np.fft.ifftshift(fullsig))
	pl.matshow(np.abs(reconstruct))
	pl.title('reconstruct mag')
	pl.matshow(image-np.abs(reconstruct))
	pl.title('image difference')
	pl.matshow(np.log(np.abs(realfullsig-np.real(F))))
	pl.title('realdiff')
	pl.matshow(np.log(np.abs(imagfullsig-np.imag(F))))
	pl.title('imagdiff')
	pl.show()
	return fullsig

def oneDfftTest():
	ln=256
	t=np.arange(ln)*0.01
	signal=np.random.rand(ln)+np.cos(t*4*180/np.pi)
	
	sf=np.fft.fftshift(np.fft.fft(signal))
	
	f,ax=pl.subplots(6,2)
	a=ax[0,0]
	a.plot(signal)
	a=ax[1,0]
	a.plot(np.real(sf))
	a=ax[2,0]
	a.plot(np.imag(sf))
	
	
	m=np.mod(ln,2)
	
	l=np.floor(len(signal)/2.0).astype(int)+1
	halfsig=sf[:l]
	
	realhalf=np.real(halfsig)
	imaghalf=np.imag(halfsig)
	realfullsig=np.hstack((realhalf,np.flipud(realhalf[1-m:-1])))
	imagfullsig=np.hstack((imaghalf,np.flipud(-1*imaghalf[1-m:-1])))
	
	fullsig=realfullsig+1j*imagfullsig
	
	
	a=ax[3,0]
	a.plot(np.real(fullsig))
	a=ax[4,0]
	a.plot(np.imag(fullsig))
	a=ax[5,0]
	reconstruct=np.fft.ifft(np.fft.ifftshift(fullsig))
	a.plot(np.real(reconstruct))
	
	a=ax[0,1]
	a.plot(signal-np.real(reconstruct))
	a=ax[1,1]
	a.plot(np.real(sf)-np.real(fullsig))
	a=ax[2,1]
	a.plot(np.imag(sf)-np.imag(fullsig))
	
	
	a=ax[3,1]
	a.plot(np.real(sf))
	a.plot(np.real(fullsig),'-o')
	a=ax[4,1]
	a.plot(np.imag(sf))
	a.plot(np.imag(fullsig),'-o')
	
	pl.show()
	

def norm(data):
	data=data-np.min(data)
	data=data/np.amax(np.abs(data))
	return(data)


def error(img1,img2):
	#error=np.log(np.abs(norm(img1)-norm(img2)))
	error=np.abs(norm(img1)-norm(img2))
	return(error)

#     
# ZpadFft=np.zeros((224,224),dtype=complex)
# 
# ZPFdata=np.fft.ifft2(np.fft.ifftshift((ZpadFft)))
# NewDataFft=np.fft.fftshift(np.fft.fft2(ZPFdata,s=(2240,2240)))
#     



def comp_sens(imgf):
	gtv=0
	refkx,refky=create_kspace(128,128,angle=[0])
	imgf=ravel_kspace(imgf,refkx,refky,((128,128)))
	print imgf.shape
	for r in range(1,imgf.shape[0]):
		for c in range(1,imgf.shape[1]):
			gtv+=np.sqrt(np.square(np.abs(imgf[r,c]-imgf[r-1,c]))+np.square(np.abs(imgf[r,c]-imgf[r,c-1])))
	
	return(gtv)



def test_minimize():
	img=phantom(128).T
	orig_size=(128,128)
	imageF=np.fft.fftshift(np.fft.fft2(img))
	
	xr=(np.random.rand(8192)*127).astype(int)
	yr=(np.random.rand(8192)*127).astype(int)
	#data=imageF[xr,yr]
	refkx,refky=create_kspace(128,128,angle=[0])
	sparse_data=np.zeros(orig_size,dtype=complex)
	sparse_data[xr,yr]=imageF[xr,yr]
	# pl.plot(sparse_data[:,64],'-o')
	# pl.plot(imageF[:,64],'-*')
	# pl.show()
	# pl.matshow(np.abs(sparse_data))
	# pl.matshow(np.abs(imageF))
	# pl.show()
	
	urSparse=unravel_kspace(sparse_data,refkx,refky)
	res=minimize(comp_sens,urSparse,method='nelder-mead',options={'xtol':1e-8,'disp':True})
	NewImg=res.x
	pl.matshow(np.abs(np.fft.ifft2(np.fft.fftshift(NewImg))))
	pl.show()
	
	pass


def episequence_Simple(FOVx,FOVy,Nx,Ny,angle=[]):
	
	KfovMax=np.pi/2.0
	Kspanx=np.linspace(-KfovMax,KfovMax,Nx)
	Kspany=np.linspace(-KfovMax,KfovMax,Ny)
	
	SpeedY=1.0
	SpeedX=(Nx*1.0)/(Ny*1.0)
	
	Kx,Ky=np.meshgrid(Kspanx,Kspany)
	
	if not angle==[]:
		if len(angle)==1:
			
			newKx=np.zeros(Kx.shape)
			newKy=np.zeros(Ky.shape)
			
			theta=angle[0]
			for ix in range(len(Kspanx)):
				for iy in range(len(Kspany)):
					newKx[ix,iy]=Kx[ix,iy]*np.cos(theta*np.pi/180)-Ky[ix,iy]*np.sin(theta*np.pi/180)
					newKy[ix,iy]=Kx[ix,iy]*np.sin(theta*np.pi/180)+Ky[ix,iy]*np.cos(theta*np.pi/180)
					
				
			Kx=newKx
			Ky=newKy
	
	return(Kx,Ky)
			
			
		
	



def episequence(Te,TR,resZ,slcdir,phasedir,readdir,resX,resY,bottom,top,xDim,yDim,zDim,rt=2.2e-4,maxG=5.5e-2,Bwrec=1e5,angle=90,gammabar=gam):
		# 	self.maxG=5.5e-2 #T/m
		# self.risetime=2.2e-4 #s
	# Input parameters: n = number of volumes, ns = number of slices (per volume)
	#   ddz = slice thickness (m) , zc = coordinate of slice centre (m)
	#EPISEQUENCE MATRIX INPUTFILE
	#(1)=time in s,(2)=rf angle,(3)=rf frequency bandwidth df(Hz),(4)=rf center frequency fc(Hz),(5)=readout 1/0 (6)=x gradient(T/m),(7)=y gradient(T/m),(8)=z gradient(T/m)
	#TRslc=2.997# for epi
			 #               =  TRline for ge 
	#Set up gradient directions
	zc=[0]
	nSlices=1
	nVolumes=1
	TRslc=TR/nSlices
	
	if slcdir=='z+':
		sdindex=7
	if phasedir=='y+':
		pdindex=6
	if readdir=='x+':
		rdindex=5
	
	# Assuming z=slice y=phase, x=read, and all are in the positive direction
	simdir=1
	phdir=1
	redir=1
	angle_rad=angle*np.pi/180
	gdt=maxG/rt #calculate the delta gradient/sec (T/ms)
	
	# Slice Selection
	Gz=7.128e-3 # Slice selection gradient during rf Excitation (T/m)
	dtz=Gz/gdt # Time required for SS gradient to rise to Gz (s)
	rft=4*1e-3 # Not sure what this is - I think time of the RF pulse...added to dtz so must be (s) - I believe it's the duration of the RF pulse
	
	dtz11=np.sqrt(((rft+dtz)*Gz)/(2*gdt))
	Gz1 = ((rft+dtz)*Gz)/(2*dtz11)
	dtz1=dtz11*2.0
	# fig 26.1 - Gz*(rft+dtz) = area A+B+C+D assuming B=0 and A=D
	# will come back to all this
	# dtz11 is time for 0 to Gz1; dtz1 is the total time for the negative pulse
	TA=rft/2.0+dtz+dtz1 # Time at which all rf stuff is over
	# fir 26.1 - this is t9
	
	df=zDim*gammabar*Gz #frequency width - slice thickness(m) times the gradient (T/m) Times gammabar (Hz/T) (in m*Hz/T*T/m=Hz), kinda like bandwidth of slice?
	
	fc=np.array(zc)*gammabar*Gz # Center frequencies of slices
	
	# Read Out
	dtx=1.0/Bwrec # Sampling time along readout direction
	dkx=1.0/(resX*xDim) # K space incrament is 1/FOV
	dky=1.0/(resY*yDim)
	
	Gx=dkx/(gammabar*dtx) # from dtx*gammabar*Gx=dkx - gradient strength needed to move dkx hz in dtx seconds given gamma
	dt=Gx/gdt # how long it will take for the gradient to reach Gx
	
	dty=np.sqrt(4.0*dky/(gammabar*gdt)) # solving dty using a triangle pulse, dty is the full width of the pulse, solve using the integral and Gy(t)=gdt*t dky=gammabar*integral(Gy(t)dt)
	Gy=1.0/2.0*dty*gdt
	
	
	# These are for moving k space to the appropriate location before sampling starts
	dtx1=np.sqrt(Gx*(dt+resX*dtx)*2.0/gdt) # calculating center time if read gradient was a triangle??!?! A=Gx*(Nx*dtx+dt), in triangle: A=1/2*b*h, Gx*(Nx*dtx+dt)=1/2*b*h, h=gdt*b, solve for b - divided by two
	
	Gx1=dtx1*gdt/2.0 # Can't figure out equation for this, but it's half the gradient strength.  so this should move k space to the start of the x row.  Not sure why it's divided by two, though
	# It seems like dtx1 is the time it takes to make it half way across k space at maximum gradient.  maybe it's just because we don't need to go that fast.
	
	dty1=np.sqrt(bottom)*dty # initial dy, moving k space to the start of the y row.
	Gy1=dty1*gdt/2.0
	
	# More things
	TEl=bottom*(2.0*dt+(resX-1.0)*dtx)+(dt+resX/2.0*dtx) #from the Te which is the middle of the central k space line, how much time is acquired to the LEFT of the TE
	#Bottom number of lines * time to acquire a line +1/2 time to acquire one line
	TEr=top*(2.0*dt+(resX-1)*dtx)+(dt+(resX/2.0-1)*dtx) #from the TE which is the middle of the central k space line, how much time is acquired to the RIGHT of the TE
	#Top number of lines * time to acquire a line +1/2 time to acquire one line
	
	TD=Te-TEl  # Counting back from Te, subtract readout time occuring BEFORE Te
	TC=TD-dtx1 # Now Subtract the initial kspace x-placement (Frequency encoding)
	TB=TC-dty1 # minus the initial kspace y-placement (Phase encoding)
	TF=Te+TEr  # now calculate when the reading will be complete
	tcrush=2.0*rt # how long the crush gradient will be on
	TG=TF+2.0*rt+tcrush # what time the crush gradient will start.
	
	TRslc=TR*0.999
	
	# dtz1=float("{0:.9f}".format(dtz1))
	# dtz11=float("{0:.9f}".format(dtz11))
	# dt=float("{0:.10f}".format(dt))
	# Gx=float("{0:.7f}".format(Gx))
	# dtx1=float("{0:.9f}".format(dtx1))
	# Gx1=float("{0:.7f}".format(Gx1))
	# dty=float("{0:.10f}".format(dty))
	# Gy=float("{0:.8f}".format(Gy))
	# dty1=float("{0:.9f}".format(dty1))
	# Gy1=float("{0:.7f}".format(Gy1))
	# 
	# TEl=float("{0:.6f}".format(TEl))
	# TEr=float("{0:.7f}".format(TEr))
	# TD=float("{0:.6f}".format(TD))
	# TC=float("{0:.7f}".format(TC))
	# TB=float("{0:.7f}".format(TB))
	# TA=float("{0:.8f}".format(TA))
	# TF=float("{0:.6f}".format(TF))
	# TG=float("{0:.6f}".format(TG))
	
	
	
	
	print('gdt = tana:\t{}'.format(gdt))
	
	print('resX:\t{}'.format(resX))
	print('resY:\t{}'.format(resY))
	print('zDim:\t{}'.format(zDim))
	print('Bottom:\t{}'.format(bottom))
	print('Top:\t{}'.format(top))
	
	print('')   
	print('maxG:\t{}'.format(maxG))
	print('rt:\t{}'.format(rt))
	print('TRslc:\t{}'.format(TRslc))

	print('')
	print('df:\t{}'.format(df))
	print('rft:\t{}'.format(rft))
	print('dtz:\t{}'.format(dtz))
	print('dtz1:\t{}'.format(dtz1))
	print('dtz11:\t{}'.format(dtz11))
	print('')
	
	print('dt:\t{}'.format(dt))
	print('dtx:\t{}'.format(dtx))
	print('Gx:\t{}'.format(Gx))
	print('dtx1:\t{}'.format(dtx1))
	print('Gx1:\t{}'.format(Gx1))
	print('')

	print('dty:\t{}'.format(dty))
	print('Gy:\t{}'.format(Gy))
	print('dty1:\t{}'.format(dty1))
	print('Gy1:\t{}'.format(Gy1))
	print('')
	print('TE:\t{}'.format(Te))
	print('TEl:\t{}'.format(TEl))
	print('TEr:\t{}'.format(TEr))        
	print('TD:\t{}'.format(TD))
	print('TC:\t{}'.format(TC))
	print('TB:\t{}'.format(TB))
	print('TA:\t{}'.format(TA))
	print('TF:\t{}'.format(TF))
	print('TG:\t{}'.format(TG))
	print('TR:\t{}'.format(TR))
	print('gammabar:\t{}'.format(gammabar))
	

	
	
	
	# cout<<"Times in the acquisition of one slice starting from the RF pulse (in s)"<<endl;
	# cout<<"the slice selection gradient is done TA="<<TA<<endl;
	# cout<<"the phase encode gradient starts dephasing TB="<<TB<<endl;
	# cout<<"the phase encode gradient stops dephasing, and the read-out gradient starts dephasing TC="<<TC<<endl;
	# cout<<"the read-out gradient stops dephasing,begining of the read-out period TD="<<TD<<endl;
	# cout<<"echo time Te="<<Te<<endl;
	# cout<<"end of the read-out period and begining of the crushers TF="<<TF<<endl;
	# cout<<"end of the crushers TG="<<TG<<endl;
	# cout<<"end of the acquisition of one slice TRslc="<<TRslc<<endl;       
	
	TRF=0
	
	###############################################
	##         First loop to calculate size      ##
	###############################################
	t=0 # start time
	step=1 # Row number in the matrix
	
	for a in range(nVolumes):
		for b in range(nSlices):
		
			#Slice Selection Gradient Rises
			t+=dtz
			step+=1
			#RF pulse turns on, SS gradient remains on, taken to mid line of RF pulse
			t+=rft/2
			step+=1
			TRF=t # Set this as the Time of the RF pulse
			#RF pulse finishes Gradient remains on
			t+=rft/2
			step+=1
			#Gradient turns off
			t+=dtz
			step+=1
			#Gradient goes negative to remove phase accumulation
			t+=dtz1/2
			step+=1
			#Negative gradient returns to zero
			t+=dtz1/2
			step+=1
			# From TRF, when do we start the frequency and phase encoding
			t=TRF+TB
			step+=1
			# Account for Phase Encoding
			t+=dty1/2
			step+=1
			t+=dty1/2
			step+=1
			
			t+=dtx1/2
			step+=1
			t+=dtx1/2
			step+=1
			
		  
			# Now simulate sampling k space through frequency and phase
			for c in range(bottom+1+top):
				# Now raise the initial readout gradient
				if c==0:
					# if we're just starting, just apply x gradient
					t+=dt
					step+=1
				else:
					# Otherwise it's a new slice and we need to incrament y
					# Turn On or off Y Gradient
					t+=dty/2
					step+=1
					#Turn Off Y Gradient...and something?
					t+=dt-dty/2
					step+=1
				# Now loop through the readout
				for d in range(resX-1):
					# Gradient is on already, just start stepping
					t+=dtx
					step+=1
				
				# If we're at the last slice
				if c==bottom+top:
					# Add an x gradient DT
					t+=dt
					step+=1
				else:
					#Otherwise we have more slices to go, switch the x gradient
					t+=dt-dty/2
					step+=1
					#and turn on Y Gradient
					t+=dty/2
					step+=1
					
			
			# Now apply the Crushers              
			t+=rt
			step+=1
			t+=tcrush
			step+=1
			t+=rt
			step+=1
			
			# Account for previous volumes (a) and the current slice (b)
			t=TRslc*(b+1)+a*TR
			step+=1
		
		tt=t
		t=TR*(a+1)
		
		if t-tt>1e-6:
			step+=1
		if t-tt<-1e6:
			print ("Warning TR is shorter then Nslc*TRslc")
		
	###############################################
	##                  Main Loop                ##
	###############################################
	
	nreadp=nVolumes*nSlices*resX*resY
	readstep=-1
	
	Pmatrix=np.zeros((step,8))
	#H: (1)=time in s,(2)=rf angle,(3)=rf frequency bandwidth df(Hz),(4)=rf center frequency fc(Hz),(5)=readout 1/0 (6)=x gradient(T/m),(7)=y gradient(T/m),(8)=z gradient(T/m)
	step=0
	t=0.0
	
	# Making matrix to save k space coordinates
	coord=np.zeros((2,nreadp))
	tindex=0
	
	#        if slcdir=='z+':
	#     sdindex=8 = cc
	# if phasedir=='y+':
	#     pdindex=7 = bb
	# if readdir=='x+':
	#     rdindex=6 = aa
	bhelp=0
	RefGrid=[]
	for a in range(nVolumes):
		for b in range(nSlices):
			kx=0
			ky=0
			kz=0
			
			# sdindex=cc
			# 
			
			#Slice Selection Gradient Rises
			t+=dtz;step+=1 # 1      #line1 (In Figure 1)
			Pmatrix[step,0]=t;Pmatrix[step,sdindex]=Gz 
			# Half the pulse time (Time to peak pulse) and set phase angle
			t+=rft/2;step+=1 # 2    # Line2
			Pmatrix[step,0]=t;
			Pmatrix[step,1]=angle_rad;
			Pmatrix[step,2]=df;
			Pmatrix[step,3]=fc[bhelp+simdir*b];
			Pmatrix[step,sdindex]=Gz
			TRF=t
			print ('TRF:\t{}'.format(TRF))
			#Finish the other half of the pulse time
			t=t+rft/2 #  3      # Line3
			step+=1
			Pmatrix[step,0]=t
			Pmatrix[step,sdindex]=Gz
			kz+=Pmatrix[step,sdindex]*rft/2 # Move K space by the GZ*dt
			# Turn Off Gradient
			t+=dtz  # 4     # Line4
			step+=1
			Pmatrix[step,0]=t
			kz=kz+Pmatrix[step,sdindex]*dtz/2
			#Begin Negative Z Gradient
			t+=dtz1/2 # 5       # Line5
			step+=1
			Pmatrix[step,0]=t
			Pmatrix[step,sdindex]=-Gz1
			kz=kz+Pmatrix[step,sdindex]*dtz1/4
			# Turn Off Negative Gradient
			t+=dtz1/2  # 6      # Line 6 - TA
			step+=1
			Pmatrix[step,0]=t
			kz=kz+Pmatrix[step-1,sdindex]*dtz1/4
			
			#  This was for Gradient Echo !!!
			
			# dty1=np.sqrt(np.abs(resY/2-c+1))*dty; #Recalculate ulate dty1 and Gy1 - Honestly I'm not really sure why
			# # New dty1 
			# Gy1=np.sign(resY/2-c+1)*dty1*gdt/2;
			# TB=TC-dty1;
			
			##### END OF SLICE SELECTION ####
			
			# Move time forward to TB, where kx ky space movement begins
			t=TRF+TB  # 7       # Line 7
			print ("TRF+TB=\t{}".format(t))
			step+=1
			Pmatrix[step,0]=t # TB
			#Begin moving through Ky space
			t+=dty1/2 # 8       # Line 8
			step+=1
			Pmatrix[step,0]=t
			Pmatrix[step,pdindex]=-phdir*Gy1
			ky=ky+Pmatrix[step,pdindex]*dty1/4
			#Turn of Gradient
			t+=dty1/2   # 9         # Line 9
			step+=1 # TC
			Pmatrix[step,0]=t
			ky=ky+Pmatrix[step-1,pdindex]*dty1/4
			# Turn on X Gradient for initial K space setup
			t+=dtx1/2  # 10     # Line 10
			step+=1
			Pmatrix[step,0]=t
			Pmatrix[step,rdindex]=-redir*Gx1
			kx=kx+Pmatrix[step,rdindex]*dtx1/4                  # 1
			# Turn Off X Gradient
			t+=dtx1/2  # 11  # Line 11
			step+=1 # TD
			Pmatrix[step,0]=t
			kx=kx+Pmatrix[step-1,rdindex]*dtx1/4
			print('kx at start of readout:\t{}'.format(kx))
			print "t at start of redout for volume {}: {}".format(a,t)
			
			#### END OF K SPACE INITIALIZATION ####
			####          BEGIN READOUT        ####
			print bottom+1+top
			for c in range(bottom+1+top):
				# If it's the first line of the slice
				if c==0:
					#Ramp the X Gradient up
					t+=dt # 12      # Line 12
					step+=1
					Pmatrix[step,0]=t
					Pmatrix[step,4]=1 # Read on
					Pmatrix[step,rdindex]=redir*Gx
					kx=kx+Pmatrix[step,rdindex]*dt/2
					# Update K space Coordinates
					readstep+=1
					coord[0,readstep]=kx*gammabar
					coord[1,readstep]=ky*gammabar
					
				elif dt-dty/2>=0: # If the y gradient can rise and fall enough in the time between x gradient shifts:
					# If we've made it here and it's not the first line, we must be switching to a new line, and the y gradient is already on
					# Ramp down the y gradient while also ramping the x in the current read direction
					#print('In the elif')
					t+=dty/2 # 13       # Line 16
					step+=1
					Pmatrix[step,0]=t
					Pmatrix[step,rdindex]=np.power(-1,c)*dty*gdt/2
					ky=ky+dty*Pmatrix[step-1,pdindex]/4 #Change ramping down
					kx=kx+Pmatrix[step,rdindex]*dty/4 # X change while y was ramping down
					
					# Y is ramped down, but x still has changing to do
					t+=dt-dty/2 # 14         #Line 17
					step+=1
					Pmatrix[step,0]=t
					Pmatrix[step,4]=1 # Turn on read gradient
					Pmatrix[step,rdindex]=np.power(-1,c)*redir*Gx
					kx=kx+(Pmatrix[step,rdindex]+Pmatrix[step-1,rdindex])*(dt-dty/2)/2
					readstep=readstep+1
					coord[0,readstep]=kx*gammabar
					coord[1,readstep]=ky*gammabar
				else: # If the y gradient will take longer to rise and fall:
					#print('in the else')
					t+=dty/2-dt # Begin lowering the y gradient, leave x at 0
					step+=1
					Pmatrix[step,0]=t
					Pmatrix[step,4]=1
					Pmatrix[step,pdindex]=Gy-(phdir*(dty/2-dt)*gdt) # Decrease the y gradient as much as posible during dty/2-dt
					ky+=1/2*(dty/2-dt)*(Gy+Pmatrix[step,pdindex])
					
					t+=dt # Step how long till Gx reaches peak
					step+=1
					Pmatrix[step,0]=t
					Pmatrix[step,rdindex]=np.power(-1,c)*redir*Gx
					ky+=1/2*dt*Pmatrix[step-1,pdindex]
					kx+=1/2*dt*Pmatrix[step,rdindex]
					readstep=readstep+1
					coord[0,readstep]=kx*gammabar
					coord[1,readstep]=ky*gammabar                       
					
				#print('kx at start of line {} :\t{}'.format(c,kx)) 
					
					
					#Between lines 12 and 13
				#print resX-1
					
				for d in range(resX-1):
					# Loop through the read line
					t+=dtx #  15     
					step+=1
					Pmatrix[step,0]=t
					Pmatrix[step,4]=1 # Turn on Read Gradient
					#Pmatrix[step,rdindex]=np.power(-1,c)*redir*Gx # switch direction with each line

					Pmatrix[step,rdindex]=np.power(-1,c)*redir*Gx # switch direction with each line
					kx=kx+Pmatrix[step,rdindex]*dtx
					readstep+=1
					# If we've reached the middle of k space
					if c+1==bottom+1 and (d+1)==resX/2:
						print('------')
						#print 'readstep:\t{}'.format(readstep)
						#print('step:\t{}'.format(step))
						print('Time at center or k is:\t{}'.format(t-(a)*TR-dtz-rft/2))
						print('t={}'.format(t))
						print('a={}'.format(a))
						#print('TR={}'.format(TR))
						#print('dtz={}'.format(dtz))
						#print('rft={}'.format(rft))
						#print('CurrentM={}'.format(Pmatrix[step,rdindex]))
						print ('')
						print('Time we want is:\t{}'.format(Te))
						print('Center of kspace for VolNum {} and slice num {} is (kx,ky)=({},{})'.format(a,b,kx*gammabar,ky*gammabar))
						print('-------')
					coord[0,readstep]=kx*gammabar
					coord[1,readstep]=ky*gammabar
					
				# If we're on the top line
				if c+1==bottom+1+top:
					t+=dt # 16      # Ramp down the X gradient
					step+=1
					Pmatrix[step,0]=t
					kx=kx+Pmatrix[step-1,rdindex]*dt/2 # TF
				# Otherwise switch gradient directions
				elif dt-dty/2>=0: # If the y gradient can rise and fall enough in the time between x gradient shifts:
					#Begin lowering the x gradieng
					#print 'in the elif'
					t+=dt-dty/2# 17      # At some point while the x gradient is lowering, begin raising the y gradient so it peaks when x=0
					step+=1 # Line 14
					Pmatrix[step,0]=t
					Pmatrix[step,rdindex]=np.power(-1,c)*dty*gdt/2 # Gradient at this point is equavalent to raising at gdt for dty seconds
					kx=kx+(Pmatrix[step-1,rdindex]+ Pmatrix[step,rdindex])*(dt-dty/2)/2 # Triangle area subtraction
					# Begin Raising the y gradient while still lowering x
					t+=dty/2 # 18       #line 15
					step+=1
					Pmatrix[step,0]=t
					Pmatrix[step,pdindex]=phdir*Gy
					ky=ky+dty*Pmatrix[step,pdindex]/4
					kx=kx+Pmatrix[step-1,rdindex]*dty/4 # TG
						
				else:
					#print('in the else')
					t+=dt # Lower the x gradient
					step+=1
					Pmatrix[step,0]=t
					Pmatrix[step,pdindex]=phdir*dt*gdt # Increase the y gradient as much as posible during dt
					kx+=1/2*dt*Pmatrix[step-1,rdindex]
					ky+=1/2*dt*Pmatrix[step,pdindex]
					
					t+=dty/2-dt # Step how long till Gy reaches peak
					step+=1
					Pmatrix[step,0]=t
					Pmatrix[step,pdindex]=phdir*Gy
					ky+=1/2*(dty/2-dt)*(Pmatrix[step-1,pdindex]+Pmatrix[step,pdindex])

			print 't at end of readout: {}'.format(t)           
			# Crushers
			t+=rt
			step+=1
			Pmatrix[step,0]=t
			Pmatrix[step,rdindex]=maxG
			Pmatrix[step,pdindex]=maxG
			Pmatrix[step,sdindex]=maxG
			t+=tcrush
			step+=1
			Pmatrix[step,0]=t
			Pmatrix[step,rdindex]=maxG
			Pmatrix[step,pdindex]=maxG
			Pmatrix[step,sdindex]=maxG
			t+=rt
			step+=1
			Pmatrix[step,0]=t
			
			t=TRslc*(b+1)+(a)*TR
			step=step+1
			Pmatrix[step,0]=t
			
		t=TR*(a+1)
		if t-Pmatrix[step,0]>1e-6:
			step=step+1
			Pmatrix[step,0]=t
		if t-Pmatrix[step,0]<-1e-6:
			print('WARNING TR is shorter than Nslc*TRslc')
		
		# pl.plot(coord[0,:],coord[1,:],'-o')
		# pl.show()
	np.savetxt('/home/dparker/Desktop/My_kCoord.txt',coord)
	
	
	#  Create a reference K matrix for the X/Y plane

	
	Kxref=coord[0,0:resX*resY]        
	Kyref=coord[1,0:resY*resY]  
	return(Pmatrix,Kxref,Kyref)
	

def test_interp():
	
	true128=phantom(128).T
	phSize=256
	orig_size=(128,128)
	image=phantom(matrix_size=phSize)
	
	test=zero_pad_image(true128,256)
	
	imageF=np.zeros((phSize,phSize))
	imageF[100:156,120:136]=1
	imageF[126:130,100:156]=1
	
	image=np.fft.ifftshift(np.fft.ifft2(np.fft.fftshift(imageF))).T
	# pl.matshow(np.abs(imageF))
	# pl.matshow(np.abs(image))
	# pl.show()
	#
	

	
	# For No Resampling:
	newfft,origkx,origky,refkx,refky=simulate_kspace_sampling(image,orig_size,[20])
	newimg0=np.fft.ifft2(newfft)
	
	
	smallfft,sorigkx,sorigky,srefkx,srefky=simulate_kspace_sampling(image,orig_size,[0])
	junk1,sorigkx,sorigky,srefkx,srefky=simulate_kspace_sampling(image,(20,20),[20])
	trefx=(srefkx.astype(float)-(srefkx[0]))
	trefx=trefx/np.amax(trefx)*128
	trefy=(srefky.astype(float)-(srefky[0]))
	trefy=trefy/np.amax(trefy)*128
	
	
	tracex=(sorigkx.astype(float)-(sorigkx[0]))
	tracex=tracex/np.amax(tracex)*128
	tracey=(sorigky.astype(float)-(sorigky[0]))
	tracey=tracey/np.amax(tracey)*128
	# pl.plot(tracex,tracey,'-*')
	# pl.show()
	
	img=np.zeros(orig_size)
	for i in range(0,orig_size[0],10):
		img[i,:]=1
	

	#tracex=tracex/np.amax(tracex)
	# for ix,iy in zip(tracex,tracey):
	#     print '{} , {}'.format(ix,iy)
	#     img[int(ix),int(iy)]=ix+1000*iy
	
	for i in range(0,orig_size[0],10):
		img[i,:]=1
		
	xr=(np.random.rand(1000)*127).astype(int)
	yr=(np.random.rand(1000)*127).astype(int)
	data=img[xr,yr]
	
	urimg=np.abs(unravel_kspace(img,refkx,refky))
	#gridx,gridy=np.meshgrid(tracex[0:orig_size[0]],tracey[0::orig_size[0]])
	gridx,gridy=np.meshgrid(refkx[0:orig_size[0]],refky[0::orig_size[0]])
	print gridx.shape
	print origkx.shape
	urfft=np.abs(unravel_kspace(newfft,refkx,refky))
	grid_z0 = scp.interpolate.griddata((origkx,origky), urfft, (gridx,gridy), method='nearest',fill_value=0)
	grid_z1 = scp.interpolate.griddata((origkx,origky), urfft, (gridx,gridy), method='linear',fill_value=0)
	grid_z2 = scp.interpolate.griddata((origkx,origky), urfft, (gridx,gridy), method='cubic',fill_value=0)

	f,ax=pl.subplots(1,1,figsize=(8,6))
	ax.imshow(np.abs(smallfft),origin='lower')
	ax.plot(trefy,trefx,'r--o')
	
	f,ax=pl.subplots(1,1,figsize=(8,6))
	ax.imshow(np.abs(smallfft),origin='lower')
	ax.plot(tracey,tracex,'r--o')
	
	f,ax=pl.subplots(1,1,figsize=(8,6))
	ax.imshow(np.abs(newfft),origin='lower')

	
	f,ax=pl.subplots(1,1,figsize=(8,6))
	ax.imshow(grid_z2.T, origin='lower')

	
	
	pl.show()
	
	
	gsCmap=sb.light_palette("black",n_colors=256,as_cmap=True,reverse=True)
	pl.subplot(221)
	pl.imshow(np.abs(newfft),origin='lower')
	#pl.plot([20,20],[0,128])
	pl.plot(tracey,tracex ,'k.', ms=1)
	pl.title('Original')
	pl.subplot(222)
	pl.imshow(grid_z0.T, origin='lower')
	pl.title('Nearest')
	pl.subplot(223)
	pl.imshow(grid_z1.T, origin='lower')
	pl.title('Linear')
	pl.subplot(224)
	pl.imshow(grid_z2.T, origin='lower')
	pl.title('Cubic')
	pl.gcf().set_size_inches(6, 6)
	pl.show()
	
	pl.figure()
	urfft=(unravel_kspace(newfft,refkx,refky))
	grid_z0=np.abs(interpolate_Kspace(newfft,origkx,origky,refkx,refky,orig_size,method='nearest'))
	#grid_z1=np.abs(interpolate_Kspace(newfft,origkx,origky,refkx,refky,orig_size,method='linear'))
	grid_z2=np.abs(interpolate_Kspace(newfft,origkx,origky,refkx,refky,orig_size,method='cubic'))
	grid_z1=np.abs(interpolate_image((origkx,origky),urfft,gridx,gridy,method='linear'))
	
	# pl.subplot(221)
	# pl.imshow(np.abs(newfft),origin='lower')
	# pl.plot([20,20],[0,128])
	# pl.plot(tracey,tracex ,'k.', ms=1)
	# pl.title('Original')
	# pl.subplot(222)
	# pl.imshow(grid_z0.T, origin='lower')
	# pl.title('Nearest')
	# pl.subplot(223)
	# pl.imshow(grid_z1.T, origin='lower')
	# pl.title('Linear')
	# pl.subplot(224)
	# pl.imshow(grid_z2.T, origin='lower')
	# pl.title('Cubic')
	# pl.gcf().set_size_inches(6, 6)    
	# pl.show()


