#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl


def coeff(xold,xnew,told,tnew):#{//needs improvement
  #// return slope and intercept of a line
  #//cout<<"xold="<<xold<<" xnew="<<xnew<<" told="<<told<<" tnew="<<tnew<<" a="<<a<<" b="<<b<<endl;
  if ((tnew-told)>1e-12):
    a=xold-told*(xnew-xold)/(tnew-told)#	//intercept
    b=(xnew-xold)/(tnew-told)#			//slope
  return(a,b)

def i1( gold, gnew, told, tnew):
  #// integral: i1 = \int G(t) dt

  g1=0.0;g2=0.0;
  g1,g2=coeff(gold,gnew,told,tnew)#;               // g1 = Intercept, g2 = Slope
  #//i11=tnew*(g1+g2*tnew/2)-told*(g1+g2*told/2);

#//tejas-changed 26.10.12
  i11=(tnew-told)*g1+(tnew-told)*(tnew+told)*g2/2; # // s*T/m+s^2*T/m
#//tejas-end
  return (i11)

def i4(gold,gnew,trold,trnew,told,tnew):
 # // integral: i4 = \int T(t) G(t) dt    : T(t) is translation

  g1,g2=coeff(gold,gnew,told,tnew);
  tr1,tr2=coeff(trold,trnew,told,tnew);
  e=tnew-told;
  a=g1*tr1;
  b=(g1*tr2+g2*tr1)/2;
  c=g2*tr2/3;
  i44=e*(a+e*(b+e*c))+told*e*(2*b+3*c*(e+told));
  
  return(i44)   

gam=42.58e6



# Model FID of a single spinning proton from scratch.

B0=3
Gx=.01
w0=gam*B0


FOVx=.24 #meters
dx=.002 # meters
Nx=FOVx/dx
Te=0.01 #seconds

dk=1/FOVx
Nk=Nx
Kfov=Nk*dk
TE=Kfov/(2*gam*Gx)

Kinitial=-1*Kfov/2


Ts=(2*TE)/Nx

BW=1.0/Ts

M0=1
T2s=.3



Tsamp=np.arange(Nx)*Ts
UpSamp=10
Tsim=np.arange((Nx*UpSamp+3))*Ts/UpSamp

fastdt=Ts/UpSamp
ginitial=Kinitial/(gam*Ts/UpSamp)

Gx=np.zeros(len(Tsim))
Gx[1]=ginitial
Gx[3:]=0.01









print len(Tsamp)
print len(Tsim)

print Tsamp[-1]
print Tsim[-1]


Sfull=[]
Kfull=[]
kx=0

xstart=-1*FOVx/2
px=xstart+0.06+.12
#px=0
MaxXmove=0.01
sampstart=300
sampend=len(Tsim)-1
lmove=sampend-sampstart


move=np.zeros(len(Tsim))
move[sampstart:sampend]=np.linspace(0,MaxXmove,lmove)
move[sampend:]=MaxXmove
# pl.plot(move)
# pl.show()

phase=0
phaseorig=0

Correction=[]

pxorig=px


for it,t in enumerate(Tsim[:-1]):
    
    
    gold=Gx[it]
    gnew=Gx[it+1]
    told=Tsim[it]
    tnew=Tsim[it+1]
    Ig=i1( gold, gnew, told, tnew)
    
    
    dt=Tsim[it+1]-t
    #B=px*Gx
    phase=phase+gam*Ig*px
    phaseorig=phaseorig+gam*Ig*pxorig    
    
    
    s=M0*np.exp(-t/T2s)*np.exp(-1j*phase*180/np.pi)
    Sfull.append(s)
    
    kx=kx+gam*Ig
    Kfull.append(kx)
    
    
    px=px+move[it+1]
    
    
    
    c=(phase-phaseorig)*180/np.pi
    Correction.append(c)
    

print 'Nx:\t{}'.format(Nx)
print 'Nk:\t{}'.format(Nk)
print 'Kfov:\t{}'.format(Kfov)
print 'TE:\t{}'.format(TE)
print 'Ts:\t{}'.format(Ts)
print 'BW:\t{}'.format(BW)
print 'w0:\t{}'.format(w0)
print 'xstart:\t{}'.format(xstart)
print 'px:\t{}'.format(px)
print 'BW:\t{}'.format(BW)
print 'BW:\t{}'.format(BW)







#Sfull=Sfull*np.cos(w0*np.pi/180*Tsim[:-1])
    
Sinds=np.arange(len(Sfull)).astype(int)[3::UpSamp]
print Sinds
Sfull=np.array(Sfull)
pl.plot(Tsim[:-1],np.real(Sfull),'g')

#print Sfull[list(Sinds)]
pl.stem(Tsim[Sinds],np.real(Sfull[Sinds]))
pl.figure()

Ssamp=Sfull[Sinds]
SsampF=np.fft.ifftshift(np.fft.ifft(Ssamp))
#SsampF=np.fft.ifft(Ssamp)

xax=np.linspace(xstart,-1*xstart,Nx)
pl.plot(xax,np.abs(SsampF))

pl.figure()
pl.plot(Kfull)

pl.figure()
Scor=Sfull*np.exp(1j*np.array(Correction))
Scorf=np.fft.ifftshift(np.fft.ifft(Scor[Sinds]))
pl.plot(xax,np.abs(Scorf))
pl.show()

pl.figure()
pl.plot(move)
pl.plot(Correction)

pl.show()







































