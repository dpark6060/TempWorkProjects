#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import seaborn as sb
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb


SubDir='/share/studies/Connectome/Subjects'
Subjects=glob.glob(os.path.join(SubDir,'*','tfMRI_WM_*','MotionCorrection','tfMRI_WM_[LR][LR]_mc.par'))

df=np.array([])
#,dtype={'names':('xRotation','yRotation','zRotation','xTranslation','yTranslation','zTranslation'),'formats':('f4','f4','f4','f4','f4','f4')}

f,ax=pl.subplots(2,3)

arrays=[np.loadtxt(sub) for sub in Subjects]
b=np.concatenate(arrays)
DF=pd.DataFrame(b,index=np.arange(b.shape[0]),columns=['xRotation_rads','yRotation_rads','zRotation_rads','xTranslation_mm','yTranslation_mm','zTranslation_mm'])
m=DF.mean()
sb.despine(left=True)
bins=np.linspace(-4,4,200)
result=[]
for i,dfa in enumerate(zip(DF.iteritems(),np.ravel(ax))):
    df=dfa[0]
    a=dfa[1]
    r=sb.distplot(df[1],bins=bins,ax=a,color=sb.color_palette()[i],hist_kws={"range": [-10,10]})
    result.append(r)
    #a.set_title(df[0])
    a.set_xlim([-2,2])
    yl=np.diff(a.get_ylim())
    xl=np.diff(a.get_xlim())
    
    a.plot([m[i],m[i]],[0,yl*.65],linewidth=2,color=sb.color_palette()[i])
    a.plot([m[i],m[i]+xl*.06],[yl*.65,yl*.75],linewidth=1,color=sb.color_palette()[i])
    a.text(m[i]+xl*.09,yl*.78,'{0:6f}'.format(m[i]))
    
# sb.distplot(DF.xRotation,ax=ax[0,0])
# sb.distplot(DF.yRotation,ax=ax[0,1])
# sb.distplot(DF.zRotation,ax=ax[0,2])
# sb.distplot(DF.xTranslation,ax=ax[1,0])
# sb.distplot(DF.yTranslation,ax=ax[1,1])
# sb.distplot(DF.zTranslation,ax=ax[1,2])
pl.setp(ax,yticks=[])
pl.tight_layout()
pl.show()