#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import scipy.stats as sts
import subprocess as sp

class Vector:
    def __init__(self,v=np.zeros(3)):
        self.v=v
        
    def translate(self,T,v=np.zeros(3)):
        tv=v+T
        return(tv)
        
    def rotate(self,theta,a):
        R=self.MakeRotMat(theta,a)
        rv=np.dot(self.v,R)
        return(rv)
    
    def xfm(self,trans,theta,a):
        self.v=self.translate(trans,self.v)
        rtv=self.rotate(theta,a)
        return(rtv)

    def set_v(self,newv):
        self.v=v
        
    def get_v(self):
        return self.v
    
    def get_mag(self):
        return np.sqrt(np.sum(np.square(self.v)))
    
    def get_angle(self,axis):
        # Returns the angle of the vector relative to an axis
        if axis==0:
            angle=np.arcsin(self.v[0]/self.get_mag())
        if axis==1:
            angle=np.arcsin(self.v[1]/self.get_mag())
        if axis==2:
            angle=np.arcsin(self.v[2]/self.get_mag())
        else:
            print('Axis must be 0,1, or 2 for x,y,z')
            angle=0
        return(angle)
    
    
    def MakeRotMat(self,theta,a):  
        A=[[0,-a[2],a[1]],[a[2],0,-a[0]],[-a[1],a[0],0]]        
        R=np.eye(3)+np.sin(theta*np.pi/180)*np.array(A)+(1-np.cos(theta*np.pi/180))*np.dot(A,A)
        return R



class voxel:
    def __init__(self,M=Vector(),T1=0,T2s=0,Phi=0,s=Vector()):
        self.MM=Vector(M.v)                # This is the Magnitude of the magnetic vector at T=0
        self.MzTheta=self.MM.get_angle(2)   # In Radians     # This is the angle of the voxel's magnetic vector relative to the Z axis (Mag vector is x,y,z convention, like all other vectors)
        self.M0=M                           # This will be the M immediatly after excitation for relaxation calculations
        self.T1=T1                          # The T1 value of this particular voxel
        self.T2s=T2s                        # The T2 value of this particular voxel
        self.Phi=Phi                        # The current XY phase of this particular voxel's Mxy vector
        self.Mxy=np.sqrt(np.square(self.MM.v[0])+np.square(self.MM.v[1]))   # The Magnitude of this voxel's Mxy vector
        self.Mxy0=self.Mxy                  # initial Mxy vector.  Worth storing to avoid calculating all the time.
        self.s=s                            # The location (in meters) of this voxel's center
        self.Mz=self.MM.v[2]

        
    def set_xyz(self,s):
        self.s=s
    def set_T1(self,t1):
        self.T1=T1
    def set_T2s(self,t2):
        self.T2s=t2
    def set_Phi(self,phi):
        self.Phi=phi
    def set_M(self,m):
        self.Mt=m
        self.MzTheta=self.Mt.get_angle(2)
        self.Mxy=np.sqrt(np.square(self.Mt.v[0])+np.square(self.Mt.v[1]))
        
    def get_xyz(self):
        return self.s
    def get_Phi(self):
        return self.Phi


    def recover(self,t):        
        
        self.Mxy=self.Mxy0*np.exp(-t/self.T2s)
        self.Mz=self.M0.v[2]*np.exp(-t/self.T1)+self.MM.v[2]*(1-np.exp(-t/self.T1))
        

        
        #print self.Mxy
        

            
        #print self.MzTheta
        # if self.M0==2:
        #     print't =\t{}\nMxy =\t{}\nMz =\t{}'.format(t,self.Mxy,self.Mz)

    def excite(self,angle):
        self.M0.v=self.MM.rotate(angle,[0,1,0])   # Apply the appropriate rotation in the z axis        
        self.MzTheta=angle                      # Rather than calculate the angle, we will just set it equal to what we just rotated.  This has been tested, it works.
        self.Mxy=np.sqrt(np.square(self.M0.v[0])+np.square(self.M0.v[1])) # Calculate Mxy
        self.Mz=self.M0.v[2]                    # Mz is just the first 
        self.Mxy0=self.Mxy
        if self.MM.v[-1]!=0:
            print self.Mxy0


        # print self.Mxy
        # print self.Mt.v





class Target:
    def __init__(self,tissue=np.zeros((1,1,1))):
        
        self.T1gm=1331e-3
        self.T2gm=51e-3
        self.xDim=4e-3
        self.yDim=4e-3
        self.zDim=4e-3
        self.Lx=tissue.shape[0]
        self.Ly=tissue.shape[1]
        self.Lz=tissue.shape[2]
        self.Cx=np.round(self.Lx/2.0)-1
        self.Cy=np.round(self.Ly/2.0)-1
        self.Cz=np.round(self.Lz/2.0)-1
        self.xfmMat=[[self.xDim,0,0],[0,self.yDim,0],[0,0,self.zDim]]
        self.xfmT=[-1*self.Cx,-1*self.Cy,-1*self.Cz]        
        self.obj=self.MakeVoxels(tissue)

    def cor2mil(self,x,y,z):

        mm=np.dot(self.xfmMat,[x,y,z])+self.xfmT
        return(mm)
    
    def MakeVoxels(self,tissue):
        Object=np.empty(tissue.shape,dtype=object)
        xxx=-1*(self.Lx-1)/2.0 # Starting point for x
        posx=[(xxx+i)*self.xDim for i in range(self.Lx)]
        yyy=-1*(self.Ly-1)/2.0
        posy=[(yyy+i)*self.yDim for i in range(self.Ly)]
        zzz=-1*(self.Lz-1)/2.0
        posz=[(zzz+1)*self.zDim for i in range(self.Lz)]
        for i,v in np.ndenumerate(tissue):
            
            s=Vector((posx[i[0]],posy[i[1]],posz[i[2]]))
            Object[i]=voxel(Vector([0,0,v]),self.T1gm,self.T2gm,0,s)
            if v>0:
                print s.v
                
                
            
        return Object
    
    def excite_Voxels(self,angle):
        m=None
        for i,v in np.ndenumerate(self.obj):
            #print v
            v.excite(angle)
            v.set_Phi(0)
            if v.MM.v[-1]!=0:
                m=v.Mxy
                #print m
        return(m)
    
    def recover_Voxels(self,dt):
        m=None
        for i,v in np.ndenumerate(self.obj):
            v.recover(dt)
            
            if v.MM.v[-1]!=0:
                m=v.Mxy
                #print m
        return(m)
    
    def reset_phase(self):
        for i,v in np.ndenumerate(self.obj):
            v.set_Phi(0)
    
    def get_Voxel(self,xyz):
        return self.obj[xyz]
     
class Pulse:
    def __init__(self,TR=3,gam=46.6e6,angle=90,Te=3e-3):

        self.TR=TR
        self.angle=angle
        self.Te=Te
        self.gammabar=gam
        
    def episequence(self,nVolumes,zc,nSlices,resZ,slcdir,phasedir,readdir,resX,resY,bottom,top,Bwrec,TRslc,rt,maxG,Nx,Ny,xDim,yDim,zDim):
         # Input parameters: n = number of volumes, ns = number of slices (per volume)
        #   ddz = slice thickness (m) , zc = coordinate of slice centre (m)
        #EPISEQUENCE MATRIX INPUTFILE
        #(1)=time in s,(2)=rf angle,(3)=rf frequency bandwidth df(Hz),(4)=rf center frequency fc(Hz),(5)=readout 1/0 (6)=x gradient(T/m),(7)=y gradient(T/m),(8)=z gradient(T/m)
        #TRslc=  TR/numslc for epi
                 #               =  TRline for ge 
        #Set up gradient directions
        if slcdir=='z+':
            sdindex=7
        if phasedir=='y+':
            pdindex=6
        if readdir=='x+':
            rdindex=5
        
        # Assuming z=slice y=phase, x=read, and all are in the positive direction
        simdir=1
        phdir=1
        redir=1
        angle_rad=self.angle*np.pi/180
        gdt=maxG/rt #calculate the delta gradient/sec (T/ms)
        
        # Slice Selection
        Gz=7.128e-3 # Slice selection gradient during rf Excitation (T/m)
        dtz=Gz/gdt # Time required for SS gradient to rise to Gz (s)
        rft=4*1e-3 # Not sure what this is - I think time of the RF pulse...added to dtz so must be (s)
        
        dtz11=np.sqrt(((rft+dtz)*Gz)/(2*gdt))
        Gz1 = ((rft+dtz)*Gz)/(2*dtz11)
        dtz1=dtz11*2.0
        # fig 26.1 - Gz*(rft+dtz) = area A+B+C+D assuming B=0 and A=D
        # will come back to all this
        # dtz11 is time for 0 to Gz1; dtz1 is the total time for the negative pulse
        TA=rft/2.0+dtz+dtz1 # Time at which all rf stuff is over
        # fir 26.1 - this is t9
        
        df=resZ*self.gammabar*Gz #frequency width - slice thickness(m) times the gradient (T/m) Times self.gammabar (Hz/T) (in m*Hz/T*T/m=Hz), kinda like bandwidth of slice?
        
        fc=np.array(zc)*self.gammabar*Gz # Center frequencies of slices
        
        # Read Out
        dtx=1.0/Bwrec # Sampling time along readout direction
        dkx=1.0/(resX*xDim) # K space incrament is 1/FOV
        dky=1.0/(resY*yDim)
        
        Gx=dkx/(self.gammabar*dtx) # from dtx*self.gammabar*Gx=dkx - gradient strength needed to move dkx hz in dtx seconds given gamma
        dt=Gx/gdt # how long it will take for the gradient to reach Gx
        
        dty=np.sqrt(4.0*dky/(self.gammabar*gdt)) # solving dty using a triangle pulse, dty is the full width of the pulse, solve using the integral and Gy(t)=gdt*t dky=self.gammabar*integral(Gy(t)dt)
        Gy=1.0/2.0*dty*gdt
        
        
        # These are for moving k space to the appropriate location before sampling starts
        dtx1=np.sqrt(Gx*(dt+resX*dtx)*2.0/gdt) # calculating center time if read gradient was a triangle??!?! A=Gx*(Nx*dtx+dt), in triangle: A=1/2*b*h, Gx*(Nx*dtx+dt)=1/2*b*h, h=gdt*b, solve for b - divided by two
        
        Gx1=dtx1*gdt/2.0 # Can't figure out equation for this, but it's half the gradient strength.  so this should move k space to the start of the x row.  Not sure why it's divided by two, though
        # It seems like dtx1 is the time it takes to make it half way across k space at maximum gradient.  maybe it's just because we don't need to go that fast.
        
        dty1=np.sqrt(bottom)*dty # initial dy, moving k space to the start of the y row.
        Gy1=dty1*gdt/2.0
        
        # More things
        TEl=bottom*(2.0*dt+(resX-1.0)*dtx)+(dt+resX/2.0*dtx) #from the self.Te which is the middle of the central k space line, how much time is acquired to the LEFT of the TE
        #Bottom number of lines * time to acquire a line +1/2 time to acquire one line
        TEr=top*(2.0*dt+(resX-1)*dtx)+(dt+(resX/2.0-1)*dtx) #from the TE which is the middle of the central k space line, how much time is acquired to the RIGHT of the TE
        #Top number of lines * time to acquire a line +1/2 time to acquire one line
        
        TD=self.Te-TEl  # Counting back from self.Te, subtract readout time occuring BEFORE self.Te
        TC=TD-dtx1 # Now Subtract the initial kspace x-placement (Frequency encoding)
        TB=TC-dty1 # minus the initial kspace y-placement (Phase encoding)
        TF=self.Te+TEr  # now calculate when the reading will be complete
        tcrush=2.0*rt # how long the crush gradient will be on
        TG=TF+2.0*rt*tcrush # what time the crush gradient will start.
        
        print('resX:\t{}'.format(resX))
        print('resY:\t{}'.format(resY))
        print('resZ:\t{}'.format(resZ))
        print('Bottom:\t{}'.format(bottom))
        print('Top:\t{}'.format(top))
        
        print('')   
        print('maxG:\t{}'.format(maxG))
        print('rt:\t{}'.format(rt))
        print('TRslc:\t{}'.format(TRslc))

        print('')
        print('df:\t{}'.format(df))
        print('rft:\t{}'.format(rft))
        print('dtz:\t{}'.format(dtz))
        print('dtz1:\t{}'.format(dtz1))
        print('')
        
        print('dt:\t{}'.format(dt))
        print('dtx:\t{}'.format(dtx))
        print('Gx:\t{}'.format(Gx))
        print('dtx1:\t{}'.format(dtx1))
        print('Gx1:\t{}'.format(Gx1))
        print('')

        print('dty:\t{}'.format(dty))
        print('Gy:\t{}'.format(Gy))
        print('dty1:\t{}'.format(dty1))
        print('Gy1:\t{}'.format(Gy1))
        print('')
        print('TE:\t{}'.format(self.Te))
        print('TEl:\t{}'.format(TEl))
        print('TEr:\t{}'.format(TEr))        
        print('TD:\t{}'.format(TD))
        print('TC:\t{}'.format(TC))
        print('TB:\t{}'.format(TB))
        print('TA:\t{}'.format(TA))
        print('TF:\t{}'.format(TF))
        print('TG:\t{}'.format(TG))
        
        
        
        
        
        # cout<<"Times in the acquisition of one slice starting from the RF pulse (in s)"<<endl;
        # cout<<"the slice selection gradient is done TA="<<TA<<endl;
        # cout<<"the phase encode gradient starts dephasing TB="<<TB<<endl;
        # cout<<"the phase encode gradient stops dephasing, and the read-out gradient starts dephasing TC="<<TC<<endl;
        # cout<<"the read-out gradient stops dephasing,begining of the read-out period TD="<<TD<<endl;
        # cout<<"echo time self.Te="<<self.Te<<endl;
        # cout<<"end of the read-out period and begining of the crushers TF="<<TF<<endl;
        # cout<<"end of the crushers TG="<<TG<<endl;
        # cout<<"end of the acquisition of one slice TRslc="<<TRslc<<endl;       
        
        TRF=0
        
        ###############################################
        ##         First loop to calculate size      ##
        ###############################################
        t=0 # start time
        step=1 # Row number in the matrix
        
        for a in range(nVolumes):
            for b in range(nSlices):
            
                #Slice Selection Gradient Rises
                t+=dtz
                step+=1
                #RF pulse turns on, SS gradient remains on, taken to mid line of RF pulse
                t+=rft/2
                step+=1
                TRF=t # Set this as the Time of the RF pulse
                #RF pulse finishes Gradient remains on
                t+=rft/2
                step+=1
                #Gradient turns off
                t+=dtz
                step+=1
                #Gradient goes negative to remove phase accumulation
                t+=dtz1/2
                step+=1
                #Negative gradient returns to zero
                t+=dtz1/2
                step+=1
                # From TRF, when do we start the frequency and phase encoding
                t=TRF+TB
                step+=1
                # Account for Phase Encoding
                t+=dty1/2
                step+=1
                t+=dty1/2
                step+=1
                
                t+=dtx1/2
                step+=1
                t+=dtx1/2
                step+=1
                
              
                # Now simulate sampling k space through frequency and phase
                for c in range(bottom+1+top):
                    # Now raise the initial readout gradient
                    if c==0:
                        # if we're just starting, just apply x gradient
                        t+=dt
                        step+=1
                    else:
                        # Otherwise it's a new slice and we need to incrament y
                        # Turn On or off Y Gradient
                        t+=dty/2
                        step+=1
                        #Turn Off Y Gradient...and something?
                        t+=dt-dty/2
                        step+=1
                    # Now loop through the readout
                    for d in range(resX-1):
                        # Gradient is on already, just start stepping
                        t+=dtx
                        step+=1
                    
                    # If we're at the last slice
                    if c==bottom+top:
                        # Add an x gradient DT
                        t+=dt
                        step+=1
                    else:
                        #Otherwise we have more slices to go, switch the x gradient
                        t+=dt-dty/2
                        step+=1
                        #and turn on Y Gradient
                        t+=dty/2
                        step+=1
                        
                
                # Now apply the Crushers              
                t+=rt
                step+=1
                t+=tcrush
                step+=1
                t+=rt
                step+=1
                
                # Account for previous volumes (a) and the current slice (b)
                t=TRslc*(b+1)+a*self.TR
                step+=1
            
            tt=t
            t=self.TR*(a+1)
            
            if t-tt>1e-6:
                step+=1
            if t-tt<-1e6:
                print ("Warning TR is shorter then Nslc*TRslc")
            
        ###############################################
        ##                  Main Loop                ##
        ###############################################
        
        nreadp=nVolumes*nSlices*resX*resY
        readstep=-1
        
        Pmatrix=np.zeros((step,8))
        #H: (1)=time in s,(2)=rf angle,(3)=rf frequency bandwidth df(Hz),(4)=rf center frequency fc(Hz),(5)=readout 1/0 (6)=x gradient(T/m),(7)=y gradient(T/m),(8)=z gradient(T/m)
        step=0
        t=0.0
        
        # Making matrix to save k space coordinates
        coord=np.zeros((2,nreadp))
        tindex=0
        
        #        if slcdir=='z+':
        #     sdindex=8 = cc
        # if phasedir=='y+':
        #     pdindex=7 = bb
        # if readdir=='x+':
        #     rdindex=6 = aa
        bhelp=0
        
        for a in range(nVolumes):
            for b in range(nSlices):
                kx=0
                ky=0
                kz=0
                
                #Slice Selection Gradient Rises
                t+=dtz;step+=1 #line1 (In Figure 1)
                Pmatrix[step,0]=t;Pmatrix[step,sdindex]=Gz 
                # Half the pulse time (Time to peak pulse) and set phase angle
                t+=rft/2;step+=1 # Line2
                Pmatrix[step,0]=t;Pmatrix[step,1]=angle_rad;Pmatrix[step,2]=df;Pmatrix[step,3]=fc[bhelp+simdir*b];Pmatrix[step,sdindex]=Gz
                TRF=t
                #Finish the other half of the pulse time
                t=t+rft/2 # Line3
                step+=1
                Pmatrix[step,0]=t
                Pmatrix[step,sdindex]=Gz
                kz+=Pmatrix[step,sdindex]*rft/2 # Move K space by the GZ*dt
                # Turn Off Gradient
                t+=dtz # Line4
                step+=1
                Pmatrix[step,0]=t
                kz=kz+Pmatrix[step,sdindex]*dtz/2
                #Begin Negative Z Gradient
                t+=dtz1/2 # Line5
                step+=1
                Pmatrix[step,0]=t
                Pmatrix[step,sdindex]=-Gz1
                kz=kz+Pmatrix[step,sdindex]*dtz1/4
                # Turn Off Negative Gradient
                t+=dtz1/2 # Line 6
                step+=1
                Pmatrix[step,0]=t
                kz=kz+Pmatrix[step-1,sdindex]*dtz1/4
                
                ##### END OF SLICE SELECTION ####
                
                # Move time forward to TB, where kx ky space movement begins
                t=TRF+TB# Line 7
                step+=1
                Pmatrix[step,0]=t # TB
                #Begin moving through Ky space
                t+=dty1/2# Line 8
                step+=1
                Pmatrix[step,0]=t
                Pmatrix[step,pdindex]=-phdir*Gy1
                ky=ky+Pmatrix[step,pdindex]*dty1/4
                #Turn of Gradient
                t+=dty1/2 # Line 9
                step+=1 # TC
                Pmatrix[step,0]=t
                ky=ky+Pmatrix[step-1,pdindex]*dty1/4
                # Turn on X Gradient for initial K space setup
                t+=dtx1/2# Line 10
                step+=1
                Pmatrix[step,0]=t
                Pmatrix[step,rdindex]=-redir*Gx1
                kx=kx+Pmatrix[step,rdindex]
                # Turn Off X Gradient
                t+=dtx1/2# Line 11
                step+=1 # TD
                Pmatrix[step,0]=t
                kx=kx+Pmatrix[step-1,rdindex]
                
                #### END OF K SPACE INITIALIZATION ####
                ####          BEGIN READOUT        ####
                print bottom+1+top
                for c in range(bottom+1+top):
                    # If it's the first line of the slice
                    if c==0:
                        #Ramp the X Gradient up
                        t+=dt # Line 12
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,4]=1 # Read on
                        Pmatrix[step,rdindex]=redir*Gx
                        kx=kx+Pmatrix[step,rdindex]*dt/2
                        # Update K space Coordinates
                        readstep+=1
                        coord[0,readstep]=kx*self.gammabar
                        coord[1,readstep]=ky*self.gammabar
                        
                    elif dt-dty/2>=0: # If the y gradient can rise and fall enough in the time between x gradient shifts:
                        # If we've made it here and it's not the first line, we must be switching to a new line, and the y gradient is already on
                        # Ramp down the y gradient while also ramping the x in the current read direction
                        t+=dty/2 # Line 16
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,rdindex]=np.power(-1,c)*dty*gdt/2
                        ky=ky+dty*Pmatrix[step-1,pdindex]/4 #Change ramping down
                        kx=kx+Pmatrix[step,rdindex]*dty/4 # X change while y was ramping down
                        
                        # Y is ramped down, but x still has changing to do
                        t+=dt-dty/2 #Line 17
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,4]=1 # Turn on read gradient
                        Pmatrix[step,rdindex]=np.power(-1,c)*redir*Gx
                        kx=kx+(Pmatrix[step,rdindex]+Pmatrix[step-1,rdindex])*(dt-dty/2)/2
                        readstep=readstep+1
                        coord[0,readstep]=kx*self.gammabar
                        coord[1,readstep]=ky*self.gammabar
                    else: # If the y gradient will take longer to rise and fall:
                        t+=dty/2-dt # Begin lowering the y gradient, leave x at 0
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,4]=1
                        Pmatrix[step,pdindex]=Gy-(phdir*(dty/2-dt)*gdt) # Decrease the y gradient as much as posible during dty/2-dt
                        ky+=1/2*(dty/2-dt)*(Gy+Pmatrix[step,pdindex])
                        
                        t+=dt # Step how long till Gx reaches peak
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,rdindex]=np.power(-1,c)*redir*Gx
                        ky+=1/2*dt*Pmatrix[step-1,pdindex]
                        kx+=1/2*dt*Pmatrix[step,rdindex]
                        readstep=readstep+1
                        coord[0,readstep]=kx*self.gammabar
                        coord[1,readstep]=ky*self.gammabar                       
                        

                        
                        
                        #Between lines 12 and 13
                    for d in range(resX-1):
                        # Loop through the read line
                        t+=dtx
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,4]=1 # Turn on Read Gradient
                        Pmatrix[step,rdindex]=np.power(-1,c)*redir*Gx # switch direction with each line
                        kx=kx+Pmatrix[step,rdindex]*dtx
                        readstep+=1
                        # If we've reached the middle of k space
                        if c+1==bottom+1 and d==resX/2:
                            print('------')
                            print('Time at center or k is:\t{}'.format(t-(a)*self.TR-dtz-rft/2))
                            print('Time we want is:\t{}'.format(self.Te))
                            print('Center of kspace for VolNum {} and slice num {} is (kx,ky)=({},{})'.format(a,b,kx*self.gammabar,ky*self.gammabar))
                            print('-------')
                        coord[0,readstep]=kx*self.gammabar
                        coord[1,readstep]=ky*self.gammabar
                        
                    # If we're on the top line
                    if c+1==bottom+1+top:
                        t+=dt # Ramp down the X gradient
                        step+=1
                        Pmatrix[step,0]=t
                        kx=kx+Pmatrix[step-1,rdindex]*dt/2 # TF
                    # Otherwise switch gradient directions
                    elif dt-dty/2>=0: # If the y gradient can rise and fall enough in the time between x gradient shifts:
                        #Begin lowering the x gradieng
                        
                        t+=dt-dty/2 # At some point while the x gradient is lowering, begin raising the y gradient so it peaks when x=0
                        step+=1 # Line 14
                        Pmatrix[step,0]=t
                        Pmatrix[step,rdindex]=np.power(-1,c)*dty*gdt/2 # Gradient at this point is equavalent to raising at gdt for dty seconds
                        kx=kx+(Pmatrix[step-1,rdindex]+ Pmatrix[step,rdindex])*(dt-dty/2)/2 # Triangle area subtraction
                        # Begin Raising the y gradient while still lowering x
                        t+=dty/2#line 15
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,pdindex]=phdir*Gy
                        ky=ky+dty*Pmatrix[step,pdindex]/4
                        kx=kx+Pmatrix[step-1,rdindex]*dty/4 # TG
                            
                    else:
                        t+=dt # Lower the x gradient
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,pdindex]=phdir*dt*gdt # Increase the y gradient as much as posible during dt
                        kx+=1/2*dt*Pmatrix[step-1,rdindex]
                        ky+=1/2*dt*Pmatrix[step,pdindex]
                        
                        t+=dty/2-dt # Step how long till Gy reaches peak
                        step+=1
                        Pmatrix[step,0]=t
                        Pmatrix[step,pdindex]=phdir*Gy
                        ky+=1/2*(dty/2-dt)*(Pmatrix[step-1,pdindex]+Pmatrix[step,pdindex])
 
                            
                # Crushers
                t+=rt
                step+=1
                Pmatrix[step,0]=t
                Pmatrix[step,rdindex]=maxG
                Pmatrix[step,pdindex]=maxG
                Pmatrix[step,sdindex]=maxG
                t+=tcrush
                step+=1
                Pmatrix[step,0]=t
                Pmatrix[step,rdindex]=maxG
                Pmatrix[step,pdindex]=maxG
                Pmatrix[step,sdindex]=maxG
                t+=rt
                step+=1
                Pmatrix[step,0]=t
            
            t=self.TR*(a+1)
            if t-Pmatrix[step,0]>1e-6:
                step=step+1
                Pmatrix[step,0]=t
            if t-Pmatrix[step,0]<-1e-6:
                print('WARNING TR is shorter than Nslc*TRslc')
                

        return(Pmatrix)        
                            
class Scanner:
    def __init__(self,B0=1,target=Target()):
        self.gamma=42.58*1e6   #MHz/T
        self.B0=B0
        self.Target=target
        self.G=Vector(np.zeros((3)))
        self.grf=Vector(np.zeros(3))
        self.oldG=self.G
        self.GintRF=self.G  # This tracks the integral of the gradients since the last RFpulse      
        
        self.theta=0
        self.a=[0,0,0]
        self.R=self.G.MakeRotMat(self.theta,self.a)
        self.T=Vector(np.zeros(3))

        self.Bwrec=1e5        
        self.TR=3
        self.angle=90
        
        self.Nx=target.Lx
        self.Ny=target.Ly
        self.Nz=target.Lz
        
        self.maxG=5.5e-2 #T/m
        self.risetime=2.2e-4 #s
        
        # The target image may be larger than the fmri in the future.  For now they are the same.
        self.resX=self.Nx
        self.resY=self.Ny
        self.resZ=self.Nz
        self.TRslc=self.TR/self.Nz
        
        self.xDim=target.xDim
        self.yDim=target.yDim
        self.zDim=target.zDim
        
        self.posx=np.zeros(self.Nx)
        self.posy=np.zeros(self.Ny)
        self.posz=np.zeros(self.Nz)
        
        # Set up x,y,z mid coordinates and the extending coordinate system
        self.xxx=-1*(self.Nx-1)/2.0 # Starting point for x
        self.posx=[(self.xxx+i)*self.xDim for i in range(self.Nx)]
        self.yyy=-1*(self.Ny-1)/2.0
        self.posy=[(self.yyy+i)*self.yDim for i in range(self.Ny)]
        self.zzz=-1*(self.Nz-1)/2.0
        self.posz=[(self.zzz+1)*self.zDim for i in range(self.Nz)]
        
        self.nSlices=self.Nz
        self.nVolumes=1
        
        #Slice Selection - only 2d for now
        self.ss=0
        self.zc=[self.ss] # list of slice centers
        
        #Number of lines of k-space bellow and above the central line?
        self.top=int(0)
        self.bottom=int(0)
        self.startkspace=1
        
        # Currently the whole ROI of the target is the entire target
        self.cover=100
        self.dt=0
        self.time=0
        self.TRF=0
        
        self.dkx=0
        self.dky=0
        self.dkz=0
        
        
        if self.resY%2==0:  # If the number of voxels in y is an even number
            self.bottom=int(round((self.cover-50)*self.resY/100)) # the bottom number of voxels is the total number in y times the percentage divided by 100, giving a fraction of voxels
            self.top=int(self.resY/2.0-1)
            self.startkspace=self.resY/2-self.bottom+1 # Set the kspace starting point to half the y voxels minus the number on the bottom plus one (for cover =100, this =1) 
        else:
            self.bottom=int(round((self.cover-50)*(self.resY-1)/100))
            self.top=int((self.resY-1)/2)
            self.startkspace=(self.resY-1)/2.0-self.bottom+1
        
        self.pulse=Pulse(self.TR,self.gamma,90,3e-2)
        
    def CalcPulse(self):            
        Pmat=self.pulse.episequence(self.nVolumes,self.zc,self.nSlices,self.resZ,'z+','y+','x+',self.resX,self.resY,self.bottom,self.top,
                                self.Bwrec,self.TRslc,self.risetime,self.maxG,self.Nx,self.Ny,self.xDim,self.yDim,self.zDim)
        return Pmat
    
    def set_time(self,newt):
        self.dt=newt-self.time
        self.time=newt
        
    def set_G(self,newG):
        self.oldG=self.G
        self.G=newG
        self.dkx,self.dky,self.dkz=self.modK(self.G,self.oldG)
        
    def set_R(self,newR):
        self.R=newR
        
    def set_T(self,newT):
        self.T=newT
        
    def get_time(self):
        return(self.time)
        
    def CalcPhase(self,V=voxel()):
        dot1=np.dot(self.G.v,V.s.xfm(self.T.v,self.theta,self.a))
        dot2=np.dot(self.oldG.v,V.s.xfm(self.T.v,self.theta,self.a))
        
        
        #print V.s.v
        # print dot
        # print type(dot)
        dPhi=-1*self.gamma*1/2*(dot1+dot2)*self.dt
        #dPhi=-1*self.gamma*dot1*self.dt
        Phi=V.get_Phi()+dPhi
        V.set_Phi(Phi)
        # dPhi=self.gamma*dot
        # V.set_Phi(dPhi)        
        # if V.MM.v[2]>0:            
        #     print dPhi
        #print 'G.v:{}'.format(self.G.v)
        #print 'V.s xfm: {}'.format(V.s.xfm(self.T.v,self.theta,self.a))
        return(Phi)
    
    def Calc_TargetPhase(self):
        rp=0
        for i,V in np.ndenumerate(self.Target.obj):
            dot1=np.dot(self.G.v,V.s.xfm(self.T.v,self.theta,self.a))
            dot2=np.dot(self.oldG.v,V.s.xfm(self.T.v,self.theta,self.a))

            #dPhi=-1*self.gamma*dot1*self.dt
            dPhi=-1*self.gamma*1/2*(dot1+dot2)*self.dt
            Phi=V.get_Phi()+dPhi
            V.set_Phi(Phi)
            # dPhi=self.gamma*dot
            # V.set_Phi(dPhi)
            if V.MM.v[-1]!=0:
                rp=Phi
                #print rp
        return(rp)
        
    
    def calcMxy(self,V=voxel()):    
        
        Phi=self.CalcPhase(V)
        Mxy=V.Mxy
        # if V.MM.v[2]>0:
        #     print Mxy
        return(Mxy,Phi)
    
    def CalculateVolume(self):
        SigReal=[]
        SigImag=[]
        rp=0
        for i,V in np.ndenumerate(self.Target.obj):            
            Mxy,Phi=self.calcMxy(V)                         # Calculates Bulk Mxyz
            Fx=0.5*self.gamma*self.xDim*(self.GintRF.v[0])*2*np.pi    # Simulate gradient across voxel (MRI simulator with object-specific field map calculations, Yoder et al, eq 24 amd eq 20 in possum)
            Fy=0.5*self.gamma*self.xDim*(self.GintRF.v[1])*2*np.pi    
            Fz=0.5*self.gamma*self.xDim*(self.GintRF.v[2])*2*np.pi       
            #SigReal.append(self.xDim*self.yDim*self.zDim*np.abs(Mxy)*np.sin(Fx)/Fx*np.sin(Fy)/Fy*np.sin(Fz)/Fz*np.cos(Phi*2*np.pi))# eQ 20 in possum
            #SigImag.append(self.xDim*self.yDim*self.zDim*np.abs(Mxy)*np.sinc(Fx)*np.sinc(Fy)*np.sinc(Fz)*np.sin(Phi*2*np.pi))
            SigReal.append(self.xDim*self.yDim*self.zDim*Mxy*np.cos(Phi*2*np.pi))# eQ 20 in possum
            SigImag.append(self.xDim*self.yDim*self.zDim*Mxy*np.sin(Phi*2*np.pi))
            # SigReal.append(self.xDim*self.yDim*self.zDim*Mxy*np.cos(-1*self.gamma*self.B0*self.time-Phi))# eQ 20 in possum
            # SigImag.append(self.xDim*self.yDim*self.zDim*Mxy*np.sin(-1*self.gamma*self.B0*self.time-Phi))
            #print Phi
            if V.MM.v[-1]!=0:
                rp=Phi
                #print rp
        return(SigReal,SigImag,rp)
    
    def CalculateVolume_R(self):
        Sig=[]
        for i,V in np.ndenumerate(self.Target.obj):
            Mxy,Phi=self.calcMxy(V)
            Sig.append(Mxy)
            self.Target.obj[i].set_Phi(Phi)
            self.Target.obj[i].set_Mxy(Mxy)
        return(Sig)
    
    def modK(self,G1=Vector(),G2=Vector()):
        # Assumes that G never crosses zero in the middle of a step
        x1,y1,z1=G1.get_v()
        x2,y2,z2=G2.get_v()
        dx=0.5*self.dt*(x1+x2)*self.gamma
        dy=0.5*self.dt*(y1+y2)*self.gamma
        dz=0.5*self.dt*(z1+z2)*self.gamma
        return(dx,dy,dz)
        
    def CalculateTimeSeries(self,Pmat,Rotate=None,Translate=None):
        xstart=0
        xend=self.Nx
        ystart=0
        yend=self.Ny
        zend=self.Nz
        sszz_slc=1
        
        # Slice Selection
        slcdir=1
        if np.abs(slcdir)==1:
            sszdim=self.zDim
            ssNz=self.Nz
        # Skipping a lot of z slice selection
        
        MyPhi=[0]
        MyMxy=[0]
        
        # No Motion
        if Rotate==None and Translate==None:
            nreadp=self.nVolumes*self.nSlices*self.resX*self.resY
            Sig=np.zeros((2,nreadp))
            sreal=np.zeros(nreadp)
            simag=np.zeros(nreadp)
            print nreadp
            
            voxelCounter=0
            cxyz=self.xDim*self.yDim*self.zDim
            
            Nxx=len(self.posx)
            
            numpoints=Pmat.shape[0]
            readstep=0
            
            
            Kx=[0]
            Ky=[0]
            Time=Pmat[1:,0]
            
            for it,t in enumerate(Time):
                  
                self.set_time(t)
                self.set_G(Vector(Pmat[it+1,5:8]))
                self.angle=Pmat[it+1,1]*180/np.pi
                

                
                # If there is an RF pulse
                if Pmat[it+1,1]!=0:     
                    self.TRF=t                              # Mark this as the RF time
                    self.GintRF=Vector()                    # Reset the gradient Integrals
                    self.Target.reset_phase()
                    m=self.Target.excite_Voxels(self.angle) # Excite the target
                    if m!=None:
                        MyMxy.append(m)
                        print('woo')
                    self.dt=0
                else:
                    m=self.Target.recover_Voxels(self.time-self.TRF)
                    if m!=None:
                        MyMxy.append(m)
                # Calculate movement in Kspace due to gradients
                
                Kx.append(Kx[-1]+self.dkx)
                Ky.append(Ky[-1]+self.dky)                
                
                # if self.oldG.get_v()[0]!=0 or self.G.get_v()[0]!=0:
                #     self.GintRF.v[0]+=dkx
                # if self.oldG.get_v()[1]!=0 or self.G.get_v()[1]!=0:
                #     self.GintRF.v[1]+=dkx                
                # if self.oldG.get_v()[2]!=0 or self.G.get_v()[2]!=0:
                #     self.GintRF.v[2]+=dkx
                
                # Update the gradient integrals
                self.GintRF.v[0]+=self.dkx
                self.GintRF.v[1]+=self.dky                
                self.GintRF.v[2]+=self.dkz  
                
                
                # If there is readout
                if Pmat[it+1,4]==1:
                    Vreal,Vimag,ph=self.CalculateVolume()
                    sreal[readstep]=np.sum(Vreal)
                    #print np.sum(Vreal)
                    simag[readstep]=np.sum(Vimag)
                    MyPhi.append(ph)
                    readstep+=1
                else:
                    ph=self.Calc_TargetPhase()
                    MyPhi.append(ph)

            print self.TRF
            return(sreal,simag,Kx,Ky,MyPhi,MyMxy)
        
        
        elif Rotate==None:
            print ('Translation only Code')
            return []
        
        elif Translate==None:
            print('Rotation Only Code')
            return []
        
        else:
            print('rotation and translation code')
            return []
        
    def ReshapeSig(self,SigReal,SigImag):
        Npts=len(SigReal)
        Nvxl=self.resX*self.resY*self.resZ
        
        if Npts!=Nvxl:
            print'Npts:\t{}\nNvxl:\t{}'.format(Npts,Nvxl)
            return()
        Img=np.zeros(self.Target.obj.shape,'complex')
        
        readCount=0
        xCount=0
        yCount=0
        Xmod=-1
        for y in range(self.resY):
            Xmod=Xmod*-1
            for x in range(self.resX):
                Img[xCount,y]=SigReal[readCount]+1j*SigImag[readCount]
                xCount+=Xmod
                readCount+=1
            if xCount==self.resX:
                xCount-=1
            elif xCount==-1:
                xCount+=1
         

        return(Img)
    
        



t=np.zeros((13,13,1))
t[5,2,0]=1
# #t[1,1,0]=2
# t[9,9,0]=2

# t[2:8,1,0]=2
# t[5,2,0]=1
# t[2:8,3,0]=2
# 
# t[2,5,0]=2
# t[4:8,5,0]=1
# 
# t[2:6,7,0]=1
# t[8,7,0]=2


tar=Target(t)

NVols=161
t0=0

scan=Scanner(3,tar)
Pmat=scan.CalcPulse()

np.savetxt('/home/dparker/Desktop/MyPulse.txt',Pmat)

r,c=np.shape(Pmat)
print np.shape(Pmat)

# for ic in range(c):
#     #pl.figure()
#     pl.subplot(c,1,ic)
#     pl.plot(Pmat[:,0],Pmat[:,ic])
#     pl.title('Pmat Row {}'.format(ic))
#     #pl.xlim([0,.035])
# pl.show()
# 



#scan.set_G(Vector([.5,0,0]))

rsig,isig,Kx,Ky,ph,mx=scan.CalculateTimeSeries(Pmat)
# print rsig
# print isig
# rsig=range(len(rsig))
# isig=np.zeros(len(isig))
# rsig[0]=rsig[-1]
# rsig[-1]=0
# rsig[11]=0
# rsig[12]=100
print len(ph)
rsig=rsig*1e6
isig=isig*1e6
Sig=scan.ReshapeSig(rsig,isig)
#Sig=np.rot90(Sig)
pl.matshow(np.abs(Sig[:,:,0]))
fSig2D=np.fft.fftshift(np.fft.ifft2(Sig[:,:,0]))

# # print fSig2D
# # print np.shape(fSig2D)
# pl.matshow((np.abs(fSig2D)))
# pl.matshow(t[:,:,0])
# 
# 
# pl.figure()
# pl.plot(Kx,Ky)
# pl.title('Kspace')
# pl.figure()
# pl.plot((rsig))
# pl.title('realSig')
# pl.figure()
# pl.plot(ph)
# pl.title('phi')
# pl.figure()
# pl.plot(mx)
# pl.title('mxy')
# pl.show()

Line1=fSig2D[5,:]

t[5,9,0]=1

tar=Target(t)

NVols=161
t0=0

scan=Scanner(3,tar)
Pmat=scan.CalcPulse()
rsig,isig,Kx,Ky,ph,mx=scan.CalculateTimeSeries(Pmat)
rsig=rsig*1e6
isig=isig*1e6
Sig=scan.ReshapeSig(rsig,isig)
pl.matshow(np.abs(Sig[:,:,0]))
fSig2D=np.fft.fftshift(np.fft.ifft2(Sig[:,:,0]))
Line2=fSig2D[5,:]

t=np.zeros((13,13,1))
t[5,9,0]=1

tar=Target(t)

NVols=161
t0=0

scan=Scanner(3,tar)
Pmat=scan.CalcPulse()
rsig,isig,Kx,Ky,ph,mx=scan.CalculateTimeSeries(Pmat)
rsig=rsig*1e6
isig=isig*1e6
Sig=scan.ReshapeSig(rsig,isig)
pl.matshow(np.abs(Sig[:,:,0]))
fSig2D=np.fft.fftshift(np.fft.ifft2(Sig[:,:,0]))
Line3=fSig2D[5,:]


pl.figure()
pl.plot(Line1)
pl.plot(Line3)
pl.plot(Line2)
pl.legend(['Pos1','Pos2','Pos1+2'])

pl.figure()
pl.plot((Line1+Line3)-Line2)
pl.title('difference')
pl.show()

# for it,ir in zip(t,Rotate):
#     dt=it-Told
# 
#     Mxy,Phi=calcMxy(scan.Target.M0[7,0,0],t0,it,scan.Target.T2s[7,0,0],scan.Target.T1[7,0,0],scan,[9,0,0],scan.Target.phi[7,0,0],dt)
# 
#     Sig.append(Mxy)
#     scan.Target.Set_Mxy(Mxy,7,0,0)
#     scan.Target.Set_phi(Phi,7,0,0)
#     
#     Told=it




# pl.plot(np.real(Sig))
# pl.figure()
# s=np.abs(np.fft.fftshift(np.fft.fft(Sig)))
# pl.plot(s)
# pl.figure()
# # newsig=np.reshape(s,(15,5))
# # pl.imshow(newsig)
# 
# pl.show()




# def calcPhase(gam,dt,G,R,T,s,Phi0=0):
# 
#     
#     Phi=Phi0+gam*np.dot(G,np.dot(R,s)+T)   
#     return(Phi)
# 
# 
# def makeRotd(ax,ay,az,theta):
#     A=[[0,-az,ay],[az,0,-ax],[-ay,ax,0]]
#     R=np.eye(3)+np.sin(theta*np.pi/180)*np.array(A)+(1-np.cos(theta*np.pi/180))*np.dot(A,A)
#     return R
# 
# def calcMxy(Mxy0,t0,t1,T2s,T1,scanner,s,Phi=0,dt=None):
#     if dt==None:
#         dt=t1-t0    
#     gamma=46.6e6   #MHz/T
#     
#     mm=scanner.Target.cor2mil(s[0],s[1],s[2])
# 
#     Phi=calcPhase(gamma,dt,scanner.G,scanner.R,scanner.T,mm,Phi)
#     Mxy=np.exp(-(t1-t0)/T2s)*np.abs(Mxy0)*np.exp(-1j*Phi)
#     return(Mxy,Phi)





    

# d=45
# R=makeRotd(1,0,0,d)
# print R
# V=np.array([0,1,0])
# print np.dot(R,V)
