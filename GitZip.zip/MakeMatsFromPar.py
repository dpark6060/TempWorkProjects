#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import scipy.stats as sts
import subprocess as sp

def Trans(x,y,z):
    Translate=[[1,0,0,x],[0,1,0,y],[0,0,1,z],[0,0,0,1]]
    return Translate

def Rotx(theta):
    rotx_mat=[[1,0,0,0],[0,np.cos(theta),-1*np.sin(theta),0],[0,1*np.sin(theta),np.cos(theta),0],[0,0,0,1]]
    return rotx_mat

def Roty(theta):
    roty_mat=[[np.cos(theta),0,1*np.sin(theta),0],[0,1,0,0],[-1*np.sin(theta),0,np.cos(theta),0],[0,0,0,1]]
    return roty_mat

def Rotz(theta):
    rotz_mat=[[np.cos(theta),-1*np.sin(theta),0,0],[1*np.sin(theta),np.cos(theta),0,0],[0,0,1,0],[0,0,0,1]]
    return rotz_mat


def Combine(MatList):
    Mat=MatList.pop(-1)
    
    while MatList:
        Mat=np.dot(Mat,MatList.pop(-1))
    
    return Mat

def MakeRotMat(rx=0,ry=0,rz=0):
    Rx=Rotx(rx)
    Ry=Roty(ry)
    Rz=Rotz(rz)
    R=combine([Rx,Ry,Rz])
    return(R)



def ParToDiffPar(par):
    base,trash=os.path.splitext(par)
    par=np.loadtxt(par)
    pard=np.diff(par,axis=0)
    pard=np.vstack((np.zeros(6),pard))
    parDiffOut=os.path.join('{}_diff.par'.format(base))
    np.savetxt(parDiffOut,pard)


    
def ParFromPossumMot(Tr,te,mot,Nt):
    base,trash=os.path.splitext(mot)
    mot=np.loadtxt(mot)
    t=mot[:,0]
    t=np.hstack((t,(Nt+1)*Tr))
    
    mpar=mot[:,1:]
    mpar=np.vstack((mpar,mpar[-1,:]))
    
    
    newT=np.arange(0,(Nt*Tr),Tr)+te
    
    NewMpar=np.zeros((len(newT),6))
    
    Order=[3,4,5,0,1,2]
    
    for i,o in enumerate(Order):
        NewMpar[:,o]=np.interp(newT,t,mpar[:,i])
    
    ParOut=os.path.join('{}_mcflirt.par'.format(base))
    np.savetxt(ParOut,NewMpar)
    ParToDiffPar(ParOut)
    



