#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import seaborn as sb
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb




def LoadKspaceDat(filename,Nx,Ny,Nz,Nt):
    
    k_bin=np.fromfile(filename,dtype='float64')
    kspace_4D=np.reshape(k_bin,(Nz,Nt,Nx*Ny,2))
    kspace_4D=np.swapaxes(kspace_4D,0,2)
    print kspace_4D.shape
    
    pl.plot(kspace_4D[:,0,6,0],kspace_4D[:,0,6,1])
    pl.show()
    return(kspace_4D)
    #MyKx=np.zeros((Nx,Ny,Nz,Nt))
    #MyKy=np.zeros((Nx,Ny,Nz,Nt))
    

    
    
