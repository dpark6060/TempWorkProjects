#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb
import scipy.ndimage as spnd
import scipy as scp
from matplotlib.colors import LogNorm
from scipy.optimize import minimize
from matplotlib import cm
import FreqDomainResampSupport as rs
import scipy.ndimage as ndi

def phantom (matrix_size = 256, phantom_type = 'Modified Shepp-Logan', ellipses = None):
    """
    Create a Shepp-Logan or modified Shepp-Logan phantom::
        phantom (n = 256, phantom_type = 'Modified Shepp-Logan', ellipses = None)
    :param matrix_size: size of imaging matrix in pixels (default 256)
    :param phantom_type: The type of phantom to produce.
        Either "Modified Shepp-Logan" or "Shepp-Logan". This is overridden
        if ``ellipses`` is also specified.
    :param ellipses: Custom set of ellipses to use.  These should be in
        the form::
            [[I, a, b, x0, y0, phi],
            [I, a, b, x0, y0, phi],
                            ...]
        where each row defines an ellipse.
        :I: Additive intensity of the ellipse.
        :a: Length of the major axis.
        :b: Length of the minor axis.
        :x0: Horizontal offset of the centre of the ellipse.
        :y0: Vertical offset of the centre of the ellipse.
        :phi: Counterclockwise rotation of the ellipse in degrees,
            measured as the angle between the horizontal axis and
            the ellipse major axis.
    The image bounding box in the algorithm is ``[-1, -1], [1, 1]``,
    so the values of ``a``, ``b``, ``x0``, ``y0`` should all be specified with
    respect to this box.
    :returns: Phantom image
    References:
    Shepp, L. A.; Logan, B. F.; Reconstructing Interior Head Tissue
    from X-Ray Transmissions, IEEE Transactions on Nuclear Science,
    Feb. 1974, p. 232.
    Toft, P.; "The Radon Transform - Theory and Implementation",
    Ph.D. thesis, Department of Mathematical Modelling, Technical
    University of Denmark, June 1996.
    """

    if (ellipses is None):
        ellipses = _select_phantom (phantom_type)
    elif (np.size (ellipses, 1) != 6):
        raise AssertionError ("Wrong number of columns in user phantom")

    ph = np.zeros ((matrix_size, matrix_size),dtype=np.float32)

    # Create the pixel grid
    ygrid, xgrid = np.mgrid[-1:1:(1j*matrix_size), -1:1:(1j*matrix_size)]

    for ellip in ellipses:
        I   = ellip [0]
        a2  = ellip [1]**2
        b2  = ellip [2]**2
        x0  = ellip [3]
        y0  = ellip [4]
        phi = ellip [5] * np.pi / 180  # Rotation angle in radians

        # Create the offset x and y values for the grid
        x = xgrid - x0
        y = ygrid - y0

        cos_p = np.cos (phi)
        sin_p = np.sin (phi)

        # Find the pixels within the ellipse
        locs = (((x * cos_p + y * sin_p)**2) / a2
        + ((y * cos_p - x * sin_p)**2) / b2) <= 1

        # Add the ellipse intensity to those pixels
        ph [locs] += I

    return ph

def _select_phantom (name):
    if (name.lower () == 'shepp-logan'):
        e = _shepp_logan ()
    elif (name.lower () == 'modified shepp-logan'):
        e = _mod_shepp_logan ()
    else:
        raise ValueError ("Unknown phantom type: %s" % name)
    return e

def _shepp_logan ():
    #  Standard head phantom, taken from Shepp & Logan
    return [[   2,   .69,   .92,    0,      0,   0],
            [-.98, .6624, .8740,    0, -.0184,   0],
            [-.02, .1100, .3100,  .22,      0, -18],
            [-.02, .1600, .4100, -.22,      0,  18],
            [ .01, .2100, .2500,    0,    .35,   0],
            [ .01, .0460, .0460,    0,     .1,   0],
            [ .02, .0460, .0460,    0,    -.1,   0],
            [ .01, .0460, .0230, -.08,  -.605,   0],
            [ .01, .0230, .0230,    0,  -.606,   0],
            [ .01, .0230, .0460,  .06,  -.605,   0]]

def _mod_shepp_logan ():
    #  Modified version of Shepp & Logan's head phantom,
    #  adjusted to improve contrast.  Taken from Toft.
    return [[   1,   .69,   .92,    0,      0,   0],
            [-.80, .6624, .8740,    0, -.0184,   0],
            [-.20, .1100, .3100,  .22,      0, -18],
            [-.20, .1600, .4100, -.22,      0,  18],
            [ .10, .2100, .2500,    0,    .35,   0],
            [ .10, .0460, .0460,    0,     .1,   0],
            [ .10, .0460, .0460,    0,    -.1,   0],
            [ .10, .0460, .0230, -.08,  -.605,   0],
            [ .10, .0230, .0230,    0,  -.606,   0],
            [ .10, .0230, .0460,  .06,  -.605,   0]]


def zero_pad_image(img,newsize):
    x,y=np.shape(img)
    xpad=(newsize-x)/2.0
    if np.mod(xpad,2)!=0:
        xpad=int((newsize+1-x)/2.0)
    xsize=int(xpad*2+x)
    
    ypad=(newsize-y)/2.0
    if np.mod(ypad,2)!=0:
        ypad=int((newsize+1-y)/2.0)
    ysize=int(ypad*2+x)
    
    new_image=np.zeros((xsize,ysize))
    new_image[int(xpad):int(xpad+x),int(ypad):int(ypad+y)]=img
    
    return(new_image)


def zero_pad_complex(img,newsize):
    ZpadR=zero_pad_image(np.real(img),newsize)
    ZpadI=zero_pad_image(np.imag(img),newsize)
    Zpad=ZpadR+1j*ZpadI
    del ZpadR
    del ZpadI
    return(Zpad)
    
def create_kspace(Nx,Ny,dx=1,dy=1,angle=[0],sample_zero=False):
    
    Nk=Nx*Ny
    
    if len(angle)==1 and angle[0]!=0:
        angle=np.linspace(0,angle[0],Nk)
    elif len(angle)==1 and angle[0]==0:
        angle=np.zeros(Nk)
    elif len(angle)<Nk:
        NewAngle=np.zeros(Nk)
        NewAngle[0:len(angle)]=angle
        NewAngle[len(angle):]=angle[-1]
        angle=NewAngle
        
    
    
    
    Kx=[]
    Ky=[]
    
    xStart=-1*int(np.floor(Nx/2))
    yStart=-1*int(np.floor(Ny/2))
    
    if not sample_zero:
        if np.mod(Nx,2)==0:
            xStart+=0.5
            yStart+=0.5
    

    
       
    ik=0
    rx=xStart
    ry=yStart
    xdir=1
    
    for iy in range(Ny):
        
        for ix in range(Nx):
            
            xx=rx*np.cos(angle[ik]*np.pi/180)-ry*np.sin(angle[ik]*np.pi/180)
            yy=rx*np.sin(angle[ik]*np.pi/180)+ry*np.cos(angle[ik]*np.pi/180)
            
            Kx.append(xx)
            Ky.append(yy)
            
            ik+=1
            rx+=xdir
            
        xdir*=-1
        rx+=xdir        
        ry+=1

    return(np.array(Kx)*dx,np.array(Ky)*dy)


def upsample_fft(image,UF):
    imx,imy=np.shape(image)
    US_image=np.fft.fft2(image,s=(imx*UF,imy*UF))
    return(US_image)

def resample_fft(imageF,shape,idx,idy):
    
    tracex,tracey=create_kspace(shape[0],shape[1],sample_zero=False)
    tracex-=np.min(tracex)
    tracey-=np.min(tracey)
    
    # pl.plot(tracex,tracey,'o-*')
    # pl.show()
    newimage=np.zeros(shape)+1j*np.zeros(shape)
    
    for kx,ky,ix,iy in zip(idx.astype(int),idy.astype(int),tracex.astype(int),tracey.astype(int)):
        if kx >=0 and kx<imageF.shape[0] and ky>=0 and ky<imageF.shape[1]:
            newimage[ix,iy]=imageF[kx,ky]
    
    return(newimage)


def zero_resample_fft(imageF,shape,idx,idy):
    
    tracex,tracey=create_kspace(shape[0],shape[1],sample_zero=False)
    tracex-=np.min(tracex)
    tracey-=np.min(tracey)
    
    # pl.plot(tracex,tracey,'o-*')
    # pl.show()
    newimage=np.zeros(imageF.shape)+1j*np.zeros(imageF.shape)
    
    for kx,ky,ix,iy in zip(idx.astype(int),idy.astype(int),tracex.astype(int),tracey.astype(int)):
        newimage[kx,ky]=imageF[kx,ky]
    pl.matshow(np.abs(newimage))
    pl.show()
    return(newimage)

def zero_resample_fft2(imageF,shape,idx,idy):
    
    tracex,tracey=create_kspace(shape[0],shape[1],sample_zero=False)
    tracex-=np.min(tracex)
    tracey-=np.min(tracey)
    
    # pl.plot(tracex,tracey,'o-*')
    # pl.show()
    newimage=np.zeros(imageF.shape)+1j*np.zeros(imageF.shape)
    
    for kx,ky,ix,iy in zip(idx.astype(int),idy.astype(int),tracex.astype(int),tracey.astype(int)):
        if kx >=0 and kx<imageF.shape[0] and ky>=0 and ky<imageF.shape[1]:
            newimage[kx,ky]=imageF[kx,ky]
    pl.matshow(np.abs(newimage))
    pl.show()
    return(newimage)


def unravel_kspace(imageF,idx,idy):
    incx=np.sign(np.diff(idx)).astype(int)
    incy=np.sign(np.diff(idy)).astype(int)
    newImg=np.zeros(len(idx),dtype=complex)
    newImg[0]=imageF[0,0]
    x=0
    y=0
    i=0
    for ix,iy in zip(incx,incy):
       i+=1
       x+=ix
       y+=iy
       newImg[i]=imageF[x,y]
    return(newImg)

# def ravel_kspace(image,idx,idy,shape):
#     
#     newImg=np.zeros(shape,dtype=complex)
#    
#     incx=np.sign(np.diff(idx)).astype(int)
#     incy=np.sign(np.diff(idy)).astype(int)
# 
#     newImg[0,0]=image[0]
#     x=0
#     y=0
#     i=0
#     for ix,iy in zip(incx,incy):
#        i+=1
#        x+=ix
#        y+=iy
#        newImg[x,y]=image[i]
#        
#     return(newImg)

def ravel_kspace(image,shape,origin='upper'):

    NewImg=np.zeros(shape,complex)
    Ly=shape[0]
    Lx=shape[1]
    
    xinc=1
    yinc=1
    
    imageCounter=0
    iy=0
    ix=0
        
    for y in range(Ly):
        
        for x in range(Lx):
            NewImg[ix,iy]=image[imageCounter]
            ix+=xinc
            imageCounter+=1
        xinc*=-1
        ix+=xinc
        iy+=yinc
    
    if origin=='lower':
        NewImg=np.rot90(NewImg,k=1)
    
    return(NewImg)

def simulate_kspace_sampling3(US_imageF,HR_size,orig_size,angle):
    # HR_size=np.shape(US_imageF)
    # HR_size=orig_size
    UpFactor=10
    
    HRpadx=(HR_size[0]-orig_size[0])/2.0
    HRpady=(HR_size[1]-orig_size[1])/2.0
    
    origkx,origky=create_kspace(orig_size[0],orig_size[1],angle=angle)
    refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
    
    
    

    
    # pl.plot(refkx,refky,'r-*')
    # pl.plot(origkx,origky,'g-o',markersize=3)
    # pl.show()
    # 
    
    origkx+=np.abs(np.amin(refkx))+HRpadx
    origky+=np.abs(np.amin(refky))+HRpady
    
    origkx=np.round(origkx*UpFactor).astype(int)
    origky=np.round(origky*UpFactor).astype(int)
 
    refkx+=np.abs(np.amin(refkx))+HRpadx
    refky+=np.abs(np.amin(refky))+HRpady
    
    refkx=np.round(refkx*UpFactor).astype(int)
    refky=np.round(refky*UpFactor).astype(int)   
    
    
    
    #=upsample_fft(HR_image,UpFactor)
    
    #pl.matshow(np.abs(US_imageF))    
    # pl.matshow(np.abs(np.fft.ifft2(US_imageF)))
    #pl.show()
    # 
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.plot(refkx,refky,'-o')
    # pl.plot(origkx,origky,'-*')
    # 
    # pl.show()
    #
    newimage=np.zeros(US_imageF.shape)
    
    # for ix,iy in zip(origkx,origky):
    #     newimage[ix,iy]=100+iy*10
    # # 
    # pl.matshow(newimage)
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.show()
    
    
    newfft=resample_fft(US_imageF,orig_size,origkx,origky)
    # pl.matshow(np.abs(newfft))
    # pl.show()
    # 
    
    
    return(newfft,origkx,origky,refkx,refky)


def simulate_kspace_sampling(HR_image,orig_size,angle):
    HR_size=np.shape(HR_image)
    UpFactor=10
    
    HRpadx=(HR_size[0]-orig_size[0])/2.0
    HRpady=(HR_size[1]-orig_size[1])/2.0
    print HRpadx
    origkx,origky=create_kspace(orig_size[0],orig_size[1],angle=angle)
    refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
    
    
    
    # iix=refkx-np.amin(refkx)
    # 
    # iix=np.round((iix/np.amax(iix))*(HR_size[0]-1)*UpFactor)
    # iiy=refky-np.amin(refky)
    # iiy=np.round((iiy/np.amax(iiy))*(HR_size[1]-1)*UpFactor)
    iix=origkx-np.amin(origkx)

    iix=np.round((iix/np.amax(iix))*(HR_size[0]-1)*UpFactor)
    iiy=origky-np.amin(origky)
    iiy=np.round((iiy/np.amax(iiy))*(HR_size[1]-1)*UpFactor)    

    
    origkx+=np.abs(np.amin(refkx))+HRpadx
    origky+=np.abs(np.amin(refky))+HRpady
    
    origkx=np.round(origkx*UpFactor).astype(int)
    origky=np.round(origky*UpFactor).astype(int)
 
    refkx+=np.abs(np.amin(refkx))+HRpadx
    refky+=np.abs(np.amin(refky))+HRpady
    
    refkx=np.round(refkx*UpFactor).astype(int)
    refky=np.round(refky*UpFactor).astype(int)   
    
    
    
    
    US_imageF=upsample_fft(HR_image,UpFactor)
    
    
    pl.matshow(np.log(np.abs(np.fft.fftshift(US_imageF))),origin='lower')
    pl.plot(iix,iiy,'o',markersize=2,color='r')
    pl.title('KspaceResample')
    pl.matshow(np.log(np.abs(np.fft.fftshift(np.fft.fft2(HR_image)))))
    pl.title('OriginalFFT')

    pl.show()
    
    
    #pl.matshow(np.abs(US_imageF))    
    # pl.matshow(np.abs(np.fft.ifft2(US_imageF)))
    #pl.show()
    # 
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.plot(refkx,refky,'-o')
    # pl.plot(origkx,origky,'-*')
    # 
    # pl.show()
    #
    newimage=np.zeros(US_imageF.shape)
    
    # for ix,iy in zip(origkx,origky):
    #     newimage[ix,iy]=100+iy*10
    # # 
    # pl.matshow(newimage)
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.show()
    
    
    newfft=resample_fft(np.fft.fftshift(US_imageF),orig_size,origkx,origky)
    # pl.matshow(np.abs(newfft))
    # pl.show()
    # 
    
    
    return(newfft,origkx,origky,refkx,refky)


def simulate_kspace_sampling2(HR_image,orig_size,angle):
    HR_size=np.shape(HR_image)
    UpFactor=10
    
    HRpadx=(HR_size[0]-orig_size[0])/2.0
    HRpady=(HR_size[1]-orig_size[1])/2.0
    
    origkx,origky=create_kspace(orig_size[0],orig_size[1],angle=angle)
    refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
    
    
    

    
    # pl.plot(refkx,refky,'r-*')
    # pl.plot(origkx,origky,'g-o',markersize=3)
    # pl.show()
    # 
    
    origkx+=np.abs(np.amin(refkx))+HRpadx
    origky+=np.abs(np.amin(refky))+HRpady
    
    origkx=np.round(origkx*UpFactor).astype(int)
    origky=np.round(origky*UpFactor).astype(int)
 
    refkx+=np.abs(np.amin(refkx))+HRpadx
    refky+=np.abs(np.amin(refky))+HRpady
    
    refkx=np.round(refkx*UpFactor).astype(int)
    refky=np.round(refky*UpFactor).astype(int)
    
    
    
    US_imageF=upsample_fft(HR_image,UpFactor)
    
    # pl.matshow(np.abs(US_imageF))    
    # pl.matshow(np.abs(np.fft.ifft2(US_imageF)))
    # pl.show()
    # 
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.plot(refkx,refky,'-o')
    # pl.plot(origkx,origky,'-*')
    # 
    # pl.show()
    #
    newimage=np.zeros(US_imageF.shape)
    
    # for ix,iy in zip(origkx,origky):
    #     newimage[ix,iy]=100+iy*10
    # # 
    # pl.matshow(newimage)
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.show()
    
    
    newfft=zero_resample_fft(np.fft.fftshift(US_imageF),orig_size,origkx,origky)
    # pl.matshow(np.abs(newfft))
    # pl.show()
    # 
    
    
    return(newfft,origkx,origky,refkx,refky)


def simulate_kspace_sampling4(HR_image,orig_size,angle):
    HR_size=np.shape(HR_image)
    UpFactor=10
    
    HRpadx=(HR_size[0]-orig_size[0])/2.0
    HRpady=(HR_size[1]-orig_size[1])/2.0
    
    origkx,origky=create_kspace(orig_size[0],orig_size[1],angle=angle)
    refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
    
    
    

    
    # pl.plot(refkx,refky,'r-*')
    # pl.plot(origkx,origky,'g-o',markersize=3)
    # pl.show()
    # 
    
    origkx+=np.abs(np.amin(refkx))+HRpadx
    origky+=np.abs(np.amin(refky))+HRpady
    
    origkx=np.round(origkx*UpFactor).astype(int)
    origky=np.round(origky*UpFactor).astype(int)
 
    refkx+=np.abs(np.amin(refkx))+HRpadx
    refky+=np.abs(np.amin(refky))+HRpady
    
    refkx=np.round(refkx*UpFactor).astype(int)
    refky=np.round(refky*UpFactor).astype(int)
    
    
    
    US_imageF=upsample_fft(HR_image,UpFactor)
    
    # pl.matshow(np.abs(US_imageF))    
    # pl.matshow(np.abs(np.fft.ifft2(US_imageF)))
    # pl.show()
    # 
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.plot(refkx,refky,'-o')
    # pl.plot(origkx,origky,'-*')
    # 
    # pl.show()
    #
    newimage=np.zeros(US_imageF.shape)
    
    # for ix,iy in zip(origkx,origky):
    #     newimage[ix,iy]=100+iy*10
    # # 
    # pl.matshow(newimage)
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.show()
    
    
    newfft=zero_resample_fft2(np.fft.fftshift(US_imageF),orig_size,origkx,origky)
    # pl.matshow(np.abs(newfft))
    # pl.show()
    # 
    
    
    return(newfft,origkx,origky,refkx,refky)

def simulate_kspace_sampling5(HR_image,orig_size,angle):
    HR_size=np.shape(HR_image)
    UpFactor=10
    
    HRpadx=(HR_size[0]-orig_size[0])/2.0
    HRpady=(HR_size[1]-orig_size[1])/2.0
    
    origkx,origky=create_kspace(orig_size[0],orig_size[1],angle=angle)
    refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
    
    
    

    
    # pl.plot(refkx,refky,'r-*')
    # pl.plot(origkx,origky,'g-o',markersize=3)
    # pl.show()
    # 
    
    origkx+=np.abs(np.amin(refkx))+HRpadx
    origky+=np.abs(np.amin(refky))+HRpady
    
    origkx=np.round(origkx*UpFactor).astype(int)
    origky=np.round(origky*UpFactor).astype(int)
 
    refkx+=np.abs(np.amin(refkx))+HRpadx
    refky+=np.abs(np.amin(refky))+HRpady
    
    refkx=np.round(refkx*UpFactor).astype(int)
    refky=np.round(refky*UpFactor).astype(int)
    
    
    
    US_imageF=upsample_fft(HR_image,UpFactor)
    
    # pl.matshow(np.abs(US_imageF))    
    # pl.matshow(np.abs(np.fft.ifft2(US_imageF)))
    # pl.show()
    # 
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.plot(refkx,refky,'-o')
    # pl.plot(origkx,origky,'-*')
    # 
    # pl.show()
    #
    newimage=np.zeros(US_imageF.shape)
    
    # for ix,iy in zip(origkx,origky):
    #     newimage[ix,iy]=100+iy*10
    # # 
    # pl.matshow(newimage)
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.show()
    
    
    newfft=zero_resample_fft2(np.fft.fftshift(US_imageF),orig_size,origkx,origky)
    # pl.matshow(np.abs(newfft))
    # pl.show()
    # 
    
    
    return(newfft,origkx,origky,refkx,refky)



def New_simulate_kspace_sampling(HR_image,orig_size,angle):
    HR_size=np.shape(HR_image)
    UpFactor=10
    
    HRpadx=(HR_size[0]-orig_size[0])/2.0
    HRpady=(HR_size[1]-orig_size[1])/2.0
    print HRpadx
    origkx,origky=create_kspace(orig_size[0],orig_size[1],angle=angle)
    refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
    
    
    
    # iix=refkx-np.amin(refkx)
    # 
    # iix=np.round((iix/np.amax(iix))*(HR_size[0]-1)*UpFactor)
    # iiy=refky-np.amin(refky)
    # iiy=np.round((iiy/np.amax(iiy))*(HR_size[1]-1)*UpFactor)
    iix=origkx-np.amin(origkx)

    iix=np.round((iix/np.amax(iix))*(HR_size[0]-1)*UpFactor)
    iiy=origky-np.amin(origky)
    iiy=np.round((iiy/np.amax(iiy))*(HR_size[1]-1)*UpFactor)    

    
    origkx+=np.abs(np.amin(refkx))+HRpadx
    origky+=np.abs(np.amin(refky))+HRpady
    
    origkx=np.round(origkx*UpFactor).astype(int)
    origky=np.round(origky*UpFactor).astype(int)
 
    refkx+=np.abs(np.amin(refkx))+HRpadx
    refky+=np.abs(np.amin(refky))+HRpady
    
    refkx=np.round(refkx*UpFactor).astype(int)
    refky=np.round(refky*UpFactor).astype(int)   
    
    
    
    
    US_imageF=upsample_fft(HR_image,UpFactor)
    
    
    pl.matshow(np.log(np.abs(np.fft.fftshift(US_imageF))),origin='lower')
    pl.plot(iix,iiy,'o',markersize=2,color='r')
    pl.title('KspaceResample')
    pl.matshow(np.log(np.abs(np.fft.fftshift(np.fft.fft2(HR_image)))))
    pl.title('OriginalFFT')

    pl.show()
    
    
    #pl.matshow(np.abs(US_imageF))    
    # pl.matshow(np.abs(np.fft.ifft2(US_imageF)))
    #pl.show()
    # 
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.plot(refkx,refky,'-o')
    # pl.plot(origkx,origky,'-*')
    # 
    # pl.show()
    #
    newimage=np.zeros(US_imageF.shape)
    
    # for ix,iy in zip(origkx,origky):
    #     newimage[ix,iy]=100+iy*10
    # # 
    # pl.matshow(newimage)
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.show()
    
    
    newfft=resample_fft(np.fft.fftshift(US_imageF),orig_size,origkx,origky)
    # pl.matshow(np.abs(newfft))
    # pl.show()
    # 
    
    
    return(newfft,origkx,origky,refkx,refky)


def k_2_magphase(kspace):
    mag=np.abs(kspace)
    angle=np.angle(kspace)
    return(mag,angle)

def magphase_2_k(mag,phase):
    k=mag*np.cos(phase)+1j*mag*np.cos(phase)
    return(k)


def interpolate_Kspace(imgfft,sampkx,sampky,refkx,refky,orig_size,method='cubic'):
    points=np.zeros((len(sampkx),2))
    points[:,0]=sampkx
    points[:,1]=sampky

    values=unravel_kspace(imgfft,refkx,refky)
    kxGrid,kyGrid=np.meshgrid(refkx[0:orig_size[0]],refky[0::orig_size[0]])
    # pl.matshow(kxGrid)
    # pl.matshow(np.abs(imgfft))
    # pl.matshow(np.abs(np.fft.fftshift(np.fft.fft2(imgfft))))
    # 
    # #pl.plot(refkx[0:orig_size[0]],refky[0::orig_size[0]])
    # pl.show()
    # print kxGrid.shape
    
    # mag,phase=k_2_magphase(values)
    # 
    # ReGridMag=interpolate_image((sampkx,sampky),mag,kxGrid,kyGrid,method)    
    # ReGridPhase=interpolate_image((sampkx,sampky),phase,kxGrid,kyGrid,method)
    #     
    # ReGrid=magphase_2_k(ReGridMag,ReGridPhase)
    # #ReGrid=interpolate_image((sampkx,sampky),values,kxGrid,kyGrid,method)
    # #ReGrid=ravel_kspace(ReGridReal+1j*ReGridImag,refkx,refky,orig_size)
    
    ReGridReal=interpolate_image((sampkx,sampky),np.real(values),kxGrid,kyGrid,method)
    ReGridimag=interpolate_image((sampkx,sampky),np.imag(values),kxGrid,kyGrid,method)
    # print ReGridReal.shape
    # print ReGridimag.shape
    
    #ReGrid=ravel_kspace(ReGridReal+1j*ReGridimag,refkx,refky,orig_size)
    ReGrid=ReGridReal+1j*ReGridimag
    print np.amax(np.abs(ReGrid))
    
    return(ReGrid)

def interpolate_image(points,values,xGrid,yGrid,method='cubic'):
    interpolated=scp.interpolate.griddata(points,values,(xGrid,yGrid),method=method,fill_value=0)
    return(interpolated)
    



def copyKspaceQuadrent(image,q):
    # ____________
    # |    |      |
    # | q1 |  q3  | 
    # |____|______|
    # | q2 |  q4  |
    # |____|______\
    # 
    #pl.matshow(image)
    nx,ny=np.shape(image)
    xmid=np.round(nx/2)
    ymid=np.round(ny/2)
    
    if q==1:
       quadcopy=image[0:xmid+1,0:ymid+1]
       newimage=np.zeros(image.shape)
       #newimage=np.copy(image)
       newimage[0:xmid,0:ymid]=quadcopy
       newimage[xmid:,0:ymid]=np.flipud(quadcopy)
       newimage[xmid:,ymid:]=np.fliplr(np.flipud(quadcopy))
       newimage[0:xmid,ymid:]=np.fliplr(quadcopy)
    
    # pl.matshow(newimage)
    # 
    # pl.show()

    return(newimage)




def twoDfftTest():
    
    ln=256
    image=np.zeros((ln,ln))
    
    image[20:60,5:10]=1
    image[100:115,180:230]=1
    image[160:165,60:80]=1
    image[155:160,80:100]=1
    image[160:165,100:120]=1
    
    F=np.fft.fftshift(np.fft.fft2(image))
    xline=F[:,128]
    yline=F[128,:]
    pl.matshow(np.log(np.abs(F)))
    
    f,ax=pl.subplots(3,2)
    a=ax[0,0]
    a.plot(np.real(xline))
    a.set_title('x real')
    a=ax[1,0]
    a.plot(np.imag(xline))
    a.set_title('x imag')
    a=ax[2,0]
    a.plot(np.abs(xline))
    
    a=ax[0,1]
    a.plot(np.real(yline))
    a.set_title('yreal')
    a=ax[1,1]
    a.plot(np.imag(yline))
    a.set_title('yimag')
    a=ax[2,1]
    a.plot(np.abs(yline))
    pl.show()
    
    
    lx,ly=np.shape(image)
    
    mx=np.mod(lx,2)
    my=np.mod(ly,2)
        
    lx=np.floor(lx/2.0).astype(int)
    ly=np.floor(ly/2.0).astype(int)+1
    
    halfsig=F[:,:ly]
    
    
    #realhalf=np.    
    realhalf=np.real(halfsig)
    imaghalf=np.imag(halfsig)
    
    
    print realhalf.shape
    print np.shape(np.fliplr(np.flipud(realhalf[:,1-my:-1])))
    print np.shape(realhalf[:,1-my:-1])
    
    
    realfullsig=np.hstack((realhalf,np.roll(np.fliplr(np.flipud(realhalf[:,1-my:-1])),1-mx,0)))
    imagfullsig=np.hstack((imaghalf,np.roll(np.fliplr(np.flipud(-1*imaghalf[:,1-my:-1])),1-mx,0)))
    fullsig=realfullsig+1j*imagfullsig    
    pl.matshow(np.log(np.abs(fullsig)))
    pl.title('Reconstcuct')
    pl.matshow(np.log(np.abs(F)))
    pl.title('original')    
    
    pl.matshow(image)
    reconstruct=np.fft.ifft2(np.fft.ifftshift(fullsig))
    pl.matshow(np.abs(reconstruct))
    pl.title('reconstruct mag')
    pl.matshow(image-np.abs(reconstruct))
    pl.title('image difference')
    pl.matshow(np.log(np.abs(realfullsig-np.real(F))))
    pl.title('realdiff')
    pl.matshow(np.log(np.abs(imagfullsig-np.imag(F))))
    pl.title('imagdiff')
    pl.show()
    
    
def QuadCopy2D(F):

    lx,ly=np.shape(F)
    
    mx=np.mod(lx,2)
    my=np.mod(ly,2)
        
    lx=np.floor(lx/2.0).astype(int)
    ly=np.floor(ly/2.0).astype(int)+1
    
    halfsig=F[:,:ly]
    
    
   
    realhalf=np.real(halfsig)
    imaghalf=np.imag(halfsig)
    
    
    print realhalf.shape
    print np.shape(np.fliplr(np.flipud(realhalf[:,1-my:-1])))
    print np.shape(realhalf[:,1-my:-1])
    
    
    realfullsig=np.hstack((realhalf,np.roll(np.fliplr(np.flipud(realhalf[:,1-my:-1])),1-mx,0)))
    imagfullsig=np.hstack((imaghalf,np.roll(np.fliplr(np.flipud(-1*imaghalf[:,1-my:-1])),1-mx,0)))
    fullsig=realfullsig+1j*imagfullsig    
    pl.matshow(np.log(np.abs(fullsig)))
    pl.title('Reconstcuct')
    pl.matshow(np.log(np.abs(F)))
    pl.title('original')    
    
    pl.matshow(image)
    reconstruct=np.fft.ifft2(np.fft.ifftshift(fullsig))
    pl.matshow(np.abs(reconstruct))
    pl.title('reconstruct mag')
    pl.matshow(image-np.abs(reconstruct))
    pl.title('image difference')
    pl.matshow(np.log(np.abs(realfullsig-np.real(F))))
    pl.title('realdiff')
    pl.matshow(np.log(np.abs(imagfullsig-np.imag(F))))
    pl.title('imagdiff')
    pl.show()
    return fullsig

def oneDfftTest():
    ln=256
    t=np.arange(ln)*0.01
    signal=np.random.rand(ln)+np.cos(t*4*180/np.pi)
    
    sf=np.fft.fftshift(np.fft.fft(signal))
    
    f,ax=pl.subplots(6,2)
    a=ax[0,0]
    a.plot(signal)
    a=ax[1,0]
    a.plot(np.real(sf))
    a=ax[2,0]
    a.plot(np.imag(sf))
    
    
    m=np.mod(ln,2)
    
    l=np.floor(len(signal)/2.0).astype(int)+1
    halfsig=sf[:l]
    
    realhalf=np.real(halfsig)
    imaghalf=np.imag(halfsig)
    realfullsig=np.hstack((realhalf,np.flipud(realhalf[1-m:-1])))
    imagfullsig=np.hstack((imaghalf,np.flipud(-1*imaghalf[1-m:-1])))
    
    fullsig=realfullsig+1j*imagfullsig
    
    
    a=ax[3,0]
    a.plot(np.real(fullsig))
    a=ax[4,0]
    a.plot(np.imag(fullsig))
    a=ax[5,0]
    reconstruct=np.fft.ifft(np.fft.ifftshift(fullsig))
    a.plot(np.real(reconstruct))
    
    a=ax[0,1]
    a.plot(signal-np.real(reconstruct))
    a=ax[1,1]
    a.plot(np.real(sf)-np.real(fullsig))
    a=ax[2,1]
    a.plot(np.imag(sf)-np.imag(fullsig))
    
    
    a=ax[3,1]
    a.plot(np.real(sf))
    a.plot(np.real(fullsig),'-o')
    a=ax[4,1]
    a.plot(np.imag(sf))
    a.plot(np.imag(fullsig),'-o')
    
    pl.show()
    

def norm(data):
    data=data-np.min(data)
    data=data/np.amax(np.abs(data))
    return(data)


def error(img1,img2):
    #error=np.log(np.abs(norm(img1)-norm(img2)))
    error=np.abs(norm(img1)-norm(img2))
    return(error)

#     
# ZpadFft=np.zeros((224,224),dtype=complex)
# 
# ZPFdata=np.fft.ifft2(np.fft.ifftshift((ZpadFft)))
# NewDataFft=np.fft.fftshift(np.fft.fft2(ZPFdata,s=(2240,2240)))
#     



def comp_sens(imgf):
    gtv=0
    refkx,refky=create_kspace(128,128,angle=[0])
    imgf=ravel_kspace(imgf,refkx,refky,((128,128)))
    print imgf.shape
    for r in range(1,imgf.shape[0]):
        for c in range(1,imgf.shape[1]):
            gtv+=np.sqrt(np.square(np.abs(imgf[r,c]-imgf[r-1,c]))+np.square(np.abs(imgf[r,c]-imgf[r,c-1])))
    
    return(gtv)



def test_minimize():
    img=phantom(128).T
    orig_size=(128,128)
    imageF=np.fft.fftshift(np.fft.fft2(img))
    
    xr=(np.random.rand(8192)*127).astype(int)
    yr=(np.random.rand(8192)*127).astype(int)
    #data=imageF[xr,yr]
    refkx,refky=create_kspace(128,128,angle=[0])
    sparse_data=np.zeros(orig_size,dtype=complex)
    sparse_data[xr,yr]=imageF[xr,yr]
    # pl.plot(sparse_data[:,64],'-o')
    # pl.plot(imageF[:,64],'-*')
    # pl.show()
    # pl.matshow(np.abs(sparse_data))
    # pl.matshow(np.abs(imageF))
    # pl.show()
    
    urSparse=unravel_kspace(sparse_data,refkx,refky)
    res=minimize(comp_sens,urSparse,method='nelder-mead',options={'xtol':1e-8,'disp':True})
    NewImg=res.x
    pl.matshow(np.abs(np.fft.ifft2(np.fft.fftshift(NewImg))))
    pl.show()
    
    pass


def test_interp():
    
    true128=phantom(128).T
    phSize=256
    orig_size=(128,128)
    image=phantom(matrix_size=phSize)
    
    test=zero_pad_image(true128,256)
    
    imageF=np.zeros((phSize,phSize))
    imageF[100:156,120:136]=1
    imageF[126:130,100:156]=1
    
    image=np.fft.ifftshift(np.fft.ifft2(np.fft.fftshift(imageF))).T
    # pl.matshow(np.abs(imageF))
    # pl.matshow(np.abs(image))
    # pl.show()
    #
    

    
    # For No Resampling:
    newfft,origkx,origky,refkx,refky=simulate_kspace_sampling(image,orig_size,[20])
    newimg0=np.fft.ifft2(newfft)
    
    
    smallfft,sorigkx,sorigky,srefkx,srefky=simulate_kspace_sampling(image,orig_size,[0])
    junk1,sorigkx,sorigky,srefkx,srefky=simulate_kspace_sampling(image,(20,20),[20])
    trefx=(srefkx.astype(float)-(srefkx[0]))
    trefx=trefx/np.amax(trefx)*128
    trefy=(srefky.astype(float)-(srefky[0]))
    trefy=trefy/np.amax(trefy)*128
    
    
    tracex=(sorigkx.astype(float)-(sorigkx[0]))
    tracex=tracex/np.amax(tracex)*128
    tracey=(sorigky.astype(float)-(sorigky[0]))
    tracey=tracey/np.amax(tracey)*128
    # pl.plot(tracex,tracey,'-*')
    # pl.show()
    
    img=np.zeros(orig_size)
    for i in range(0,orig_size[0],10):
        img[i,:]=1
    

    #tracex=tracex/np.amax(tracex)
    # for ix,iy in zip(tracex,tracey):
    #     print '{} , {}'.format(ix,iy)
    #     img[int(ix),int(iy)]=ix+1000*iy
    
    for i in range(0,orig_size[0],10):
        img[i,:]=1
        
    xr=(np.random.rand(1000)*127).astype(int)
    yr=(np.random.rand(1000)*127).astype(int)
    data=img[xr,yr]
    
    urimg=np.abs(unravel_kspace(img,refkx,refky))
    #gridx,gridy=np.meshgrid(tracex[0:orig_size[0]],tracey[0::orig_size[0]])
    gridx,gridy=np.meshgrid(refkx[0:orig_size[0]],refky[0::orig_size[0]])
    print gridx.shape
    print origkx.shape
    urfft=np.abs(unravel_kspace(newfft,refkx,refky))
    grid_z0 = scp.interpolate.griddata((origkx,origky), urfft, (gridx,gridy), method='nearest',fill_value=0)
    grid_z1 = scp.interpolate.griddata((origkx,origky), urfft, (gridx,gridy), method='linear',fill_value=0)
    grid_z2 = scp.interpolate.griddata((origkx,origky), urfft, (gridx,gridy), method='cubic',fill_value=0)

    f,ax=pl.subplots(1,1,figsize=(8,6))
    ax.imshow(np.abs(smallfft),origin='lower')
    ax.plot(trefy,trefx,'r--o')
    
    f,ax=pl.subplots(1,1,figsize=(8,6))
    ax.imshow(np.abs(smallfft),origin='lower')
    ax.plot(tracey,tracex,'r--o')
    
    f,ax=pl.subplots(1,1,figsize=(8,6))
    ax.imshow(np.abs(newfft),origin='lower')

    
    f,ax=pl.subplots(1,1,figsize=(8,6))
    ax.imshow(grid_z2.T, origin='lower')

    
    
    pl.show()
    
    
    gsCmap=sb.light_palette("black",n_colors=256,as_cmap=True,reverse=True)
    pl.subplot(221)
    pl.imshow(np.abs(newfft),origin='lower')
    #pl.plot([20,20],[0,128])
    pl.plot(tracey,tracex ,'k.', ms=1)
    pl.title('Original')
    pl.subplot(222)
    pl.imshow(grid_z0.T, origin='lower')
    pl.title('Nearest')
    pl.subplot(223)
    pl.imshow(grid_z1.T, origin='lower')
    pl.title('Linear')
    pl.subplot(224)
    pl.imshow(grid_z2.T, origin='lower')
    pl.title('Cubic')
    pl.gcf().set_size_inches(6, 6)
    pl.show()
    
    pl.figure()
    urfft=(unravel_kspace(newfft,refkx,refky))
    grid_z0=np.abs(interpolate_Kspace(newfft,origkx,origky,refkx,refky,orig_size,method='nearest'))
    #grid_z1=np.abs(interpolate_Kspace(newfft,origkx,origky,refkx,refky,orig_size,method='linear'))
    grid_z2=np.abs(interpolate_Kspace(newfft,origkx,origky,refkx,refky,orig_size,method='cubic'))
    grid_z1=np.abs(interpolate_image((origkx,origky),urfft,gridx,gridy,method='linear'))
    
    # pl.subplot(221)
    # pl.imshow(np.abs(newfft),origin='lower')
    # pl.plot([20,20],[0,128])
    # pl.plot(tracey,tracex ,'k.', ms=1)
    # pl.title('Original')
    # pl.subplot(222)
    # pl.imshow(grid_z0.T, origin='lower')
    # pl.title('Nearest')
    # pl.subplot(223)
    # pl.imshow(grid_z1.T, origin='lower')
    # pl.title('Linear')
    # pl.subplot(224)
    # pl.imshow(grid_z2.T, origin='lower')
    # pl.title('Cubic')
    # pl.gcf().set_size_inches(6, 6)    
    # pl.show()





def New_Possum_Ksamp():
    
    gsCmap=sb.light_palette("black",n_colors=256,as_cmap=True,reverse=True)
    
    OS=112
    HRfactor=1.5
    UpFactor=10
    
    
    
    orig_size=(OS,OS)
    phSize=(OS*HRfactor,OS*HRfactor)
    image=phantom(np.round(OS*HRfactor).astype(int))
    true128=phantom(OS)

    
    baseDir='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord'
    Myk=np.loadtxt('/home/dparker/Desktop/kMot.txt')
    Posk=np.loadtxt(os.path.join(baseDir,'Kcoord_Mot_ascii'))


    #  For mag and phase
    # MagNii='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord/image_abs.nii.gz'
    # PhaseNii='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord/image_phase.nii.gz'
    # 
    # mag=nb.load(MagNii).get_data()
    # phase=nb.load(PhaseNii).get_data()
    
    # InKspace=False
    # RealImag=False
    
    
    # For real and imag kspace:
    RealNii='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord/s2i_Kvals_real.nii.gz'
    ImagNii='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord/s2i_Kvals_imag.nii.gz'
    
    InKspace=True
    RealImag=True
    
    mag=nb.load(RealNii).get_data()
    phase=nb.load(ImagNii).get_data()
    
    
    inds=np.where(np.abs(np.diff(Posk[1]))>300)
    print inds[0]
    gap=OS*OS
    
    refKx=Posk[0,inds[0][0]+1:inds[0][0]+OS*OS+1]
    refKy=Posk[1,inds[0][0]+1:inds[0][0]+OS*OS+1]
                           #refKx,refKy,orig_size,map_size,UpFactor
    xm,xi,ym,yi=rs.mapk2ind(refKx,refKy,orig_size,phSize,UpFactor)
    
    HrImgFft=np.fft.fftshift(np.fft.fft2(image))
    ZpHrImgFft=rs.upsample_fft(image,UpFactor)
    ZpHrImgFft=np.fft.fftshift(ZpHrImgFft)

    minKx=np.amin(refKx)
    minKy=np.amin(refKy)
    
    ikx=refKx-minKx
    iky=refKy-minKy
    
    maxKx=np.amax(ikx)
    maxKy=np.amax(iky)
    
    ikx=ikx/maxKx
    iky=iky/maxKy
    
    ikx=np.round(ikx*OS).astype(int)
    iky=np.round(iky*OS).astype(int)
    
    dt=4.19379e-05
    dtx=1e-05
    T2s=50e-3
    
    xdim=2
    ydim=2
    
    xax=np.arange(OS)-OS/2.0
    yax=np.arange(OS)-OS/2.0
    
    xax=xax/OS*2*np.pi+np.pi
    yax=yax/OS*2*np.pi+np.pi
    # xax*=xdim
    # yax*=ydim
    
    X,Y=np.meshgrid(xax,yax)
    
    xmm=rs.unravel_kspace(X)
    ymm=rs.unravel_kspace(Y)
    
    pl.matshow(X)
    pl.matshow(Y)
    pl.figure()
    
    pl.plot(xmm,ymm)
    pl.show()
    
    
    scalex=((np.amax(refKx)-np.amin(refKx)))/2
    #Kx=Kx/scalex#*(np.pi/dx)
    # 
    scaley=((np.amax(refKy)-np.amin(refKy)))/2
    #Ky=Ky/scaley#*(np.pi/dy)
    
    for i,ii in enumerate(inds[0]):
        if i>=4 and i<=6:
            
            #######################
            # This runs on the kspace of 
            
            m=mag[:,:,0,i]
            p=phase[:,:,0,i]
            # m=np.rot90(m,k=1,axes=(1,0))
            # p=np.rot90(p,k=1,axes=(1,0))
            
            if not RealImag:
                cpx=m*np.cos(p)+1j*m*np.sin(p)
            else:
                cpx=m+1j*p
            
            if not InKspace:
                Fcpx=np.fft.fftshift(np.fft.fft2(cpx))
            else:
                Fcpx=cpx
            
            
            SliceKx=Posk[0,i*gap:ii+1]
            SliceKy=Posk[1,i*gap:ii+1]
            
            pl.matshow(np.log(np.abs(HrImgFft)),origin='lower')
            pl.title('HR FFt')
            pl.matshow(np.log(np.abs(ZpHrImgFft)),origin='lower')
            
            
            k2ix=np.array([xi+xm*kx for kx in SliceKx])
            k2iy=np.array([yi+ym*ky for ky in SliceKy])
            
            pl.plot(k2ix,k2iy,'-*')

            #testimgFft=[ZpHrImgFft[x,y]/HRfactor for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int))]
            
            
            testimgFft=rs.unravel_kspace(Fcpx)
            
            NewImage=np.zeros(ZpHrImgFft.shape)
            
            for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int)):                
                NewImage[x,y]=1
                
            Xmap=rs.ravel_kspace(SliceKx,true128.shape)
            Ymap=rs.ravel_kspace(SliceKy,true128.shape)
            
            
            X1=np.diff(Xmap,axis=0)
            Y1=np.diff(Xmap,axis=1)
            
            X2=np.diff(Ymap,axis=0)
            Y2=np.diff(Ymap,axis=1)            
            
            m1=np.amax(np.sqrt(np.square(X1[:,1:])+np.square(Y1[1:,:])))
            m2=np.amax(np.sqrt(np.square(X2[:,1:])+np.square(Y2[1:,:])))
            
            mx=np.amax((m1,m2))
            npx=mx*true128.shape[0]/(np.amax(SliceKx)-np.amin(SliceKx))
            
            
            output=ndi.filters.gaussian_filter(NewImage,sigma=npx*(UpFactor),mode='constant',cval=0)
            output=output*(UpFactor*UpFactor)
            output=np.nan_to_num(NewImage/output)
            #output[np.where(output==np.nan)]=0
            pl.matshow(output)
            pl.title('output')
            # pl.matshow(np.abs(np.fft.fftshift(np.fft.fft2(output+np.zeros(output.shape)))))
    
            
            weights=[]
            for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int)):
               weights.append(output[x,y])
        
            weightedImgFft=np.array(testimgFft)*np.array(weights)

            MyKx=SliceKx/scalex*OS/(np.pi*4)
            MyKy=SliceKy/scaley*OS/(np.pi*4)
            print np.amax(MyKx)
            print np.amin(MyKx)
            
            ############################################
            ####### This takes the unraveled matricies
            ############################################
            
            #custFft=rs.MyIfft(SliceKx/scalex*OS/(np.pi*4),SliceKy/scaley*OS/(np.pi*4),xmm,ymm,weightedImgFft)
            # custFft=rs.MyIfft(MyKx,MyKy,xmm,ymm,testimgFft)
            # custFft=ravel_kspace(custFft,orig_size)
            # 
            
            ############################################
            ####### This takes the 2D NxM matricies
            ############################################
            Xmap=rs.ravel_kspace(SliceKx,true128.shape)
            Ymap=rs.ravel_kspace(SliceKy,true128.shape)
            
            
            pl.matshow(np.log(np.abs(rs.ravel_kspace(testimgFft,true128.shape))))
            pl.title('Resampled')
            custFft=rs.MyIfft2(MyKx,MyKy,X,Y,testimgFft)
            #custFft=ravel_kspace(custFft,orig_size)            
            
            
            
            pl.matshow(np.abs(custFft))
            #custFft[56,56]=1
            
            pl.matshow(np.abs(np.fft.fftshift(custFft)))
            
            imgFft=rs.ravel_kspace(testimgFft,orig_size)
            img=np.fft.fft2(imgFft)
            pl.matshow(np.abs(img))
            
            pl.show()
            # testimgFft=rs.ravel_kspace(testimgFft,orig_size)
            # 
           # NewImage=np.zeros(ZpHrImgFft.shape,complex)    
            # 
            # for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int)):
            #     
            #     NewImage[x,y]=1
            #     #NewImage[rx,ry]=2
            # NewImage=NewImage*ZpHrImgFft
            # pl.matshow(np.abs(np.fft.ifft2(NewImage)))
            # pl.show()
            
            # 

            # 
            # weights=rs.ravel_kspace(weights,true128.shape)
            # 
            # 
            # 
            # testimgFft=testimgFft*weights            
            # 
            # # pl.matshow(np.log(np.abs(testimgFft)),origin='lower')
            # # pl.matshow(np.log(np.abs(HrImgFft)),origin='lower')
            # # pl.show()
            # testimg=np.abs(np.fft.ifft2(testimgFft))
            # pl.matshow(testimg)
            # pl.matshow(true128)
            # pl.matshow(true128-testimg)
            # 
            # pl.show()
            # 
            
            
            
def New_Phantom_Ksamp():
    
    gsCmap=sb.light_palette("black",n_colors=256,as_cmap=True,reverse=True)
    
    OS=112
    HRfactor=1.5
    UpFactor=10
    
    
    
    orig_size=(OS,OS)
    phSize=(OS*HRfactor,OS*HRfactor)
    image=phantom(np.round(OS*HRfactor).astype(int))
    true128=phantom(OS)

    
    baseDir='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord'
    Myk=np.loadtxt('/home/dparker/Desktop/kMot.txt')
    Posk=np.loadtxt(os.path.join(baseDir,'Kcoord_Mot_ascii'))

    

    inds=np.where(np.abs(np.diff(Posk[1]))>300)
    print inds[0]
    gap=OS*OS
    
    refKx=Posk[0,inds[0][0]+1:inds[0][0]+OS*OS+1]
    refKy=Posk[1,inds[0][0]+1:inds[0][0]+OS*OS+1]
                           #refKx,refKy,orig_size,map_size,UpFactor
    xm,xi,ym,yi=rs.mapk2ind(refKx,refKy,orig_size,phSize,UpFactor)
    
    HrImgFft=np.fft.fftshift(np.fft.fft2(image))
    ZpHrImgFft=rs.upsample_fft(image,UpFactor)
    ZpHrImgFft=np.fft.fftshift(ZpHrImgFft)

    minKx=np.amin(refKx)
    minKy=np.amin(refKy)
    
    ikx=refKx-minKx
    iky=refKy-minKy
    
    maxKx=np.amax(ikx)
    maxKy=np.amax(iky)
    
    ikx=ikx/maxKx
    iky=iky/maxKy
    
    ikx=np.round(ikx*OS).astype(int)
    iky=np.round(iky*OS).astype(int)
    
    dt=4.19379e-05
    dtx=1e-05
    T2s=50e-3
    
    xdim=2
    ydim=2
    
    xax=np.arange(OS)-OS/2.0
    yax=np.arange(OS)-OS/2.0
    
    xax=xax/OS*2*np.pi+np.pi
    yax=yax/OS*2*np.pi+np.pi
    # xax*=xdim
    # yax*=ydim
    
    X,Y=np.meshgrid(xax,yax)
    
    xmm=rs.unravel_kspace(X)
    ymm=rs.unravel_kspace(Y)
    
    pl.matshow(X)
    pl.matshow(Y)
    pl.figure()
    
    pl.plot(xmm,ymm)
    pl.show()
    
    
    scalex=((np.amax(refKx)-np.amin(refKx)))/2
    #Kx=Kx/scalex#*(np.pi/dx)
    # 
    scaley=((np.amax(refKy)-np.amin(refKy)))/2
    #Ky=Ky/scaley#*(np.pi/dy)
    
    for i,ii in enumerate(inds[0]):
        if i>=4 and i<=6:
            
            #######################
            # This runs on the kspace of 
            
            # m=mag[:,:,0,i]
            # p=phase[:,:,0,i]
            # # m=np.rot90(m,k=1,axes=(1,0))
            # # p=np.rot90(p,k=1,axes=(1,0))
            # 
            # cpx=m*np.cos(p)+1j*m*np.sin(p)
            # Fcpx=np.fft.fftshift(np.fft.fft2(cpx))
            # 
            # 
            SliceKx=Posk[0,i*gap:ii+1]
            SliceKy=Posk[1,i*gap:ii+1]
            
            pl.matshow(np.log(np.abs(HrImgFft)),origin='lower')
            pl.title('HR FFt')
            pl.matshow(np.log(np.abs(ZpHrImgFft)),origin='lower')
            
            
            k2ix=np.array([xi+xm*kx for kx in SliceKx])
            k2iy=np.array([yi+ym*ky for ky in SliceKy])
            
            pl.plot(k2ix,k2iy,'-*')

            testimgFft=[ZpHrImgFft[x,y]/HRfactor for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int))]
            
            
            #testimgFft=rs.unravel_kspace(Fcpx)
            
            NewImage=np.zeros(ZpHrImgFft.shape)
            
            for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int)):                
                NewImage[x,y]=1
                
            Xmap=rs.ravel_kspace(SliceKx,true128.shape)
            Ymap=rs.ravel_kspace(SliceKy,true128.shape)
            
            
            X1=np.diff(Xmap,axis=0)
            Y1=np.diff(Xmap,axis=1)
            
            X2=np.diff(Ymap,axis=0)
            Y2=np.diff(Ymap,axis=1)            
            
            m1=np.amax(np.sqrt(np.square(X1[:,1:])+np.square(Y1[1:,:])))
            m2=np.amax(np.sqrt(np.square(X2[:,1:])+np.square(Y2[1:,:])))
            
            mx=np.amax((m1,m2))
            npx=mx*true128.shape[0]/(np.amax(SliceKx)-np.amin(SliceKx))
            
            
            output=ndi.filters.gaussian_filter(NewImage,sigma=npx*(UpFactor),mode='constant',cval=0)
            output=output*(UpFactor*UpFactor)
            output=np.nan_to_num(NewImage/output)
            #output[np.where(output==np.nan)]=0
            pl.matshow(output)
            pl.title('output')
            # pl.matshow(np.abs(np.fft.fftshift(np.fft.fft2(output+np.zeros(output.shape)))))
    
            
            weights=[]
            for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int)):
               weights.append(output[x,y])
        
            weightedImgFft=np.array(testimgFft)*np.array(weights)

            MyKx=SliceKx/scalex*OS/(np.pi*4)
            MyKy=SliceKy/scaley*OS/(np.pi*4)
            print np.amax(MyKx)
            print np.amin(MyKx)
            
            ############################################
            ####### This takes the unraveled matricies
            ############################################
            
            #custFft=rs.MyIfft(SliceKx/scalex*OS/(np.pi*4),SliceKy/scaley*OS/(np.pi*4),xmm,ymm,weightedImgFft)
            # custFft=rs.MyIfft(MyKx,MyKy,xmm,ymm,testimgFft)
            # custFft=ravel_kspace(custFft,orig_size)
            # 
            
            ############################################
            ####### This takes the 2D NxM matricies
            ############################################
            Xmap=rs.ravel_kspace(SliceKx,true128.shape)
            Ymap=rs.ravel_kspace(SliceKy,true128.shape)
            
            
            pl.matshow(np.log(np.abs(rs.ravel_kspace(testimgFft,true128.shape))))
            pl.title('Resampled')
            custFft=rs.MyIfft2(MyKx,MyKy,X,Y,testimgFft)
            #custFft=ravel_kspace(custFft,orig_size)            
            
            
            
            pl.matshow(np.abs(custFft))
            #custFft[56,56]=1
            
            pl.matshow(np.abs(np.fft.fftshift(custFft)))
            
            imgFft=rs.ravel_kspace(testimgFft,orig_size)
            img=np.fft.fft2(imgFft)
            pl.matshow(np.abs(img))
            
            pl.show()
            # testimgFft=rs.ravel_kspace(testimgFft,orig_size)
            
def New_Phantom_Ksamp2():
    
    gsCmap=sb.light_palette("black",n_colors=100,as_cmap=True,reverse=False)
    
    OS=112
    HRfactor=1.5
    UpFactor=10
    
    
    
    orig_size=(OS,OS)
    phSize=(OS*HRfactor,OS*HRfactor)
    image=phantom(np.round(OS*HRfactor).astype(int))
    true128=phantom(OS)
    orig128=phantom(OS)
    angle=[5]
    origkx,origky=create_kspace(orig_size[0],orig_size[1],angle=angle)
    refKx,refKy=create_kspace(orig_size[0],orig_size[1],angle=[0])
    
    xm,xi,ym,yi=rs.mapk2ind(refKx,refKy,orig_size,phSize,UpFactor)
    
    HrImgFft=np.fft.fftshift(np.fft.fft2(image))
    ZpHrImgFft=rs.upsample_fft(image,UpFactor)
    ZpHrImgFft=np.fft.fftshift(ZpHrImgFft)

    minKx=np.amin(refKx)
    minKy=np.amin(refKy)
    
    ikx=refKx-minKx
    iky=refKy-minKy
    
    maxKx=np.amax(ikx)
    maxKy=np.amax(iky)
    
    ikx=ikx/maxKx
    iky=iky/maxKy
    
    ikx=np.round(ikx*OS).astype(int)
    iky=np.round(iky*OS).astype(int)
    
    dt=4.19379e-05
    dtx=1e-05
    T2s=50e-3
    
    xdim=2
    ydim=2
    
    xax=np.arange(OS)-OS/2.0
    yax=np.arange(OS)-OS/2.0
    
    xax=xax/OS*2*np.pi+np.pi
    yax=yax/OS*2*np.pi+np.pi
    # xax*=xdim
    # yax*=ydim
    
    X,Y=np.meshgrid(xax,yax)
    
    xmm=rs.unravel_kspace(X)
    ymm=rs.unravel_kspace(Y)
    # 
    # pl.matshow(X)
    # pl.matshow(Y)
    # pl.figure()
    # 
    # pl.plot(xmm,ymm)
    # pl.show()
    # 
    
    scalex=((np.amax(refKx)-np.amin(refKx)))/2
    #Kx=Kx/scalex#*(np.pi/dx)
    # 
    scaley=((np.amax(refKy)-np.amin(refKy)))/2
    #Ky=Ky/scaley#*(np.pi/dy)

    SliceKx=origkx
    SliceKy=origky
    
    pl.matshow(np.log(np.abs(HrImgFft)),origin='lower')
    pl.title('HR FFt')
    pl.matshow(np.log(np.abs(ZpHrImgFft)),origin='lower')
    pl.title('Zero Pad Fft')
    
    k2ix=np.array([xi+xm*kx for kx in refKx])
    k2iy=np.array([yi+ym*ky for ky in refKy])
    
    RefFftSamp=[ZpHrImgFft[x,y]/HRfactor for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int))]
    RefFftSamp=rs.ravel_kspace(RefFftSamp,true128.shape)

    
    k2ix=np.array([xi+xm*kx for kx in SliceKx])
    k2iy=np.array([yi+ym*ky for ky in SliceKy])
    
    pl.plot(k2ix,k2iy,'-*')

    testimgFft=[ZpHrImgFft[x,y]/HRfactor for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int))]
    
    
    
    
    
    
    
    #testimgFft=rs.unravel_kspace(Fcpx)
    
    NewImage=np.zeros(ZpHrImgFft.shape)
    
    for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int)):                
        NewImage[x,y]=1
        
    Xmap=rs.ravel_kspace(SliceKx,true128.shape)
    Ymap=rs.ravel_kspace(SliceKy,true128.shape)
    
    
    X1=np.diff(Xmap,axis=0)
    Y1=np.diff(Xmap,axis=1)
    
    X2=np.diff(Ymap,axis=0)
    Y2=np.diff(Ymap,axis=1)            
    
    m1=np.amax(np.sqrt(np.square(X1[:,1:])+np.square(Y1[1:,:])))
    m2=np.amax(np.sqrt(np.square(X2[:,1:])+np.square(Y2[1:,:])))
    
    mx=np.amax((m1,m2))
    npx=mx*true128.shape[0]/(np.amax(SliceKx)-np.amin(SliceKx))
    
    
    output=ndi.filters.gaussian_filter(NewImage,sigma=npx*(UpFactor),mode='constant',cval=0)
    output=output*(UpFactor*UpFactor)
    output=np.nan_to_num(NewImage/output)
    #output[np.where(output==np.nan)]=0
    pl.matshow(output)
    pl.title('output')
    # pl.matshow(np.abs(np.fft.fftshift(np.fft.fft2(output+np.zeros(output.shape)))))

    
    weights=[]
    for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int)):
       weights.append(output[x,y])

    weightedImgFft=np.array(testimgFft)*np.array(weights)

    MyKx=SliceKx/scalex*OS/(np.pi*4)
    MyKy=SliceKy/scaley*OS/(np.pi*4)
    print np.amax(MyKx)
    print np.amin(MyKx)
    
    ############################################
    ####### This takes the unraveled matricies
    ############################################
    
    #custFft=rs.MyIfft(SliceKx/scalex*OS/(np.pi*4),SliceKy/scaley*OS/(np.pi*4),xmm,ymm,weightedImgFft)
    # custFft=rs.MyIfft(MyKx,MyKy,xmm,ymm,testimgFft)
    # custFft=ravel_kspace(custFft,orig_size)
    # 
    
    ############################################
    ####### This takes the 2D NxM matricies
    ############################################
    Xmap=rs.ravel_kspace(SliceKx,true128.shape)
    Ymap=rs.ravel_kspace(SliceKy,true128.shape)
    
    
    pl.matshow(np.log(np.abs(rs.ravel_kspace(testimgFft,true128.shape))))
    pl.title('Resampled')
    print "THIS IS MY STUFF"
    print MyKx
    print MyKy
    print X
    print Y
    print "K NOW"
    print np.shape(testimgFft)
    
    
    custFft=rs.MyIfft2(MyKx,MyKy,X,Y,testimgFft)
    #custFft=ravel_kspace(custFft,orig_size)            
    
    custFft=np.matrix(custFft).T
    custFft=rs.norm(np.abs(custFft))#/np.amax(np.abs(custFft))
    
    
    pl.matshow(np.abs(custFft))
    pl.title('My Custum Fft')
    #custFft[56,56]=1
    
    #pl.matshow(np.abs(np.fft.fftshift(custFft)))
    
    imgFft=rs.ravel_kspace(testimgFft,orig_size)
    img=np.fft.fft2(imgFft)
    img=img/(112*112)
    img=np.rot90(np.rot90(img))
    img=rs.norm(np.abs(img))#/np.amax(np.abs(img))
    
    dsorig=np.abs(np.fft.ifft2(RefFftSamp))
    fsize=(4,3)
    
    f,ax=pl.subplots(1,1,figsize=(3,3))
    ax.matshow(true128,cmap=gsCmap)
    ax.set_title('Original Hi-Res')
    ax.tick_params(labelbottom='off',bottom='off',top='off',left='off',labelleft='off',labeltop='off',labelright='off')
    
    f,ax=pl.subplots(1,1,figsize=(3,3))
    ax.matshow(np.abs(dsorig),cmap=gsCmap)
    ax.set_title('Undistorted')
    ax.tick_params(labelbottom='off',bottom='off',top='off',left='off',labelleft='off',labeltop='off',labelright='off')

    
    f,ax=pl.subplots(1,1,figsize=(3,3))
    true128=rs.norm(dsorig)#/np.amax(np.abs(dsorig))
    ax.matshow(np.abs(img),cmap=gsCmap)
    ax.set_title('Uncorrected Reconstruction')
    ax.tick_params(labelbottom='off',bottom='off',top='off',left='off',labelleft='off',labeltop='off',labelright='off')

    f,ax=pl.subplots(1,1,figsize=(4,3))    
    cax=ax.matshow(np.abs(true128-np.abs(img)),vmin=-0,vmax=1,cmap=gsCmap)
    ax.set_title('U.R. - Undistorted')
    cbar=f.colorbar(cax,ticks=[-1,0,1])
    ax.tick_params(labelbottom='off',bottom='off',top='off',left='off',labelleft='off',labeltop='off',labelright='off')
    
    f,ax=pl.subplots(1,1,figsize=(4,3))
    cax=ax.matshow(np.abs(true128-np.abs(custFft)),vmin=-0,vmax=1,cmap=gsCmap)
    ax.set_title('S.C.R. - Undistorted')
    cbar=f.colorbar(cax,ticks=[-1,0,1])
    ax.tick_params(labelbottom='off',bottom='off',top='off',left='off',labelleft='off',labeltop='off',labelright='off')
    
    
    
    f,ax=pl.subplots(1,1,figsize=(3,3))
    ax.matshow(true128,cmap=gsCmap)
    ax.set_title('Sample Corrected Reconstruction')
    ax.tick_params(labelbottom='off',bottom='off',top='off',left='off',labelleft='off',labeltop='off',labelright='off')

    #pl.close()
    
    Data=[]
    diff=np.reshape(true128-np.abs(img),-1)
    
    print('maxorig:\t{}').format(np.amax(orig128[0,0]))
    print('maxtrue:\t{}'.format(np.amax(np.abs(true128[0,0]))))
    print('maxifft:\t{}'.format(np.amax(np.abs(img[0,0]))))
    print('maxCust:\t{}'.format(np.amax(np.abs(custFft[0,0]))))
    
    
    MSEuc=np.mean((np.power(diff,2)))
    Data.append(diff)
    UCdiff=diff
    
    pl.figure()
    #pl.plot(np.ones(len(diff)),diff,'*',label='Uncorrected')
    
    diff=np.reshape(true128-np.abs(custFft),-1)
    MSEmc=np.mean((np.power(diff,2)))
    Data.append(diff)
    MCdiff=diff
    
    bins=np.linspace(0,.99,199)
    sb.violinplot(data=Data)
    pl.figure()
    sb.distplot(np.abs(UCdiff),bins=bins,kde=False)
    sb.distplot(np.abs(MCdiff),bins=bins,kde=False)
    print 'Uncorrected MSE:\t{}'.format(MSEuc)
    print 'MyCorrected MSE:\t{}'.format(MSEmc)
    pl.show()
    #pl.close()
    #pl.plot(np.ones(len(diff))*2,diff,'+',label='Mycorrected')
    #pl.legend()
    #pl.grid()

    
    
    #pl.show()
            # testimgFft=rs.ravel_kspace(testimgFft,orig_size)


def test_phantom():
    gsCmap=sb.light_palette("black",n_colors=256,as_cmap=True,reverse=True)
    
    os=128
    Up=10
    orig_size=(os,os)
    phSize=(os*Up,os*Up)
    image=phantom(matrix_size=phSize)
    true128=phantom(os)
    
    
    refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
    sampkx,sampky=create_kspace(orig_size[0],orig_size[1],angle=[0.6])
    
    refkx+=np.abs(np.amin(refkx))
    refky+=np.abs(np.amin(refky))
    
    
    sampkx+=np.abs(np.amin(refkx))
    sampky+=np.abs(np.amin(refky))
    

    
    # For No Resampling:
    newfft,origkx,origky,refkx,refky=simulate_kspace_sampling(image,orig_size,[0])
    newimg0=np.fft.ifft2(newfft)
    
    # 
    # IntFft=interpolate_Kspace(np.abs(newfft),origkx,origky,refkx,refky,orig_size)
    # IntImg0=np.fft.ifft2(IntFft)
    # 
    
    # For 1degree rotation
    newfft,origkx,origky,refkx,refky=simulate_kspace_sampling(image,orig_size,[0.6])
    newimg1=np.fft.ifft2(newfft)
    
    
    
    smallfft,sorigkx,sorigky,srefkx,srefky=simulate_kspace_sampling(image,orig_size,[0])
    junk1,sorigkx,sorigky,srefkx,srefky=simulate_kspace_sampling(image,(20,20),[20])
    trefx=(srefkx.astype(float)-(srefkx[0]))
    trefx=trefx/np.amax(trefx)*128
    trefy=(srefky.astype(float)-(srefky[0]))
    trefy=trefy/np.amax(trefy)*128
    
    
    tracex=(sorigkx.astype(float)-(sorigkx[0]))
    tracex=tracex/np.amax(tracex)*128
    tracey=(sorigky.astype(float)-(sorigky[0]))
    tracey=tracey/np.amax(tracey)*128
    
    
    
    
    
    # pl.plot(origkx,origky,'-o')
    # pl.plot(refkx,refky,'-*')
    # pl.show()
    # 
    # img=np.zeros(orig_size)
    # for i in range(0,orig_size[0],10):
    #     img[i,:]=1
    # 
    # tracex,tracey=create_kspace(orig_size[0],orig_size[1],sample_zero=False)
    # tracex-=np.min(tracex)
    # tracey-=np.min(tracey)
    # for ix,iy in zip(tracex,tracey):
    #     print '{} , {}'.format(ix,iy)
    #     img[int(ix),int(iy)]=ix+1000*iy
    #     
    # xr=(np.random.rand(1000)*128).astype(int)
    # 
    # pl.matshow(np.matrix(img))
    # 
    # pl.show()
    # 
    # resampTest=interpolate_Kspace(img,origkx,origky,refkx,refky,orig_size)
    # pl.imshow(np.real(resampTest))
    # pl.figure()
    # pl.imshow(img)
    # pl.figure()
    # pl.plot(origkx,origky,'-o')
    # pl.plot(refkx,refky,'-*')
    # pl.show()
    # 
    # # 
    # pl.matshow(np.abs(newfft))
    # pl.show()
    IntFft=interpolate_Kspace(newfft,origkx,origky,refkx,refky,orig_size)
    IntImg1=np.fft.ifft2(IntFft).T
    # pl.matshow(np.log(norm(np.abs(IntImg1))))
    # pl.show()
    
    # This Shows Error Between zero motion and resampled
    # pl.matshow(np.abs(newimg0))
    # pl.matshow(np.abs(IntImg0))
    # pl.matshow(np.abs(IntImg0)-np.abs(newimg0))
    # pl.show()
    
    
    
    
    
    
    e1=error(true128,np.abs(newimg1))
    e0=error(true128,np.abs(newimg0))
    e2=error(true128,np.abs(IntImg1))
    vmin=np.amin(e2)
    #vmin=0
    vmax=np.amax(e2)
    print vmin
    print vmax
    
    f,ax=pl.subplots(nrows=3,ncols=3,squeeze=True)
    
    a=ax[0][0]
    a.matshow(np.abs(true128))
    a.set_title('Original Image')
    
    a=ax[0][1]
    a.matshow(np.abs(newimg0))
    a.set_title('Kspace Resampled 0 Rotation')
    
    a=ax[0][2]
    #cax=a.matshow(e0,cmap=pl.cm.bwr,norm=LogNorm(vmin=0.001,vmax=1))
    cax=a.matshow(e0,cmap=pl.cm.OrRd,vmin=vmin,vmax=vmax)
    f.colorbar(cax)
    #a.matshow(e0,cmap=pl.cm.bwr,vmin=vmin,vmax=vmax)
    a.set_title('Difference')
    
    
    
    a=ax[1][0]
    a.matshow(np.abs(true128))
    a.set_title('Original Image')
    
    a=ax[1][1]
    a.matshow(np.abs(newimg1))
    a.set_title('Kspace Simulated 5 Rotation')
    
    a=ax[1][2]
    #a.matshow(e1,cmap=pl.cm.bwr,norm=LogNorm(vmin=0.001,vmax=1))
    
    a.matshow(e1,cmap=pl.cm.OrRd,vmin=vmin,vmax=vmax)
    a.set_title('Difference')
    
    
    
    a=ax[2][0]
    a.matshow(np.abs(true128))
    a.set_title('Original Image')
    
    a=ax[2][1]
    a.matshow(norm(np.abs(IntImg1)))
    a.set_title('Kspace Resampled 5 Rotation')
    
    a=ax[2][2]
    #a.matshow(e2,cmap=pl.cm.bwr,norm=LogNorm(vmin=0.001,vmax=1))
    a.matshow(e2,cmap=pl.cm.OrRd,vmin=vmin,vmax=vmax)
    a.set_title('Difference')
    
    pl.show()    











def test_phantom2():
    gsCmap=sb.light_palette("black",n_colors=256,as_cmap=True,reverse=True)
    phSize=128
    orig_size=(128,128)
    image=phantom(matrix_size=phSize)
    true128=phantom(128)
    
    
    refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
    sampkx,sampky=create_kspace(orig_size[0],orig_size[1],angle=[1.0])
    
    refkx+=np.abs(np.amin(refkx))
    refky+=np.abs(np.amin(refky))
    
    
    sampkx+=np.abs(np.amin(refkx))
    sampky+=np.abs(np.amin(refky))
    

    
    # For No Resampling:
    newfft0,origkx,origky,refkx,refky=simulate_kspace_sampling(image,orig_size,[0])
    newimg0=np.fft.ifft2(newfft0)

    
    # IntFft=interpolate_Kspace(np.abs(newfft0),origkx,origky,refkx,refky,orig_size)
    # IntImg0=np.fft.ifft2(IntFft)
    # 
    # 
    
  
    # For 5degree rotation
    #newfft,origkx,origky,refkx,refky=simulate_kspace_sampling2(image,orig_size,[20])
    newfft,origkx,origky,refkx,refky=simulate_kspace_sampling4(image,orig_size,[1.0])
    newimg1=np.fft.ifft2(newfft)
    pl.imshow(np.abs(newimg1))
    pl.show()
    
    
    # modfft=copyKspaceQuadrent(newfft,1)
    # dfft=modfft-newfft
    # pl.matshow(np.log(np.abs(dfft)))
    # pl.title('Diff')
    # pl.matshow(np.log(np.abs(modfft)))
    # pl.title('modff')
    pl.matshow(np.log(np.abs(newfft)))
    pl.title('rotated')
    pl.matshow(np.log(np.abs(newfft0)))
    pl.title('Orig')
    pl.matshow(np.abs(newimg1[0:orig_size[0],0:orig_size[1]]))
    pl.title('cropped')
    pl.matshow(np.abs(newimg1))
    pl.title('full')
    # 
    # newfft,origkx,origky,refkx,refky=simulate_kspace_sampling(image,orig_size,[20])
    # newimg1=np.fft.ifft2(newfft)
    # pl.matshow(np.log(np.abs(newfft)))
    # pl.title('rotated')
    # pl.matshow(np.log(np.abs(newfft0)))
    # pl.title('Orig')
    # pl.matshow(np.abs(newimg1))   
    # 
    # 
    # pl.show()
    # 
    # # pl.matshow(np.abs(newfft))
    # # pl.matshow(np.abs(newimg1))
    # # pl.title('NewResampledImage1')
    # # oldnewfft,origkx,origky,refkx,refky=simulate_kspace_sampling(image,orig_size,[20])
    # # oldnewimg1=np.fft.ifft2(oldnewfft)
    # # pl.matshow(np.abs(oldnewimg1))
    # # pl.show()
    # 
    # 
    # smallfft,sorigkx,sorigky,srefkx,srefky=simulate_kspace_sampling(image,orig_size,[0])
    # junk1,sorigkx,sorigky,srefkx,srefky=simulate_kspace_sampling(image,(20,20),[20])
    # trefx=(srefkx.astype(float)-(srefkx[0]))
    # trefx=trefx/np.amax(trefx)*128
    # trefy=(srefky.astype(float)-(srefky[0]))
    # trefy=trefy/np.amax(trefy)*128
    # 
    # 
    # tracex=(sorigkx.astype(float)-(sorigkx[0]))
    # tracex=tracex/np.amax(tracex)*128
    # tracey=(sorigky.astype(float)-(sorigky[0]))
    # tracey=tracey/np.amax(tracey)*128
    # 
    # 
    # 
    # 
    # 
    # # pl.plot(origkx,origky,'-o')
    # # pl.plot(refkx,refky,'-*')
    # # pl.show()
    # # 
    # # img=np.zeros(orig_size)
    # # for i in range(0,orig_size[0],10):
    # #     img[i,:]=1
    # # 
    # # tracex,tracey=create_kspace(orig_size[0],orig_size[1],sample_zero=False)
    # # tracex-=np.min(tracex)
    # # tracey-=np.min(tracey)
    # # for ix,iy in zip(tracex,tracey):
    # #     print '{} , {}'.format(ix,iy)
    # #     img[int(ix),int(iy)]=ix+1000*iy
    # #     
    # # xr=(np.random.rand(1000)*128).astype(int)
    # # 
    # # pl.matshow(np.matrix(img))
    # # 
    # # pl.show()
    # # 
    # # resampTest=interpolate_Kspace(img,origkx,origky,refkx,refky,orig_size)
    # # pl.imshow(np.real(resampTest))
    # # pl.figure()
    # # pl.imshow(img)
    # # pl.figure()
    # # pl.plot(origkx,origky,'-o')
    # # pl.plot(refkx,refky,'-*')
    # # pl.show()
    # # 
    # # # 
    # # pl.matshow(np.abs(newfft))
    # # pl.show()
    # IntFft=interpolate_Kspace(newfft,origkx,origky,refkx,refky,orig_size)
    # IntImg1=np.fft.ifft2(IntFft).T
    # # pl.matshow(np.log(norm(np.abs(IntImg1))))
    # # pl.show()
    # 
    # # This Shows Error Between zero motion and resampled
    # # pl.matshow(np.abs(newimg0))
    # # pl.matshow(np.abs(IntImg0))
    # # pl.matshow(np.abs(IntImg0)-np.abs(newimg0))
    # # pl.show()
    # 
    # 
    # 
    # 
    # 
    # 
    # e1=error(true128,np.abs(newimg1))
    # e0=error(true128,np.abs(newimg0))
    # e2=error(true128,np.abs(IntImg1))
    # vmin=np.amin(e2)
    # #vmin=0
    # vmax=np.amax(e2)
    # print vmin
    # print vmax
    # 
    # f,ax=pl.subplots(nrows=3,ncols=3,squeeze=True)
    # 
    # a=ax[0][0]
    # a.matshow(np.abs(true128))
    # a.set_title('Original Image')
    # 
    # a=ax[0][1]
    # a.matshow(np.abs(newimg0))
    # a.set_title('Kspace Resampled 0 Rotation')
    # 
    # a=ax[0][2]
    # #cax=a.matshow(e0,cmap=pl.cm.bwr,norm=LogNorm(vmin=0.001,vmax=1))
    # cax=a.matshow(e0,cmap=pl.cm.OrRd,vmin=vmin,vmax=vmax)
    # f.colorbar(cax)
    # #a.matshow(e0,cmap=pl.cm.bwr,vmin=vmin,vmax=vmax)
    # a.set_title('Difference')
    # 
    # 
    # 
    # a=ax[1][0]
    # a.matshow(np.abs(true128))
    # a.set_title('Original Image')
    # 
    # a=ax[1][1]
    # a.matshow(np.abs(newimg1))
    # a.set_title('Kspace Simulated 5 Rotation')
    # 
    # a=ax[1][2]
    # #a.matshow(e1,cmap=pl.cm.bwr,norm=LogNorm(vmin=0.001,vmax=1))
    # 
    # a.matshow(e1,cmap=pl.cm.OrRd,vmin=vmin,vmax=vmax)
    # a.set_title('Difference')
    # 
    # 
    # 
    # a=ax[2][0]
    # a.matshow(np.abs(true128))
    # a.set_title('Original Image')
    # 
    # a=ax[2][1]
    # a.matshow(norm(np.abs(IntImg1)))
    # a.set_title('Kspace Resampled 5 Rotation')
    # 
    # a=ax[2][2]
    # #a.matshow(e2,cmap=pl.cm.bwr,norm=LogNorm(vmin=0.001,vmax=1))
    # a.matshow(e2,cmap=pl.cm.OrRd,vmin=vmin,vmax=vmax)
    # a.set_title('Difference')
    # 
    # pl.show()    



def test_phantom_MagErrors():
    gsCmap=sb.light_palette("black",n_colors=256,as_cmap=True,reverse=True)
    phSize=256
    orig_size=(128,128)
    image=phantom(matrix_size=phSize)
    true128=phantom(128)
    
    
    ln=256
    imageF=np.zeros((ln,ln))
    
    HRimageF=np.zeros((ln*10,ln*10))
    # image[20:60,5:10]=1
    # image[100:115,180:230]=1
    # image[160:165,60:80]=1
    # image[155:160,80:100]=1
    # image[160:165,100:120]=1
    
    imageF[120:136,120:136]=1
    HRimageF[1200:1360,1200:1360]=1
    image=np.abs(np.fft.fftshift(np.fft.fft2(imageF)))
    
    
    
    refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
    sampkx,sampky=create_kspace(orig_size[0],orig_size[1],angle=[5])
    
    refkx+=np.abs(np.amin(refkx))
    refky+=np.abs(np.amin(refky))
    
    
    sampkx+=np.abs(np.amin(refkx))
    sampky+=np.abs(np.amin(refky))
    

    
    # For No Resampling:
    newfft0,origkx,origky,refkx,refky=simulate_kspace_sampling(image,orig_size,[0])
    newimg0=np.fft.ifft2(newfft0)
    
    
    IntFft=interpolate_Kspace(np.abs(newfft0),origkx,origky,refkx,refky,orig_size)
    IntImg0=np.fft.ifft2(IntFft)
    
    UF=10
    HR_F=upsample_fft(np.fft.ifft2(imageF),UF)
    pl.matshow(np.abs(HRimageF))
    pl.title('upsampled')
    pl.show()
    # For 5degree rotation
    newfft,origkx,origky,refkx,refky=simulate_kspace_sampling3(HRimageF,(256,256),orig_size,[0.6])
    newimg=np.fft.ifftshift(np.fft.ifft2(newfft))
    
    pl.matshow(np.abs(imageF))
    pl.title('Original')
    pl.matshow(np.abs(newfft))
    pl.title('10 degree rotation')
    
    pl.matshow(np.abs(newimg0))
    pl.title('OriginalImage')
    pl.matshow(np.abs(newimg))
    pl.title('MotionImage')
    
    fftSwitch=np.fft.fftshift(np.fft.fft2(np.abs(newimg)))
    
    pl.matshow(np.log(np.abs(fftSwitch)))
    pl.title('Abs rotated image fft')
    
    pl.matshow(np.log(np.abs(np.abs(fftSwitch)-np.abs(newfft))))
    pl.title('log difference')
    pl.show()
    newimg1=np.fft.ifft2(newfft)
    
    
    
    # pl.matshow(np.abs(newfft))
    # pl.matshow(np.abs(newimg1))
    # pl.title('NewResampledImage1')
    # oldnewfft,origkx,origky,refkx,refky=simulate_kspace_sampling(image,orig_size,[20])
    # oldnewimg1=np.fft.ifft2(oldnewfft)
    # pl.matshow(np.abs(oldnewimg1))
    # pl.show()
    
    pass





def phantom_Images():
    gs=sb.light_palette("black",n_colors=256,as_cmap=True,reverse=True)
    gsCmap=cm.gnuplot2
    phSize=256
    orig_size=(128,128)
    image=phantom(matrix_size=phSize)
    true128=phantom(128).T
    
    
    refkx,refky=create_kspace(orig_size[0],orig_size[1],angle=[0])
    sampkx,sampky=create_kspace(orig_size[0],orig_size[1],angle=[5])
    
    refkx+=np.abs(np.amin(refkx))
    refky+=np.abs(np.amin(refky))
    
    
    sampkx+=np.abs(np.amin(refkx))
    sampky+=np.abs(np.amin(refky))
    

    
    # For No Resampling:
    newfft,origkx,origky,refkx,refky=simulate_kspace_sampling(image,orig_size,[0])
    newimg0=np.fft.ifft2(newfft)
    newfft0=newfft
    
    IntFft=interpolate_Kspace(np.abs(newfft),origkx,origky,refkx,refky,orig_size)
    IntImg0=np.fft.ifft2(IntFft)
    
    
    # For 1degree rotation
    newfft,origkx,origky,refkx,refky=simulate_kspace_sampling(image,orig_size,[5])
    newimg1=np.fft.ifft2(newfft)
    
    # pl.plot(origkx,origky,'-o')
    # pl.plot(refkx,refky,'-*')
    # pl.show()
    # 
    # img=np.zeros(orig_size)
    # for i in range(0,orig_size[0],10):
    #     img[i,:]=1
    # 
    # tracex,tracey=create_kspace(orig_size[0],orig_size[1],sample_zero=False)
    # tracex-=np.min(tracex)
    # tracey-=np.min(tracey)
    # for ix,iy in zip(tracex,tracey):
    #     print '{} , {}'.format(ix,iy)
    #     img[int(ix),int(iy)]=ix+1000*iy
    #     
    # xr=(np.random.rand(1000)*128).astype(int)
    # 
    # pl.matshow(np.matrix(img))
    # 
    # pl.show()
    # 
    # resampTest=interpolate_Kspace(img,origkx,origky,refkx,refky,orig_size)
    # pl.imshow(np.real(resampTest))
    # pl.figure()
    # pl.imshow(img)
    # pl.figure()
    # pl.plot(origkx,origky,'-o')
    # pl.plot(refkx,refky,'-*')
    # pl.show()
    # 
    # 
    # pl.matshow(np.abs(newfft))
    # pl.show()
    IntFft=interpolate_Kspace(newfft,origkx,origky,refkx,refky,orig_size)
    IntImg1=np.fft.ifft2(IntFft).T
    # pl.matshow(np.log(norm(np.abs(IntImg1))))
    # pl.show()
    
    # This Shows Error Between zero motion and resampled
    # pl.matshow(np.abs(newimg0))
    # pl.matshow(np.abs(IntImg0))
    # pl.matshow(np.abs(IntImg0)-np.abs(newimg0))
    # pl.show()
    
    smallfft,sorigkx,sorigky,srefkx,srefky=simulate_kspace_sampling(image,orig_size,[0])
    junk1,sorigkx,sorigky,srefkx,srefky=simulate_kspace_sampling(image,(20,20),[5])
    trefx=(srefkx.astype(float)-(srefkx[0]))
    trefx=trefx/np.amax(trefx)*128
    trefy=(srefky.astype(float)-(srefky[0]))
    trefy=trefy/np.amax(trefy)*128
    
    
    tracex=(sorigkx.astype(float)-(sorigkx[0]))
    tracex=tracex/np.amax(tracex)*128
    tracey=(sorigky.astype(float)-(sorigky[0]))
    tracey=tracey/np.amax(tracey)*128
    
    e1=error(true128,np.abs(newimg1))
    e0=error(true128,np.abs(newimg0))
    e2=error(true128,np.abs(IntImg1))
    vmin=np.amin(e2)
    
    
    #vmin=0
    vmax=np.amax(e2)
    print vmin
    print vmax
    f,a=pl.subplots(1,1,figsize=(8,6))
    a.matshow(np.abs(newimg0),cmap=gsCmap)
    a.set_title('Original Phantom')
    
    
    
    f,a=pl.subplots(1,1,figsize=(8,6))
    a.matshow(np.abs(newimg1),cmap=gsCmap)
    a.set_title('Kspace Simulated 5 Rotation')
    
    f,a=pl.subplots(1,1,figsize=(8,6))
    a.matshow(np.abs(IntImg1),cmap=gsCmap)
    a.set_title('Reconstructed')

    
    f,a=pl.subplots(1,1,figsize=(8,6))
    a.matshow(np.log(np.abs(newfft0)),cmap=gs,origin='lower')
    a.plot(trefy,trefx,'r--o')

    
    f,a=pl.subplots(1,1,figsize=(8,6))
    a.matshow(np.log(np.abs(newfft)),cmap=gs,origin='lower')
    a.plot(tracey,tracex,'r--o')
    pl.show()
       
    
def test_quadcopy():
    image=np.zeros((112,112))
    image[10:20,10:50]=1
    image[5:45,40:50]=2
    copyKspaceQuadrent(image,1)



def TestRandom():
    image=phantom(112)
    percentSample=0.8
    randar=np.random.choice(112*112,int(112*112*percentSample),replace=False)
    xy=np.unravel_index(randar,(112,112))
    
    Fft=np.fft.fftshift(np.fft.fft2(image))
    newFft=np.zeros((112,112),dtype=complex)
    for x,y in zip(xy[0],xy[1]):
        newFft[x,y]=Fft[x,y]
    
    pl.matshow(np.abs(newFft))
    pl.show()
    
    img2=np.fft.fftshift(np.fft.ifft2(newFft))
    pl.matshow(np.abs(img2))
    UF=11
    HRfft=np.zeros((112*UF,112*UF),dtype=complex)
    
    
    
    for x,y in zip(xy[0],xy[1]):
        
        HRfft[x*UF+np.floor(UF/2).astype(int),y*UF+np.floor(UF/2).astype(int)]=Fft[x,y]
    HRimg=np.fft.ifft2(np.fft.ifftshift(HRfft))
    pl.matshow(np.abs(HRimg))
    pl.show()
    
    # 
    # AveImage=np.zeros((112,112*UF),dtype=complex)
    # for i in range(UF):
    #     AveImage+=HRimg[112*i:112*i+112,:]
    # AveImage/=10
    # pl.matshow(np.abs(AveImage))
    # pl.show()
    # 
        
    

def test_RawSignal():
    x=np.fromfile('/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord3/signal',dtype=float)
    x=x[2:]
    print x.shape
    skip=112*112
    signal=np.zeros((2,skip*7))
    signal[0,:]=x[:skip*7]
    signal[1,:]=x[skip*7:]
    
    
    # signal=np.zeros((2,skip*7+1))
    # signal[0,:]=x[:skip*7+1]
    # signal[1,:]=x[skip*7+1:]
    # xreal=x[:skip*7]
    # ximag=x[skip*7:]
    #
    
    
    slcdir=1
    nslc=1
    phasedir=2
    nphase=112
    readdir=3
    nread=112
    startkspace=0
    
    
    
    xreal,ximag=rs.ReshapeEpiSignal(signal,slcdir,nslc,phasedir,nphase,readdir,nread,startkspace,112)
    
    
    print np.shape(xreal)
    print np.shape(ximag)
    
    testvol=np.squeeze(xreal[:,:,0,0]+1j*np.squeeze(ximag[:,:,0,0]))
    
    print testvol.shape
    pl.matshow(np.log(np.abs(testvol)));pl.show()
    
    # Fsig=np.zeros((112,112),dtype=complex)
    # Fsig=xreal+1j*ximag
    # 
    # 
    # 
    # Fmat=rs.ravel_kspace(Fsig,(112,112))
    # pl.matshow(np.fft.fftshift(np.log(np.abs(Fmat))))
    # pl.show()



def project(Mat3d):
    Mat2d=np.sum(Mat3d,axis=-1)
    return(Mat2d)
    



def TestOutOfPlane():
    
    gsCmap=sb.light_palette("black",n_colors=100,as_cmap=True,reverse=False)    
    OS=112
    HRfactor=1.5
    UpFactor=10
    
    orig_size=(OS,OS)
    phSize=(int(np.round(OS*HRfactor)),int(np.round(OS*HRfactor)))
    phSize=((OS,OS))
    image=phantom(np.round(OS).astype(int))
    true128=phantom(OS)
    orig128=phantom(OS)
    
    xax=np.arange(OS)-OS/2.0
    yax=np.arange(OS)-OS/2.0
    
    xax=xax/OS*2*np.pi+np.pi
    yax=yax/OS*2*np.pi+np.pi
    # xax*=xdim
    # yax*=ydim
    
    X,Y=np.meshgrid(xax,yax)
    
    
    Nx=OS
    Ny=OS
    
    
    
    hires3d=np.zeros((phSize[0],phSize[0],82))
    print hires3d.shape
    mid=np.round(hires3d.shape[-1]/2).astype(int)
    hires3d[:,:,mid]=image
    center=0.5*np.array(hires3d.shape)
    samplex,sampley=rs.create_kspace(OS,OS)
    
    samplex=samplex-np.amin(samplex)
    sampley=sampley-np.amin(sampley)    
    kxinds=samplex.astype(int)
    kyinds=sampley.astype(int)
    
    print len(kxinds)
    Angles=np.linspace(0,45,len(kxinds))
    MyKspace=np.zeros((OS,OS),complex)
    # 
    # for i in range(len(kxinds)):
    #     print i
    #     
    #     kx=kxinds[i]
    #     ky=kyinds[i]
    #     
    #     theta=Angles[i]    
    #     Mat=rs.RotMat([0,theta,0])       
    #     offset=(center-center.dot(Mat)).A1   
    #     
    #     mat=ndi.interpolation.affine_transform(hires3d,Mat.T,offset=offset,output_shape=hires3d.shape)
    #     mat2d=project(mat)
    #     
    #     Kspace=np.fft.fftshift(np.fft.fft2(mat2d))
    #     MyKspace[kx,ky]=Kspace[kx,ky]
    # 
    # 
    # 
    # output='/home/dparker/Desktop/MyKOut45'
    # pl.matshow(np.log(np.abs(MyKspace)))
    # MyImg=np.fft.fftshift(np.fft.ifft2(MyKspace))
    # pl.matshow(np.abs(MyImg))
    # pl.show()
    # np.save(output,MyKspace)
    # 
    
    scalex=Nx/2.0
    scaley=Ny/2.0
    
    xax=np.arange(OS)-OS/2.0
    yax=np.arange(OS)-OS/2.0
    
    xax=xax/OS*2*np.pi+np.pi
    yax=yax/OS*2*np.pi+np.pi+np.pi/3
    # xax*=xdim
    # yax*=ydim
    
    X,Y=np.meshgrid(xax,yax)
    
    Kx=np.arange(0,Nx)-scalex
    Ky=np.arange(0,Ny)-scalex
    
    Kx,Ky=np.meshgrid(Kx,Ky)
    
    MyKx=Kx/scalex*OS/(np.pi*4)
    MyKy=Ky/scaley*OS/(np.pi*4)
    
    kyrot=MyKy*np.cos(45*np.pi/180.0)
    MyKx=rs.unravel_kspace(MyKx)
    MyKy=rs.unravel_kspace(kyrot)
    
    Mat=rs.RotMat([0,0,0])
    offset=(center-center.dot(Mat)).A1
    mat=ndi.interpolation.affine_transform(hires3d,Mat.T,offset=offset,output_shape=hires3d.shape)
    mat2d=project(mat)
    Kspace=np.fft.fftshift(np.fft.fft2(mat2d))
    
    pl.matshow(mat2d)
    pl.title('Rot=0')
    pl.matshow(np.log(np.abs(np.fft.fftshift(np.fft.fft2(mat2d)))))
    pl.title('Rot=0')
    
    
    Mat=rs.RotMat([0,45,0])
    offset=(center-center.dot(Mat)).A1
    mat=ndi.interpolation.affine_transform(hires3d,Mat.T,offset=offset,output_shape=hires3d.shape)
    mat2d=project(mat)
    Kspace=np.fft.fftshift(np.fft.fft2(mat2d))
    
    flatKspace=rs.unravel_kspace(Kspace)
    custFft=rs.MyIfft2(MyKx,MyKy,X,Y,flatKspace)
    
    pl.matshow(np.abs(custFft))
    pl.title('DRIFT')
    
    
    pl.matshow(mat2d)
    pl.title('Rot=10')
    pl.matshow(np.log(np.abs(np.fft.fftshift(np.fft.fft2(mat2d)))))
    pl.title('Rot=10')    
    
        
    output='/home/dparker/Desktop/MyKOut45.npy'
    
    OldKspace=np.load(output)
    
    pl.matshow(np.abs(np.fft.ifft2(OldKspace)))
    pl.matshow(np.log(np.abs(OldKspace)))
    pl.show()



def CorrectOutOfPlane():
    
    gsCmap=sb.light_palette("black",n_colors=100,as_cmap=True,reverse=False)  
    output='/home/dparker/Desktop/MyKOut45.npy'
    
    OldKspace=np.load(output)
    
    
    Nx,Ny=np.shape(OldKspace)
    OS=Nx
    fovx=Nx
    
    scalex=Nx/2.0
    scaley=Ny/2.0
    
    xax=np.arange(OS)-OS/2.0
    yax=np.arange(OS)-OS/2.0
    
    xax=xax/OS*2*np.pi+np.pi
    yax=yax/OS*2*np.pi+np.pi
    # xax*=xdim
    # yax*=ydim
    
    X,Y=np.meshgrid(xax,yax)
    
    Kx=np.arange(0,Nx)-scalex
    Ky=np.arange(0,Ny)-scalex
    
    Kx,Ky=np.meshgrid(Kx,Ky)
    
    MyKx=Kx/scalex*OS/(np.pi*4)
    MyKy=Ky/scaley*OS/(np.pi*4)
    
    urKx=rs.unravel_kspace(MyKx)
    
    dkxRef=np.mean(np.diff(MyKx))
    
    samplex,sampley=rs.create_kspace(OS,OS)    
    kxinds=samplex.astype(int)
    kyinds=sampley.astype(int)
    
    print len(kxinds)
    
    
    Angles=np.linspace(0,45,len(kxinds))
    
    kx,ky=rs.create_OOP_kspace(OS,OS,angle=[45],axtilt='X')
    
    
    

        
  
    
    pl.plot(kx,ky,'-*')
 
    MyKx=rs.ravel_kspace(kx,(OS,OS))
    MyKy=rs.ravel_kspace(ky,(OS,OS))
    
    MyKx=MyKx/scalex*OS/(np.pi*4)
    MyKy=MyKy/scaley*OS/(np.pi*4)
    MyKx=rs.unravel_kspace(MyKx)
    MyKy=rs.unravel_kspace(MyKy)
    #X=rs.unravel_kspace(X)
    pl.matshow(np.log(np.abs(OldKspace)))
    pl.title('PreRot')
    #OldKspace=np.rot90(OldKspace,k=1)
    pl.matshow(np.log(np.abs(OldKspace)))
    pl.title('PostRot')
    
    flatKspace=rs.unravel_kspace(OldKspace)
    custFft=rs.MyIfft2(MyKx,MyKy,X,Y,flatKspace)
    
    pl.matshow(np.abs(custFft))
    pl.title('DRIFT')
    pl.matshow(np.abs(np.fft.ifft2(OldKspace)))
    pl.title('FFT')
    pl.matshow(np.log(np.abs(OldKspace)))
    pl.title('OLD Kspace')
    

    image=phantom(np.round(OS).astype(int))
    pl.matshow(np.log(np.abs(np.fft.fftshift(np.fft.fft2(image)))))
    pl.title('UnRotKspace')
    pl.show()
    

    # 
    # 
    # 
    # angle=[5]
    # origkx,origky=create_kspace(orig_size[0],orig_size[1],angle=angle)
    # refKx,refKy=create_kspace(orig_size[0],orig_size[1],angle=[0])
    # 
    # xm,xi,ym,yi=rs.mapk2ind(refKx,refKy,orig_size,phSize,UpFactor)
    # 
    # HrImgFft=np.fft.fftshift(np.fft.fft2(image))
    # ZpHrImgFft=rs.upsample_fft(image,UpFactor)
    # ZpHrImgFft=np.fft.fftshift(ZpHrImgFft)
    # 
    # minKx=np.amin(refKx)
    # minKy=np.amin(refKy)
    # 
    # ikx=refKx-minKx
    # iky=refKy-minKy
    # 
    # maxKx=np.amax(ikx)
    # maxKy=np.amax(iky)
    # 
    # ikx=ikx/maxKx
    # iky=iky/maxKy
    # 
    # ikx=np.round(ikx*OS).astype(int)
    # iky=np.round(iky*OS).astype(int)
    # 
    # dt=4.19379e-05
    # dtx=1e-05
    # T2s=50e-3
    # 
    # xdim=2
    # ydim=2
    # 
    # xax=np.arange(OS)-OS/2.0
    # yax=np.arange(OS)-OS/2.0
    # 
    # xax=xax/OS*2*np.pi+np.pi
    # yax=yax/OS*2*np.pi+np.pi
    # # xax*=xdim
    # # yax*=ydim
    # 
    # X,Y=np.meshgrid(xax,yax)
    # 
    # xmm=rs.unravel_kspace(X)
    # ymm=rs.unravel_kspace(Y)
    # # 
    # # pl.matshow(X)
    # # pl.matshow(Y)
    # # pl.figure()
    # # 
    # # pl.plot(xmm,ymm)
    # # pl.show()
    # # 
    # 
    # scalex=((np.amax(refKx)-np.amin(refKx)))/2
    # #Kx=Kx/scalex#*(np.pi/dx)
    # # 
    # scaley=((np.amax(refKy)-np.amin(refKy)))/2
    # #Ky=Ky/scaley#*(np.pi/dy)
    # 
    # SliceKx=origkx
    # SliceKy=origky
    # 
    # pl.matshow(np.log(np.abs(HrImgFft)),origin='lower')
    # pl.title('HR FFt')
    # pl.matshow(np.log(np.abs(ZpHrImgFft)),origin='lower')
    # pl.title('Zero Pad Fft')
    # 
    # k2ix=np.array([xi+xm*kx for kx in refKx])
    # k2iy=np.array([yi+ym*ky for ky in refKy])
    # 
    # RefFftSamp=[ZpHrImgFft[x,y]/HRfactor for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int))]
    # RefFftSamp=rs.ravel_kspace(RefFftSamp,true128.shape)
    # 
    # 
    # k2ix=np.array([xi+xm*kx for kx in SliceKx])
    # k2iy=np.array([yi+ym*ky for ky in SliceKy])
    # 
    # pl.plot(k2ix,k2iy,'-*')
    # 
    # testimgFft=[ZpHrImgFft[x,y]/HRfactor for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int))]
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    # #testimgFft=rs.unravel_kspace(Fcpx)
    # 
    # NewImage=np.zeros(ZpHrImgFft.shape)
    # 
    # for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int)):                
    #     NewImage[x,y]=1
    #     
    # Xmap=rs.ravel_kspace(SliceKx,true128.shape)
    # Ymap=rs.ravel_kspace(SliceKy,true128.shape)
    # 
    # 
    # X1=np.diff(Xmap,axis=0)
    # Y1=np.diff(Xmap,axis=1)
    # 
    # X2=np.diff(Ymap,axis=0)
    # Y2=np.diff(Ymap,axis=1)            
    # 
    # m1=np.amax(np.sqrt(np.square(X1[:,1:])+np.square(Y1[1:,:])))
    # m2=np.amax(np.sqrt(np.square(X2[:,1:])+np.square(Y2[1:,:])))
    # 
    # mx=np.amax((m1,m2))
    # npx=mx*true128.shape[0]/(np.amax(SliceKx)-np.amin(SliceKx))
    # 
    # 
    # output=ndi.filters.gaussian_filter(NewImage,sigma=npx*(UpFactor),mode='constant',cval=0)
    # output=output*(UpFactor*UpFactor)
    # output=np.nan_to_num(NewImage/output)
    # #output[np.where(output==np.nan)]=0
    # pl.matshow(output)
    # pl.title('output')
    # # pl.matshow(np.abs(np.fft.fftshift(np.fft.fft2(output+np.zeros(output.shape)))))
    # 
    # 
    # weights=[]
    # for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int)):
    #    weights.append(output[x,y])
    # 
    # weightedImgFft=np.array(testimgFft)*np.array(weights)
    # 
    # MyKx=SliceKx/scalex*OS/(np.pi*4)
    # MyKy=SliceKy/scaley*OS/(np.pi*4)
    # print np.amax(MyKx)
    # print np.amin(MyKx)
    # 
    # ############################################
    # ####### This takes the unraveled matricies
    # ############################################
    # 
    # #custFft=rs.MyIfft(SliceKx/scalex*OS/(np.pi*4),SliceKy/scaley*OS/(np.pi*4),xmm,ymm,weightedImgFft)
    # # custFft=rs.MyIfft(MyKx,MyKy,xmm,ymm,testimgFft)
    # # custFft=ravel_kspace(custFft,orig_size)
    # # 
    # 
    # ############################################
    # ####### This takes the 2D NxM matricies
    # ############################################
    # Xmap=rs.ravel_kspace(SliceKx,true128.shape)
    # Ymap=rs.ravel_kspace(SliceKy,true128.shape)
    # 
    # 
    # pl.matshow(np.log(np.abs(rs.ravel_kspace(testimgFft,true128.shape))))
    # pl.title('Resampled')
    # print "THIS IS MY STUFF"
    # print MyKx
    # print MyKy
    # print X
    # print Y
    # print "K NOW"
    # print np.shape(testimgFft)
    # 
    # 
    # custFft=rs.MyIfft2(MyKx,MyKy,X,Y,testimgFft)
    # #custFft=ravel_kspace(custFft,orig_size)            
    # 
    # custFft=np.matrix(custFft).T
    # custFft=rs.norm(np.abs(custFft))#/np.amax(np.abs(custFft))
    # 
    # 
    # pl.matshow(np.abs(custFft))
    # pl.title('My Custum Fft')
    # #custFft[56,56]=1
    # 
    # #pl.matshow(np.abs(np.fft.fftshift(custFft)))
    # 
    # imgFft=rs.ravel_kspace(testimgFft,orig_size)
    # img=np.fft.fft2(imgFft)
    # img=img/(112*112)
    # img=np.rot90(np.rot90(img))
    # img=rs.norm(np.abs(img))#/np.amax(np.abs(img))
    # 
    # dsorig=np.abs(np.fft.ifft2(RefFftSamp))
    # fsize=(4,3)
    # 
    # f,ax=pl.subplots(1,1,figsize=(3,3))
    # ax.matshow(true128,cmap=gsCmap)
    # ax.set_title('Original Hi-Res')
    # ax.tick_params(labelbottom='off',bottom='off',top='off',left='off',labelleft='off',labeltop='off',labelright='off')
    # 
    # f,ax=pl.subplots(1,1,figsize=(3,3))
    # ax.matshow(np.abs(dsorig),cmap=gsCmap)
    # ax.set_title('Undistorted')
    # ax.tick_params(labelbottom='off',bottom='off',top='off',left='off',labelleft='off',labeltop='off',labelright='off')
    # 
    # 
    # f,ax=pl.subplots(1,1,figsize=(3,3))
    # true128=rs.norm(dsorig)#/np.amax(np.abs(dsorig))
    # ax.matshow(np.abs(img),cmap=gsCmap)
    # ax.set_title('Uncorrected Reconstruction')
    # ax.tick_params(labelbottom='off',bottom='off',top='off',left='off',labelleft='off',labeltop='off',labelright='off')
    # 
    # f,ax=pl.subplots(1,1,figsize=(4,3))    
    # cax=ax.matshow(np.abs(true128-np.abs(img)),vmin=-0,vmax=1,cmap=gsCmap)
    # ax.set_title('U.R. - Undistorted')
    # cbar=f.colorbar(cax,ticks=[-1,0,1])
    # ax.tick_params(labelbottom='off',bottom='off',top='off',left='off',labelleft='off',labeltop='off',labelright='off')
    # 
    # f,ax=pl.subplots(1,1,figsize=(4,3))
    # cax=ax.matshow(np.abs(true128-np.abs(custFft)),vmin=-0,vmax=1,cmap=gsCmap)
    # ax.set_title('S.C.R. - Undistorted')
    # cbar=f.colorbar(cax,ticks=[-1,0,1])
    # ax.tick_params(labelbottom='off',bottom='off',top='off',left='off',labelleft='off',labeltop='off',labelright='off')
    # 
    # 
    # 
    # f,ax=pl.subplots(1,1,figsize=(3,3))
    # ax.matshow(true128,cmap=gsCmap)
    # ax.set_title('Sample Corrected Reconstruction')
    # ax.tick_params(labelbottom='off',bottom='off',top='off',left='off',labelleft='off',labeltop='off',labelright='off')
    # 
    # #pl.close()
    # 
    # Data=[]
    # diff=np.reshape(true128-np.abs(img),-1)
    # 
    # print('maxorig:\t{}').format(np.amax(orig128[0,0]))
    # print('maxtrue:\t{}'.format(np.amax(np.abs(true128[0,0]))))
    # print('maxifft:\t{}'.format(np.amax(np.abs(img[0,0]))))
    # print('maxCust:\t{}'.format(np.amax(np.abs(custFft[0,0]))))
    # 
    # 
    # MSEuc=np.mean((np.power(diff,2)))
    # Data.append(diff)
    # UCdiff=diff
    # 
    # pl.figure()
    # #pl.plot(np.ones(len(diff)),diff,'*',label='Uncorrected')
    # 
    # diff=np.reshape(true128-np.abs(custFft),-1)
    # MSEmc=np.mean((np.power(diff,2)))
    # Data.append(diff)
    # MCdiff=diff
    # 
    # bins=np.linspace(0,.99,199)
    # sb.violinplot(data=Data)
    # pl.figure()
    # sb.distplot(np.abs(UCdiff),bins=bins,kde=False)
    # sb.distplot(np.abs(MCdiff),bins=bins,kde=False)
    # print 'Uncorrected MSE:\t{}'.format(MSEuc)
    # print 'MyCorrected MSE:\t{}'.format(MSEmc)
    # pl.show()



#def Ray_Demonstration():

#twoDfftTest()
#test_minimize()
#test_interp()
#phantom_Images()
#test_quadcopy()
#test_phantom2()
#TestOutOfPlane()
# CorrectOutOfPlane()
# sys.exit()
# 
# TestOutOfPlane()
# sys.exit()


New_Phantom_Ksamp2()
sys.exit()


New_Phantom_Ksamp()
sys.exit()

New_Possum_Ksamp()
sys.exit()

test_RawSignal()
sys.exit()



test_phantom2()
#test_phantom_MagErrors()

#TestRandom()









