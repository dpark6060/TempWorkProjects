#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb

image='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast/image_abs_idealmc.nii.gz'
mask='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast/Mask1.nii.gz'
Nskip=3
Nii=nb.load(image)
Data=Nii.get_data()
Mask=nb.load(mask).get_data()


print Data.shape
nx,ny,nz,nt=Data.shape
Lines=Data.reshape((-1,Data.shape[-1]))

CompLine=[]
Label=[]
VoxType=[]
Timepoint=range(nt-Nskip)
tsData=[]
tsCondition=[]
tsUnit=[]
tsTimepoint=[]
subject=[]

VN=0
for ix in range(nx):
    for iy in range(ny):
        for iz in range(nz):
            l=Data[ix,iy,iz,Nskip:]
            
            
            
            if Mask[ix,iy]==0:
                tempVT='Air'
            else:
                tempVT='Brain'
                
            diff=l[2]-l[3]
            
            if l[0]>l[-1]:
                tempL='SigDecrease'
            elif l[0]<l[-1]:
                tempL='SigIncrease'
            else:
                tempL='NoChange'
            
            Label.append(tempL)
            
            l=l-l[0]
            VoxType.append(tempVT)
            
            tsData.extend(l)
            tsTimepoint.extend(Timepoint)
            
            tt=np.chararray((len(l)),itemsize=len(tempL))
            tt[:]=tempL
            tsCondition.extend(tt)
            
            uu=np.chararray((len(l)),itemsize=len(tempVT))
            uu[:]=tempVT
            tsUnit.extend(uu)
            
            VoxN=np.ones(len(l))*VN
            subject.extend(VoxN)
            VN=VN+1
            
            
        
            
            
            CompLine.append(diff)

# print np.shape(CompLine)
# pl.plot(np.array(CompLine).T)
# pl.show()
# 


TS=pd.DataFrame(data={
    'TimePoint':tsTimepoint,
    'ShiftType':tsCondition,
    'VoxelType':tsUnit,
    'BOLDsignal':tsData,
    'VoxNum':subject})


#DS=pd.DataFrame(data=np.array([CompLine,Label]).T,dtype=[('SignalChange', 'f4'),('ShiftType', 'a10')])
print TS
sb.set(style='whitegrid',palette='muted')

meltTS=TS.melt(id_vars=['TimePoint','SigStart'],value_vars='BOLDsignal')
print meltTS
print 'plotting'
# sb.swarmplot(data=DS)
#ax=sb.violinplot(x="VoxelType",y="SignalChange",hue='SigStart',data=DS)
f=pl.figure()
ax11=f.add_subplot(211)
ax12=f.add_subplot(212)
# ax21=f.add_subplot(223)
# ax22=f.add_subplot(224)

sig=TS.loc[TS['VoxelType']=='Air']
sig=sig.loc[sig['ShiftType']=='SigDecrease']['BOLDsignal'].as_matrix().reshape(-1,7)
ax11.plot(sig.T-50)
ax11.set_title('AirVoxel Sig Decrease')

sig=TS.loc[TS['VoxelType']=='Air']
sig=sig.loc[sig['ShiftType']=='SigIncrease']['BOLDsignal'].as_matrix().reshape(-1,7)
ax11.plot(sig.T+50)
ax11.set_title('AirVoxel Sig Increase')

sig=TS.loc[TS['VoxelType']=='Brain']
sig=sig.loc[sig['ShiftType']=='SigDecrease']['BOLDsignal'].as_matrix().reshape(-1,7)
ax12.plot(sig.T-50)
ax12.set_title('BrainVoxel Sig Decrease')

sig=TS.loc[TS['VoxelType']=='Brain']
sig=sig.loc[sig['ShiftType']=='SigIncrease']['BOLDsignal'].as_matrix().reshape(-1,7)
ax12.plot(sig.T+50)
ax12.set_title('BrainVoxel Sig Increase')

pl.show()





















