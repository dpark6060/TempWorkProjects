#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import scipy.stats as sts
import subprocess as sp

nStart=6

def main(Rz,T,dt,TR,save):
    radZ=Rz*np.pi/180.0
    
    Npoints=int(np.ceil(T/dt+nStart))
    
    dr=radZ/(Npoints-nStart)
    
    MotMat=np.zeros((Npoints,7))
    
    for i in range(Npoints):
        if i<nStart:
            MotMat[i,0]=TR*i
        
        else:
            MotMat[i,0]=MotMat[i-1,0]+dt
            MotMat[i,6]=MotMat[i-1,6]+dr
    np.savetxt(save,MotMat)
    
if __name__ == '__main__':
    main(float(sys.argv[1]),float(sys.argv[2]),float(sys.argv[3]),float(sys.argv[4]),sys.argv[5])
    
    

