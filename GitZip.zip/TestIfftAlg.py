#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import seaborn as sb
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb



def MyIfft(Wn,n,Kn,N):
    
    x=np.zeros(len(n),complex)
    #N=len(Kn)
    for w,k in zip(Wn,Kn):
        x+=w*np.exp(1j*2*np.pi*n*k/N)
    x=x/len(Kn)
    return(x)


signal=np.zeros(100)
signal[45:55]=10


FullW=np.fft.fftshift(np.fft.fft(signal))
FullK=np.arange(len(FullW))
pl.plot(np.abs(FullW))

dsW=FullW[1::2]
dsK=FullK[1::2]

# for ii,i in enumerate(range(0,len(FullK),2)):
#     dsW[ii]=np.mean(FullW[i:i+2])


sigN=np.arange(len(signal))
ds=len(FullK)-len(dsK)
dsN=sigN[int(np.floor(ds/2.0)):int(np.ceil(len(sigN)-ds/2.0))]
# 
# dsN=sigN[::2]
print len(dsN)

NewLen=len(dsN)
print 'FullK:\t{}'.format(FullK)
print 'sigN:\t{}'.format(sigN)
print 'dsN:\t{}'.format(dsN)
print 'dsK:\t{}'.format(dsK)

#print 'k:\t{}'.format(k)

pl.figure()

PyRecon=np.fft.ifft(FullW,NewLen)

MyRecon=MyIfft(dsW,dsN,dsK,len(FullK))
pl.plot(dsN,(np.abs(MyRecon)))
pl.plot(sigN,signal)
#pl.plot(n,np.abs(PyRecon))
pl.show()
    
