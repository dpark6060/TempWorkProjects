#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import scipy.stats as sts
import subprocess as sp




def norm(sig,mean=0,span=0):
    if mean==0:
        mean=np.mean(sig)
        
    nsig=sig-mean
    
    if span==0:
        span=np.max(nsig)-np.mean(nsig)
    
    nsig=nsig/span
    
    return(nsig)

def plotFFT(sig,Fs):
    nF=len(sig)
    t=np.arange(0,nF)/Fs
    F=np.fft.fftfreq(nF,1/Fs)
    Fsig=np.fft.fft(sig)
    Fsigp=np.fft.fftshift(np.abs(Fsig))
    F=np.fft.fftshift(F)
    pl.plot(F,Fsigp,'--o')
    return(F,Fsig)

    

Fs=100.0

t=np.arange(0,40*Fs+1)/Fs

f1=np.random.rand()
f2=(np.random.rand()+10)*2
f3=(np.random.rand()+20)*3

# Sig=np.cos((t+np.random.rand(len(t))*0.1)*f1)
# Sig+=np.cos((t+np.random.rand(len(t))*0.1)*f2)
# Sig+=np.cos((t+np.random.rand(len(t))*0.1)*f3)

Sig=np.cos(t*f1)
Sig+=np.cos(t*f2)
Sig+=np.cos(t*f3)

span=np.max(Sig)-np.min(Sig)
mn=np.mean(Sig)
# pl.plot(t,Sig)
# pl.figure()

F1,Fsig1=plotFFT(Sig,Fs)
#pl.plot(F1,Fsig1)
Fsig1sh=np.fft.fftshift(Fsig1)


DownSample=4
sInds=np.arange(0,len(Sig),DownSample)
Fsigdssh=np.array([])
#print sInds
for i in sInds[:-1]:
    Fsigdssh=np.append(Fsigdssh,np.mean(Fsig1sh[i:i+DownSample]))
    
Fsigdssh=np.append(Fsigdssh,np.mean(Fsig1sh[sInds[-1]:]))


Fds=F1[sInds]
#Fsigdssh=Fsig1sh[::DownSample]
pl.plot(Fds,np.abs(Fsigdssh))


Fsigds=np.fft.fftshift(Fsigdssh)
Sigds=np.fft.ifft(Fsigds)
tds=np.arange(0,len(Sigds))/Fs
pl.figure()
pl.plot(t,norm(Sig))
pl.plot(tds+t[round(len(t)/2-len(t)/8)],norm(np.real(Sigds),mn,span))
pl.plot(tds,norm(np.real(Sigds),mn,span))


pl.show()
