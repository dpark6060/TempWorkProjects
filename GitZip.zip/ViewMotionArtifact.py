#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb

image='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast/image_abs.nii.gz'
mask='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast/MaskDiff.nii.gz'
Nskip=3
Nii=nb.load(image)
Data=Nii.get_data()
Mask=nb.load(mask).get_data()


print Data.shape
nx,ny,nz,nt=Data.shape
Lines=Data.reshape((-1,Data.shape[-1]))

CompLine=[]
Label=[]
VoxType=[]
Timepoint=range(nt-Nskip)
tsData=[]
tsCondition=[]
tsUnit=[]
tsTimepoint=[]
subject=[]

VN=0
for ix in range(nx):
    for iy in range(ny):
        for iz in range(nz):
            l=Data[ix,iy,iz,Nskip:]
            
            diff=l[2]-l[3]
            
            if l[0]>l[-1]:
                tempL='SigDecrease'
            elif l[0]<l[-1]:
                tempL='SigIncrease'
            else:
                tempL='NoChange'
            
            Label.append(tempL)
            
            if Mask[ix,iy]==-1:
                tempVT='AirToBrain'
            elif Mask[ix,iy]==1:
                tempVT='BrainToAir'
            elif Mask[ix,iy]==10:
                tempVT='BrainToBrain'
            elif Mask[ix,iy]==0:
                tempVT='AirToAir'
                
            VoxType.append(tempVT)
            
            tsData.extend(l)
            tsTimepoint.extend(Timepoint)
            
            tt=np.chararray((len(l)),itemsize=len(tempL))
            tt[:]=tempL
            tsCondition.extend(tt)
            
            uu=np.chararray((len(l)),itemsize=len(tempVT))
            uu[:]=tempVT
            tsUnit.extend(uu)
            
            VoxN=np.ones(len(l))*VN
            subject.extend(VoxN)
            VN=VN+1
            
     
            
        
            
            
            CompLine.append(diff)

# print np.shape(CompLine)
# pl.plot(np.array(CompLine).T)
# pl.show()
# 

Columns=['SignalChange','ShiftType']

DS=pd.DataFrame(
    data={'SignalChange':CompLine,
          'ShiftType':Label,
          'VoxelType':VoxType})

TS=pd.DataFrame(data={
    'TimePoint':tsTimepoint,
    'ShiftType':tsCondition,
    'VoxelType':tsUnit,
    'BOLDsignal':tsData,
    'VoxNum':subject})


#DS=pd.DataFrame(data=np.array([CompLine,Label]).T,dtype=[('SignalChange', 'f4'),('ShiftType', 'a10')])
print TS
sb.set(style='whitegrid',palette='muted')

meltTS=TS.melt(id_vars=['TimePoint','ShiftType'],value_vars='BOLDsignal')
print meltTS
print 'plotting'
# sb.swarmplot(data=DS)
ax=sb.violinplot(x="VoxelType",y="SignalChange",hue='ShiftType',data=DS)
f=pl.figure()
ax11=f.add_subplot(221)
ax12=f.add_subplot(222)
ax21=f.add_subplot(223)
ax22=f.add_subplot(224)

colorDict={'SigIncrease':sb.xkcd_rgb['medium green'],'SigDecrease':sb.xkcd_rgb['pale red']}

sb.tsplot(data=TS.loc[TS['VoxelType']=='BrainToBrain'],time='TimePoint',unit='VoxNum',condition='ShiftType',value='BOLDsignal',ci='sd',ax=ax11,color=colorDict)
ax11.set_title('Brain To Brain Voxel')
sb.tsplot(data=TS.loc[TS['VoxelType']=='BrainToAir'],time='TimePoint',unit='VoxNum',condition='ShiftType',value='BOLDsignal',ci='sd',ax=ax12,color=colorDict)
ax12.set_title('Brain To air Voxel')
sb.tsplot(data=TS.loc[TS['VoxelType']=='AirToBrain'],time='TimePoint',unit='VoxNum',condition='ShiftType',value='BOLDsignal',ci='sd',ax=ax21,color=colorDict)
ax21.set_title('air To Brain Voxel')
sb.tsplot(data=TS.loc[TS['VoxelType']=='AirToAir'],time='TimePoint',unit='VoxNum',condition='ShiftType',value='BOLDsignal',ci='sd',ax=ax22,color=colorDict)
ax22.set_title('air To air Voxel')

pl.figure()
ax=sb.tsplot(data=TS,time='TimePoint',unit='VoxNum',condition='ShiftType',value='BOLDsignal',ci='sd')
pl.figure()
ax=sb.tsplot(data=TS,time='TimePoint',unit='VoxNum',condition='VoxelType',value='BOLDsignal',ci='sd')

pl.show()

