#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import scipy.stats as sts
import subprocess as sp
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import scipy.interpolate as ipt
import Invdisttree as ivd



#baseDir='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord3'
baseDir='/share/dbp2123/dparker/Code/KSpaceMotion/Possum/Possum_10XYRot'

tmat=np.loadtxt(baseDir+'/pulse.dmat_mot')
fmat=np.loadtxt(baseDir+'/pulse.fmat_mot')
fmatRS=np.reshape(fmat,(-1,len(tmat))).T
#tmat=tmat.reshape(1,-1)


r,c=np.shape(fmatRS)


# for ic in range(c):
#     pl.figure()
#     # pl.subplot(c,1,ic+1)
#     # if ic==0:
#     #     pl.plot(Pmat[:,ic])
#     #     pl.plot(pmat2[:,ic],'o--')
#     # else:
#     #     pl.plot(Pmat[:,0],Pmat[:,ic],'*-')
#     #     pl.plot(pmat2[:,0],pmat2[:,ic],'o--')
#     # pl.legend(['Calculated Gradients','PosGradients'])
#     pl.plot(tmat,fmatRS[:,ic])
#     pl.title('Pmat Row {}'.format(ic))
#     #pl.xlim([0,.035])
# pl.show()

pl.plot(tmat,fmatRS[:,3]*np.amax(fmatRS[:,5]),label='read')
#pl.plot(tmat,fmatRS[:,10])
pl.plot(tmat,fmatRS[:,0],label='Z')
pl.plot(tmat,fmatRS[:,4],label='X')
pl.plot(tmat,fmatRS[:,5],label='Y')
pl.legend()
pl.show()
sys.exit()













MyPmat=np.loadtxt('/home/dparker/Desktop/MyNewPmat.txt')
print tmat.shape
print fmatRS.shape
print MyPmat.shape

MotMat=np.loadtxt(os.path.join(baseDir,'motion'))
print MotMat.shape

# for i in range(fmatRS.shape[-1]):
#     pl.plot(fmatRS[:,i])
#     pl.title('i={}'.format(i))
#     pl.show()

MyTime=MyPmat[:,0]
PosTime=tmat[0,:]

MyxGrad=MyPmat[:,5]
PosxGrad=fmatRS[:,4]

pl.plot(PosTime,'-.')
pl.plot(MyTime,'--o')
pl.show()


pl.plot(PosTime,PosxGrad,'-.')
pl.plot(MyTime,MyxGrad,'--o')
pl.show()

pl.plot()
















###################################################
# View My Kspace vs Possums Kspace
################################################

Myk=np.loadtxt('/home/dparker/Desktop/kMot.txt')
Posk=np.loadtxt(os.path.join(baseDir,'Kcoord_Mot_ascii'))
print Myk.shape
print Posk.shape#

# pl.plot(Posk[0])
# pl.figure()
# pl.plot(np.diff(Posk[1]))
inds=np.where(np.abs(np.diff(Posk[1]))>300)
print inds[0]
gap=112*112
for i,ii in enumerate(inds[0]):
    pl.plot(Myk[0,i*gap:ii+1]+600*i,Myk[1,i*gap:ii+1],'*-')
    pl.plot(Posk[0,i*gap:ii+1]+600*i,Posk[1,i*gap:ii+1],'o--')
i+=1
pl.plot(Myk[0,ii+1:]+600*i,Myk[1,ii+1:],'*-')
pl.plot(Posk[0,ii+1:]+600*i,Posk[1,ii+1:],'o--')

pl.show()


Myk=Myk[:,0:112*112]
Posk=Posk[:,0:112*112]

pl.plot(Myk[0],Myk[1],'*-')
pl.plot(Posk[0],Posk[1],'o--')
pl.legend(['Calculated Kspace','Possum Kspace'])
pl.show()

Nii=nb.load(os.path.join(baseDir,'image_abs.nii.gz'))
data=Nii.get_data()
hdr=Nii.get_header()
aff=Nii.get_affine()

RMX,RMY=np.meshgrid(KxRef,KyRef)


nx,ny,nz,nt=data.shape


nC=np.array([KxRef,KyRef]).T
NewData=np.zeros(data.shape)













# for i in range(nt):
# 
#     Slice=np.squeeze(data[:,:,:,i])
#     print Slice.shape
#     FftSlice=np.fft.fftshift(np.fft.fft2(Slice))
#     FftSliceImag=np.imag(FftSlice).reshape(-1)
#     FftSliceReal=np.real(FftSlice).reshape(-1)
#     #pl.matshow(np.squeeze(np.real(FftSlice)))
#     #pl.figure()
#     #pl.matshow(np.squeeze(Slice))
#     SliceKx=kx[i*nx*ny:(i+1)*nx*ny]
#     SliceKy=ky[i*nx*ny:(i+1)*nx*ny]
#     SliceMX,SliceMY=np.meshgrid(SliceKx,SliceKy)
#     C=np.array([SliceKx,SliceKy]).T
# 
#     N=len(FftSliceReal)
#     Ndim = 2
#     Nask = N  # N Nask 1e5: 24 sec 2d, 27 sec 3d on mac g4 ppc
#     Nnear = 4  # 8 2d, 11 3d => 5 % chance one-sided -- Wendel, mathoverflow.com
#     leafsize = 16
#     eps = .1  # approximate nearest, dist <= (1 + eps) * true nearest
#     p = 1  # weights ~ 1 / distance**p
#     cycle = .25
#     seed = 1
# 
# 
# #...............................................................................
#     invdisttree = ivd.Invdisttree( C, FftSliceReal, leafsize=leafsize, stat=1 )
#     fReal = invdisttree( nC, nnear=Nnear, eps=eps, p=p )   
#     
#     invdisttree = ivd.Invdisttree( C, FftSliceImag, leafsize=leafsize, stat=1 )
#     fImag = invdisttree( nC, nnear=Nnear, eps=eps, p=p )   
#     #print nz.shape
# 
#     # pl.matshow(np.reshape(nz,(nx,ny)))
#     # pl.show()
#     
#     # fReal=ipt.interp2d(SliceKx,SliceKy,np.real(FftSlice),kind='linear',bounds_error=False,fill_value=0)
#     # fImag=ipt.interp2d(SliceKx,SliceKy,np.imag(FftSlice),kind='linear',bounds_error=False,fill_value=0)
#     # 
#     NewFslice=fReal+1j*fImag
#     
#     NewFslice=np.reshape(NewFslice,(nx,ny))
#     
#     NewSlice=np.abs((np.fft.ifft2(NewFslice)))
#     NewData[:,:,0,i]=NewSlice
# 
#     # pl.figure()
#     # pl.matshow(np.abs(NewSlice))
#     # pl.show()
    
    
NewNii=nb.Nifti1Image(NewData,aff,hdr)
nb.loadsave.save(NewNii,os.path.join(baseDir,'image_abs_Reconstruct.nii.gz'))





# diff=[]
# for i in range(Myk.shape[-1]):
#     diff.append(np.sqrt((Myk[0,i]-Posk[0,i])**2+(Myk[1,i]-Posk[1,i])**2))
# 
# diff=np.array(diff).reshape(112,112)
# 
# X,Y=np.meshgrid(range(112),range(112))
# 
# fig=pl.figure()
# ax=fig.gca(projection='3d')
# surf=ax.plot_surface(X,Y,diff,cmap=cm.coolwarm,linewidth=1,antialiased=False)
# pl.show()




# np.savetxt('/home/dparker/Desktop/MyPulse.txt',Pmat)
# 
r,c=np.shape(Pmat)
print np.shape(Pmat)
pl.figure()

for ic in range(c):
    #pl.figure()
    pl.subplot(c,1,ic+1)
    if ic==0:
        pl.plot(Pmat[:,ic])
    else: 
        pl.plot(Pmat[:,0],Pmat[:,ic])
    pl.title('Pmat Row {}'.format(ic))
    #pl.xlim([0,.035])

pl.figure()
pl.subplot(3,1,1)
pl.plot(Pmat[:-1,0],gx)
pl.subplot(3,1,2)
pl.plot(Pmat[:-1,0],gy)

pl.subplot(3,1,3)
pl.plot(Pmat[:-1,0],gz)


pl.show()
tmat=np.loadtxt('/home/dparker/Desktop/MyOutput/Possum/TestImage12_NoMotion/pulse.dmat')
fmat=np.loadtxt('/home/dparker/Desktop/MyOutput/Possum/TestImage12_NoMotion/pulse.fmat')
fmatRS=np.reshape(fmat,(-1,len(tmat)))
tmat=tmat.reshape(1,-1)

pmat2=np.vstack((tmat,fmatRS))
pmat2=pmat2.T
pl.figure()

r,c=np.shape(pmat2)
print np.shape(pmat2)

for ic in range(c):
    pl.figure()
    pl.subplot(c,1,ic+1)
    if ic==0:
        pl.plot(Pmat[:,ic])
        pl.plot(pmat2[:,ic],'o--')
    else:
        pl.plot(Pmat[:,0],Pmat[:,ic],'*-')
        pl.plot(pmat2[:,0],pmat2[:,ic],'o--')
    pl.legend(['Calculated Gradients','PosGradients'])
    pl.title('Pmat Row {}'.format(ic))
    #pl.xlim([0,.035])
pl.show()


# 
# 
# #scan.set_G(Vector([.5,0,0]))
# 
# rsig,isig,Kx,Ky,ph,mx=scan.CalculateTimeSeries(Pmat)
# # print rsig
# # print isig
# # rsig=range(len(rsig))
# # isig=np.zeros(len(isig))
# # rsig[0]=rsig[-1]
# # rsig[-1]=0
# # rsig[11]=0
# # rsig[12]=100
# print len(ph)
# rsig=rsig*1e6
# isig=isig*1e6
# Sig=scan.ReshapeSig(rsig,isig)
# #Sig=np.rot90(Sig)
# pl.matshow(np.abs(Sig[:,:,0]))
# fSig2D=np.fft.fftshift(np.fft.ifft2(Sig[:,:,0]))
# 
# # # print fSig2D
# # # print np.shape(fSig2D)
# # pl.matshow((np.abs(fSig2D)))
# # pl.matshow(t[:,:,0])
# # 
# # 
# # pl.figure()
# # pl.plot(Kx,Ky)
# # pl.title('Kspace')
# # pl.figure()
# # pl.plot((rsig))
# # pl.title('realSig')
# # pl.figure()
# # pl.plot(ph)
# # pl.title('phi')
# # pl.figure()
# # pl.plot(mx)
# # pl.title('mxy')
# # pl.show()
# 
# Line1=fSig2D[5,:]
# 
# t[5,9,0]=1
# 
# tar=Target(t)
# 
# NVols=161
# t0=0
# 
# scan=Scanner(3,tar)
# Pmat=scan.CalcPulse()
# rsig,isig,Kx,Ky,ph,mx=scan.CalculateTimeSeries(Pmat)
# rsig=rsig*1e6
# isig=isig*1e6
# Sig=scan.ReshapeSig(rsig,isig)
# pl.matshow(np.abs(Sig[:,:,0]))
# fSig2D=np.fft.fftshift(np.fft.ifft2(Sig[:,:,0]))
# Line2=fSig2D[5,:]
# 
# t=np.zeros((13,13,1))
# t[5,9,0]=1
# 
# tar=Target(t)
# 
# NVols=161
# t0=0
# 
# scan=Scanner(3,tar)
# Pmat=scan.CalcPulse()
# rsig,isig,Kx,Ky,ph,mx=scan.CalculateTimeSeries(Pmat)
# rsig=rsig*1e6
# isig=isig*1e6
# Sig=scan.ReshapeSig(rsig,isig)
# pl.matshow(np.abs(Sig[:,:,0]))
# fSig2D=np.fft.fftshift(np.fft.ifft2(Sig[:,:,0]))
# Line3=fSig2D[5,:]
# 
# 
# pl.figure()
# pl.plot(Line1)
# pl.plot(Line3)
# pl.plot(Line2)
# pl.legend(['Pos1','Pos2','Pos1+2'])
# 
# pl.figure()
# pl.plot((Line1+Line3)-Line2)
# pl.title('difference')
# pl.show()
# 
# # for it,ir in zip(t,Rotate):
# #     dt=it-Told
# # 
# #     Mxy,Phi=calcMxy(scan.Target.M0[7,0,0],t0,it,scan.Target.T2s[7,0,0],scan.Target.T1[7,0,0],scan,[9,0,0],scan.Target.phi[7,0,0],dt)
# # 
# #     Sig.append(Mxy)
# #     scan.Target.Set_Mxy(Mxy,7,0,0)
# #     scan.Target.Set_phi(Phi,7,0,0)
# #     
# #     Told=it
# 
# 
# 
# 
# # pl.plot(np.real(Sig))
# # pl.figure()
# # s=np.abs(np.fft.fftshift(np.fft.fft(Sig)))
# # pl.plot(s)
# # pl.figure()
# # # newsig=np.reshape(s,(15,5))
# # # pl.imshow(newsig)
# # 
# # pl.show()
# 
# 
# 
# 
# # def calcPhase(gam,dt,G,R,T,s,Phi0=0):
# # 
# #     
# #     Phi=Phi0+gam*np.dot(G,np.dot(R,s)+T)   
# #     return(Phi)
# # 
# # 
# # def makeRotd(ax,ay,az,theta):
# #     A=[[0,-az,ay],[az,0,-ax],[-ay,ax,0]]
# #     R=np.eye(3)+np.sin(theta*np.pi/180)*np.array(A)+(1-np.cos(theta*np.pi/180))*np.dot(A,A)
# #     return R
# # 
# # def calcMxy(Mxy0,t0,t1,T2s,T1,scanner,s,Phi=0,dt=None):
# #     if dt==None:
# #         dt=t1-t0    
# #     gamma=46.6e6   #MHz/T
# #     
# #     mm=scanner.Target.cor2mil(s[0],s[1],s[2])
# # 
# #     Phi=calcPhase(gamma,dt,scanner.G,scanner.R,scanner.T,mm,Phi)
# #     Mxy=np.exp(-(t1-t0)/T2s)*np.abs(Mxy0)*np.exp(-1j*Phi)
# #     return(Mxy,Phi)
# 
# 
# 
# 
# 
#     
# 
# # d=45
# # R=makeRotd(1,0,0,d)
# # print R
# # V=np.array([0,1,0])
# # print np.dot(R,V)
