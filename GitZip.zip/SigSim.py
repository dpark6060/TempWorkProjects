#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import scipy.stats as sts
import subprocess as sp

class Vector:
    def __init__(self,v=np.zeros(3)):
        self.v=v
        
    def translate(self,T,v=np.zeros(3)):
        tv=v+T
        return(tv)
        
    def rotate(self,theta,a,v=np.zeros(3)):
        R=self.MakeRotMat(theta,a)
        rv=np.dot(v,R)
        return(rv)
    
    def xfm(self,trans,theta,a):
        tv=self.translate(trans,self.v)
        rtv=self.rotate(theta,a,tv)
        return(rtv)

    def set_v(self,newv):
        self.v=v
        
    def get_v(self):
        return self.v
    
    def MakeRotMat(self,theta,a):  
        A=[[0,-a[2],a[1]],[a[2],0,-a[0]],[-a[1],a[0],0]]        
        R=np.eye(3)+np.sin(theta*np.pi/180)*np.array(A)+(1-np.cos(theta*np.pi/180))*np.dot(A,A)
        return R



class voxel:
    def __init__(self,Mz=0,T1=0,T2s=0,Phi=0,s=Vector(np.zeros(3))):
        self.Mz=Mz
        self.T1=T1
        self.T2s=T2s
        self.Phi=Phi
        self.Mxy=0
        self.s=s
        self.Mxy0=self.Mz
    
    def set_xyz(self,s):
        self.s=s
    def set_T1(self,t1):
        self.T1=T1
    def set_T2s(self,t2):
        self.T2s=t2
    def set_Mz(self,mz):
        self.Mz=mz
    def set_Phi(self,phi):
        self.Phi=phi
    def set_Mxy(self,mxy):
        self.Mxy=mxy
    
    def get_xyz(self):
        return self.s
    def get_T1(self):
        return self.T1
    def get_T2s(self):
        return self.t2
    def get_Mz(self):
        return self.mz
    def get_Phi(self):
        return self.Phi
    def get_Mxy(self):
        return self.mxy




class Target:
    def __init__(self,tissue=np.zeros((1,1,1))):
        
        self.T1gm=1331e-3
        self.T2gm=51e-3
        self.xDim=1
        self.yDim=1
        self.zDim=1
        self.Lx=tissue.shape[0]
        self.Ly=tissue.shape[1]
        self.Lz=tissue.shape[2]
        self.Cx=np.round(self.Lx/2.0)-1
        self.Cy=np.round(self.Ly/2.0)-1
        self.Cz=np.round(self.Lz/2.0)-1
        self.xfmMat=[[self.xDim,0,0],[0,self.yDim,0],[0,0,self.zDim]]
        self.xfmT=[-1*self.Cx,-1*self.Cy,-1*self.Cz]        
        self.obj=self.MakeVoxels(tissue)

    def cor2mil(self,x,y,z):

        mm=np.dot(self.xfmMat,[x,y,z])+self.xfmT
        return(mm)
    
    def MakeVoxels(self,tissue):
        Object=np.empty(tissue.shape,dtype=object)
        
        for i,v in np.ndenumerate(tissue):
            
            s=Vector([i[0]*self.xDim,i[1]*self.yDim,i[2]*self.zDim])
            Object[i]=voxel(v,self.T1gm,self.T2gm,0,s)
            
        return Object
    
    def get_Voxel(self,xyz):
        return self.obj[xyz]
    
    


class Scanner:
    def __init__(self,B0=1,target=Target()):
        self.gamma=46.6e6   #MHz/T
        self.B0=B0
        self.Target=target
        self.G=Vector(np.zeros((3,3)))
        self.theta=0
        self.a=[0,0,0]
        self.R=self.G.MakeRotMat(self.theta,self.a)
        self.T=Vector(np.zeros(3))
        self.t0=0.0
        self.t1=self.t0
        self.t2=0.0
        self.dt=self.t2-self.t1
        
    def set_time(self,newt2):
        self.t1=self.t2
        self.t2=newt2
        self.dt=self.t2-self.t1
        
    def set_G(self,newG):
        self.G=newG
        
    def set_R(self,newR):
        self.R=newR
        
    def set_T(self,newT):
        self.T=newT
        
    def get_time(self):
        return(t2)
        
    def CalcPhase(self,V=voxel()):
        dot=np.dot(self.G.get_v(),V.s.xfm(self.T.v,self.theta,self.a))
        # print dot
        # print type(dot)
        dPhi=self.gamma*dot*self.dt        
        Phi=V.get_Phi()+dPhi
        return(Phi)
    
    def calcMxy(self,V=voxel()):    

        Phi=self.CalcPhase(V)
        Mxy=np.exp(-(self.t1-self.t0)/self.Target.T2gm)*np.abs(V.Mxy0)*np.exp(-1j*Phi)
        return(Mxy,Phi)
    
    def CalculateVolume(self):
        Sig=[]
        for i,V in np.ndenumerate(self.Target.obj):
            Mxy,Phi=self.calcMxy(V)
            Sig.append(Mxy)
            self.Target.obj[i].set_Phi(Phi)
            self.Target.obj[i].set_Mxy(Mxy)
        return(Sig)
    
    def CalculateVolume_R(self):
        Sig=[]
        for i,V in np.ndenumerate(self.Target.obj):
            Mxy,Phi=self.calcMxy(V)
            Sig.append(Mxy)
            self.Target.obj[i].set_Phi(Phi)
            self.Target.obj[i].set_Mxy(Mxy)
        return(Sig)
    
    
    def CalculateTimeSeries(self,TimeSeries,Rotate=None,Translate=None):
        
        if Rotate==None and Translate==None:
        
            Sig=[]
            Kx=[]
            Ky=[]
            
            for it in TimeSeries:
                self.set_time(it)
                val=self.CalculateVolume()
                Sig.append(np.sum(val))
            return(Sig)
        
        elif Rotate==None:
            print ('Translation only Code')
            return []
        
        elif Translate==None:
            print('Rotation Only Code')
            return []
        
        else:
            print('rotation and translation code')
            return []
        

        



t=np.zeros((15,5,1))
t[8,2,0]=1
t[6,2,0]=2
tar=Target(t)

NVols=64*64
t=np.linspace(0,2,15*5)
t0=0

scan=Scanner(3,tar)
scan.set_G(Vector([.5,0,0]))

Sig=scan.CalculateTimeSeries(t)





# for it,ir in zip(t,Rotate):
#     dt=it-Told
# 
#     Mxy,Phi=calcMxy(scan.Target.M0[7,0,0],t0,it,scan.Target.T2s[7,0,0],scan.Target.T1[7,0,0],scan,[9,0,0],scan.Target.phi[7,0,0],dt)
# 
#     Sig.append(Mxy)
#     scan.Target.Set_Mxy(Mxy,7,0,0)
#     scan.Target.Set_phi(Phi,7,0,0)
#     
#     Told=it




pl.plot(np.real(Sig))
pl.figure()
s=np.abs(np.fft.fftshift(np.fft.fft(Sig)))
pl.plot(s)
pl.figure()
# newsig=np.reshape(s,(15,5))
# pl.imshow(newsig)

pl.show()




# def calcPhase(gam,dt,G,R,T,s,Phi0=0):
# 
#     
#     Phi=Phi0+gam*np.dot(G,np.dot(R,s)+T)   
#     return(Phi)
# 
# 
# def makeRotd(ax,ay,az,theta):
#     A=[[0,-az,ay],[az,0,-ax],[-ay,ax,0]]
#     R=np.eye(3)+np.sin(theta*np.pi/180)*np.array(A)+(1-np.cos(theta*np.pi/180))*np.dot(A,A)
#     return R
# 
# def calcMxy(Mxy0,t0,t1,T2s,T1,scanner,s,Phi=0,dt=None):
#     if dt==None:
#         dt=t1-t0    
#     gamma=46.6e6   #MHz/T
#     
#     mm=scanner.Target.cor2mil(s[0],s[1],s[2])
# 
#     Phi=calcPhase(gamma,dt,scanner.G,scanner.R,scanner.T,mm,Phi)
#     Mxy=np.exp(-(t1-t0)/T2s)*np.abs(Mxy0)*np.exp(-1j*Phi)
#     return(Mxy,Phi)





    

# d=45
# R=makeRotd(1,0,0,d)
# print R
# V=np.array([0,1,0])
# print np.dot(R,V)
