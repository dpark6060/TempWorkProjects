#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import seaborn as sb
import scipy.stats as sts
import subprocess as sp
import scipy.ndimage as ndi




def phantom (matrix_size = 256, phantom_type = 'Modified Shepp-Logan', ellipses = None):
    """
    Create a Shepp-Logan or modified Shepp-Logan phantom::
        phantom (n = 256, phantom_type = 'Modified Shepp-Logan', ellipses = None)
    :param matrix_size: size of imaging matrix in pixels (default 256)
    :param phantom_type: The type of phantom to produce.
        Either "Modified Shepp-Logan" or "Shepp-Logan". This is overridden
        if ``ellipses`` is also specified.
    :param ellipses: Custom set of ellipses to use.  These should be in
        the form::
            [[I, a, b, x0, y0, phi],
            [I, a, b, x0, y0, phi],
                            ...]
        where each row defines an ellipse.
        :I: Additive intensity of the ellipse.
        :a: Length of the major axis.
        :b: Length of the minor axis.
        :x0: Horizontal offset of the centre of the ellipse.
        :y0: Vertical offset of the centre of the ellipse.
        :phi: Counterclockwise rotation of the ellipse in degrees,
            measured as the angle between the horizontal axis and
            the ellipse major axis.
    The image bounding box in the algorithm is ``[-1, -1], [1, 1]``,
    so the values of ``a``, ``b``, ``x0``, ``y0`` should all be specified with
    respect to this box.
    :returns: Phantom image
    References:
    Shepp, L. A.; Logan, B. F.; Reconstructing Interior Head Tissue
    from X-Ray Transmissions, IEEE Transactions on Nuclear Science,
    Feb. 1974, p. 232.
    Toft, P.; "The Radon Transform - Theory and Implementation",
    Ph.D. thesis, Department of Mathematical Modelling, Technical
    University of Denmark, June 1996.
    """

    if (ellipses is None):
        ellipses = _select_phantom (phantom_type)
    elif (np.size (ellipses, 1) != 6):
        raise AssertionError ("Wrong number of columns in user phantom")

    ph = np.zeros ((matrix_size, matrix_size),dtype=np.float32)

    # Create the pixel grid
    ygrid, xgrid = np.mgrid[-1:1:(1j*matrix_size), -1:1:(1j*matrix_size)]

    for ellip in ellipses:
        I   = ellip [0]
        a2  = ellip [1]**2
        b2  = ellip [2]**2
        x0  = ellip [3]
        y0  = ellip [4]
        phi = ellip [5] * np.pi / 180  # Rotation angle in radians

        # Create the offset x and y values for the grid
        x = xgrid - x0
        y = ygrid - y0

        cos_p = np.cos (phi)
        sin_p = np.sin (phi)

        # Find the pixels within the ellipse
        locs = (((x * cos_p + y * sin_p)**2) / a2
        + ((y * cos_p - x * sin_p)**2) / b2) <= 1

        # Add the ellipse intensity to those pixels
        ph [locs] += I

    return ph

def _select_phantom (name):
    if (name.lower () == 'shepp-logan'):
        e = _shepp_logan ()
    elif (name.lower () == 'modified shepp-logan'):
        e = _mod_shepp_logan ()
    else:
        raise ValueError ("Unknown phantom type: %s" % name)
    return e

def _shepp_logan ():
    #  Standard head phantom, taken from Shepp & Logan
    return [[   2,   .69,   .92,    0,      0,   0],
            [-.98, .6624, .8740,    0, -.0184,   0],
            [-.02, .1100, .3100,  .22,      0, -18],
            [-.02, .1600, .4100, -.22,      0,  18],
            [ .01, .2100, .2500,    0,    .35,   0],
            [ .01, .0460, .0460,    0,     .1,   0],
            [ .02, .0460, .0460,    0,    -.1,   0],
            [ .01, .0460, .0230, -.08,  -.605,   0],
            [ .01, .0230, .0230,    0,  -.606,   0],
            [ .01, .0230, .0460,  .06,  -.605,   0]]

def _mod_shepp_logan ():
    #  Modified version of Shepp & Logan's head phantom,
    #  adjusted to improve contrast.  Taken from Toft.
    return [[   1,   .69,   .92,    0,      0,   0],
            [-.80, .6624, .8740,    0, -.0184,   0],
            [-.20, .1100, .3100,  .22,      0, -18],
            [-.20, .1600, .4100, -.22,      0,  18],
            [ .10, .2100, .2500,    0,    .35,   0],
            [ .10, .0460, .0460,    0,     .1,   0],
            [ .10, .0460, .0460,    0,    -.1,   0],
            [ .10, .0460, .0230, -.08,  -.605,   0],
            [ .10, .0230, .0230,    0,  -.606,   0],
            [ .10, .0230, .0460,  .06,  -.605,   0]]



def unravel_kspace(imageF,origin='upper'):
    
    if origin=='lower':
        imageF=np.rot90(imageF,k=-1)
    
    newarr=[]
    Lx,Ly=np.shape(imageF)
    ix=0
    iy=0
    xinc=1
    yinc=1
    
    
    for y in range(Ly):
        
        for x in range(Lx):
            newarr.append(imageF[ix,iy])
            ix+=xinc
        xinc*=-1
        ix+=xinc
        iy+=yinc
    return newarr
    


def ravel_kspace(image,shape,origin='upper'):

    NewImg=np.zeros(shape)
    Ly=shape[0]
    Lx=shape[1]
    
    xinc=1
    yinc=1
    
    imageCounter=0
    iy=0
    ix=0
        
    for y in range(Ly):
        
        for x in range(Lx):
            NewImg[ix,iy]=image[imageCounter]
            ix+=xinc
            imageCounter+=1
        xinc*=-1
        ix+=xinc
        iy+=yinc
    
    if origin=='lower':
        NewImg=np.rot90(NewImg,k=1)
    
    return(NewImg)
    
    
    # newImg=np.zeros(shape,dtype=complex)
    # 
    # incx=np.sign(np.diff(idx)).astype(int)
    # incy=np.sign(np.diff(idy)).astype(int)
    # 
    # newImg[0,0]=image[0]
    # x=0
    # y=0
    # i=0
    # for ix,iy in zip(incx,incy):
    #    i+=1
    #    x+=ix
    #    y+=iy
    #    newImg[x,y]=image[i]
    #    
    # return(newImg)


def create_kspace(Nx,Ny,dx=1,dy=1,angle=[0],sample_zero=False):
    
    Nk=Nx*Ny
    
    if len(angle)==1 and angle[0]!=0:
        angle=np.linspace(0,angle[0],Nk)
    elif len(angle)==1 and angle[0]==0:
        angle=np.zeros(Nk)
    elif len(angle)<Nk:
        NewAngle=np.zeros(Nk)
        NewAngle[0:len(angle)]=angle
        NewAngle[len(angle):]=angle[-1]
        angle=NewAngle
        
    
    
    
    Kx=[]
    Ky=[]
    
    xStart=-1*int(np.floor(Nx/2))
    yStart=-1*int(np.floor(Ny/2))
    
    if not sample_zero:
        if np.mod(Nx,2)==0:
            xStart+=0.5
            yStart+=0.5
    

    
       
    ik=0
    rx=xStart
    ry=yStart
    xdir=1
    
    for iy in range(Ny):
        
        for ix in range(Nx):
            
            xx=rx*np.cos(angle[ik]*np.pi/180)-ry*np.sin(angle[ik]*np.pi/180)
            yy=rx*np.sin(angle[ik]*np.pi/180)+ry*np.cos(angle[ik]*np.pi/180)
            
            Kx.append(xx)
            Ky.append(yy)
            
            ik+=1
            rx+=xdir
            
        xdir*=-1
        rx+=xdir        
        ry+=1

    return(np.array(Kx)*dx,np.array(Ky)*dy)


def upsample_fft(image,UF):
    imx,imy=np.shape(image)
    US_image=np.fft.fft2(image,s=(imx*UF,imy*UF))
    return(US_image)


def resample_fft(imageF,shape,idx,idy):
    
    tracex,tracey=create_kspace(shape[0],shape[1],sample_zero=False)
    tracex-=np.min(tracex)
    tracey-=np.min(tracey)
    
    # pl.plot(tracex,tracey,'o-*')
    # pl.show()
    newimage=np.zeros(shape)+1j*np.zeros(shape)
    
    for kx,ky,ix,iy in zip(idx.astype(int),idy.astype(int),tracex.astype(int),tracey.astype(int)):
        newimage[ix,iy]=imageF[kx,ky]
    
    return(newimage)

def simulate_kspace_sampling(HR_image,orig_size,origkx,origky,refkx,refky):
    HR_size=np.shape(HR_image)
    UpFactor=10
    
    HRpadx=(HR_size[0]-orig_size[0])/2.0
    HRpady=(HR_size[1]-orig_size[1])/2.0
    

    # pl.plot(refkx,refky,'r-*')
    # pl.plot(origkx,origky,'g-o',markersize=3)
    # pl.show()
    # 
    
    origkx+=np.abs(np.amin(refkx))+HRpadx
    origky+=np.abs(np.amin(refky))+HRpady
    
    origkx=np.round(origkx).astype(int)
    origky=np.round(origky).astype(int)

    pl.plot(origkx,origky)
 
    
    US_imageF=upsample_fft(HR_image,UpFactor)
    
    #pl.matshow(np.abs(US_imageF))    
    # pl.matshow(np.abs(np.fft.ifft2(US_imageF)))
    #pl.show()
    # 
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.plot(refkx,refky,'-o')
    # pl.plot(origkx,origky,'-*')
    # 
    # pl.show()
    #
    newimage=np.zeros(US_imageF.shape)
    
    # for ix,iy in zip(origkx,origky):
    #     newimage[ix,iy]=100+iy*10
    # # 
    # pl.matshow(newimage)
    # pl.matshow(np.abs(np.fft.fftshift(US_imageF)))
    # pl.show()
    
    
    newfft=resample_fft(US_imageF,orig_size,origkx,origky)
    pl.matshow(np.log(np.abs(newfft)))
    pl.matshow(np.abs(np.fft.fftshift(np.fft.fft2(newfft))))
    pl.show()
    return(newfft)




def K2Ind(refx,refy,shape,kx,ky):
    # assuming ref is a grid
    
    
    UpFactor=10
    nx,ny=shape
    
    minKx=np.amin(refx)
    minKy=np.amin(refy)
    
    irx=refx-minKx
    iry=refy-minKy
    
    maxKx=np.amax(irx)
    maxKy=np.amax(iry)
    
    irx=irx/maxKx
    iry=iry/maxKy
    
    irx=(np.round(irx*(nx-1)*UpFactor)).astype(int)
    iry=(np.round(iry*(ny-1)*UpFactor)).astype(int)
    
  

    kx=kx-minKx
    ky=ky-minKy
    kx=kx/maxKx
    ky=ky/maxKy
    
    ikx=np.round((kx*(nx-1)*UpFactor)).astype(int)
    iky=np.round((ky*(nx-1)*UpFactor)).astype(int)
    
    
    newxrange=np.amax(ikx)-np.amin(ikx)+UpFactor
    newyrange=np.amax(iky)-np.amin(iky)+UpFactor
    
    NewShape=(newxrange,newyrange)
    newkxi=ikx-np.amin(ikx)+np.round(UpFactor/2).astype(int)
    newkyi=iky-np.amin(iky)+np.round(UpFactor/2).astype(int)
        
    
    oldix=irx/UpFactor
    oldiy=iry/UpFactor
    #NewImage=np.zeros(NewShape)
    # 
    # for x,y in zip(newkxi,newkyi):
    #     
    #     NewImage[x,y]=1
    # pl.matshow(NewImage)
    # pl.show()
    # 
    # 
       

    return(oldix,oldiy,newkxi,newkyi,NewShape,UpFactor)


def K2Ind_dev(refx,refy,shape,kx,ky,m):
    # assuming ref is a grid
    
    print shape
    UpFactor=11
    nx,ny=shape
    
    minKx=np.amin(refx)
    minKy=np.amin(refy)
    
    irx=refx-minKx
    iry=refy-minKy
    
    maxKx=np.amax(irx)
    maxKy=np.amax(iry)
    
    irx=irx/maxKx
    iry=iry/maxKy
    
    irangex=(0,2*UpFactor)
    irangey=(0,2*UpFactor)
    
    irx=(np.round(irx*(nx-1)*UpFactor)).astype(int)
    iry=(np.round(iry*(ny-1)*UpFactor)).astype(int)
    
    

    # kx=kx-minKx
    # ky=ky-minKy
    
    # kx=kx-minKx
    # ky=ky-minKy
    
    kx=kx-kx[0]
    ky=ky-ky[0]
    
    # ikx-=ikx[0]
    # iky-=iky[0]
    
    kx=kx/maxKx
    ky=ky/maxKy
    
    print np.amax(kx)
    print np.amax(ky)
    
    
    # ikx=np.round((kx*(nx-1)*UpFactor)).astype(int)
    # iky=np.round((ky*(nx-1)*UpFactor)).astype(int)
    # ikx=kx*(nx-1)
    # iky=ky*(nx-1)
    
    ikx=np.round((kx*(nx-1)*UpFactor)).astype(int)
    iky=np.round((ky*(nx-1)*UpFactor)).astype(int)
    dkx=0
    dky=0
    if np.amin(ikx)<0:
        dkx=np.amin(dkx)
        ikx-=np.amin(ikx)
    if np.amin(iky)<0:
        dky=np.amin(dky)
        iky-=np.amin(iky)
    
    
    newxrange=np.amax(ikx)-np.amin(ikx)+UpFactor
    newyrange=np.amax(iky)-np.amin(iky)+UpFactor
    
    NewShape=(newxrange+2*dkx,newyrange+2*dky)

    newkxi=ikx#-np.amin(ikx)+np.round(UpFactor/2).astype(int)
    newkyi=iky#-np.amin(iky)+np.round(UpFactor/2).astype(int)
    
    oldix=irx/UpFactor
    oldiy=iry/UpFactor
    # 
    # #NewShape=(nx*UpFactor,ny*UpFactor)
    # 
    # newkxi=[]
    # newkyi=[]
    # newix=[]
    # newiy=[]
    # for x,y,rx,ry in zip(ikx,iky,oldix,oldiy):
    #     if x>=0 and x<NewShape[0] and y>=0 and y<NewShape[1]:
    #         newkxi.append(x)
    #         newkyi.append(y)
    #         newix.append(rx)
    #         newiy.append(ry)
    #     
    # 
    # 
    
    
    
    # HRpadx=(HR_size[0]-orig_size[0])/2.0
    # HRpady=(HR_size[1]-orig_size[1])/2.0
    # 
    

    
    # oldix=newix
    # oldiy=newiy
    
    NewImage=np.zeros(NewShape)
    
    
    
    for x,y in zip(newkxi,newkyi):
        
        NewImage[x,y]=1
        #NewImage[rx,ry]=2
    pl.matshow(NewImage)
    pl.show()
    
    output=ndi.filters.gaussian_filter(NewImage,sigma=m*(UpFactor),mode='constant',cval=0)
    output=output*(11*11)
    output=np.nan_to_num(NewImage/output)
    #output[np.where(output==np.nan)]=0
    # pl.matshow(output)
    # pl.matshow(np.abs(np.fft.fftshift(np.fft.fft2(output+np.zeros(output.shape)))))
    # pl.show()
    weights=[]
    for x,y in zip(newkxi,newkyi):
       weights.append(output[x,y])
       

    return(oldix,oldiy,newkxi,newkyi,NewShape,UpFactor,weights)








def CreateSamplingFunction2(kxgrid,kygrid,size):
    FftSamp=np.zeros((int(size),int(size)))
    xinds=[]
    yinds=[]
    for kx,ky in zip(kxgrid,kygrid):
        if (kx >=0 and ky >=0) and (kx<size and ky<size):
            FftSamp[kx,ky]=1
            xinds.append(kx)
            yinds.append(ky)
        else:
            xinds.append(-1)
            yinds.append(-1)
            
            

    return(FftSamp,xinds,yinds)


def simulate_kspace_sampling2(HR_Fft,orig_size,kx,ky,ikx,iky):
   
    
    
    newfft=zero_resample_fft(np.fft.fftshift(US_imageF),kx,ky,ikx,iky)
    # pl.matshow(np.abs(newfft))
    # pl.show()
    # 
    
    
    return(newfft,origkx,origky,refkx,refky)

def zero_resample_fft(imageF,newSize,kx,ky,idx,idy):
    

    # pl.plot(tracex,tracey,'o-*')
    # pl.show()
    newimage=np.zeros((newSize,newSize))+1j*np.zeros(newSize,newSize)
    
    for x,y,ix,iy in zip(kx.astype(int),ky.astype(int),idx.astype(int),idu.astype(int)):
        newimage[x,y]=imageF[ix,iy]
    pl.matshow(np.abs(newimage))
    pl.show()
    return(newimage)



def kspaceTime(rx,ry,dtx,dt,shape):
    time=np.zeros(shape)
    
    py=0
    t=0
    
    for x,y in zip(rx[1:],ry[1:]):
        
        if np.abs(y-py)>0:
            t+=2*dt
        else:
            t+=dtx
        time[x,y]=t
        py=y
    
    return(time)
            
            


#def calcWeightFunc(kx,ky):
    




# inds=range(100)
# img=ravel_kspace(inds,(10,10),origin='lower')
# pl.matshow(img)
# inds2=unravel_kspace(img,origin='lower')
# print inds2
# pl.figure()
# pl.plot(inds)
# pl.plot(inds2)
# pl.show()
# quit


baseDir='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord'
Myk=np.loadtxt('/home/dparker/Desktop/kMot.txt')
Posk=np.loadtxt(os.path.join(baseDir,'Kcoord_Mot_ascii'))
print Myk.shape
print Posk.shape#


MagNii='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord/image_abs.nii.gz'
PhaseNii='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord/image_phase.nii.gz'


mag=nb.load(MagNii).get_data()
phase=nb.load(PhaseNii).get_data()



# pl.plot(Posk[0])
# pl.figure()
# pl.plot(np.diff(Posk[1]))
inds=np.where(np.abs(np.diff(Posk[1]))>300)
print inds[0]
gap=112*112

refKx=Posk[0,inds[0][0]+1:inds[0][0]+112*112+1]
refKy=Posk[1,inds[0][0]+1:inds[0][0]+112*112+1]
    
minKx=np.amin(refKx)
minKy=np.amin(refKy)

ikx=refKx-minKx
iky=refKy-minKy

maxKx=np.amax(ikx)
maxKy=np.amax(iky)

ikx=ikx/maxKx
iky=iky/maxKy

UpScale=20

ikx=np.round(ikx*112).astype(int)
iky=np.round(iky*112).astype(int)

dt=4.19379e-05
dtx=1e-05
T2s=50e-3

for i,ii in enumerate(inds[0]):
    if i>=4 and i<=6:
        
        m=mag[:,:,0,i]
        p=phase[:,:,0,i]
        # m=np.rot90(m,k=1,axes=(1,0))
        # p=np.rot90(p,k=1,axes=(1,0))
        
        pl.matshow(m,origin='lower')
        pl.plot(refKx,refKy)
        pl.show()
        
        cpx=m*np.cos(p)+1j*m*np.sin(p)
        Fcpx=np.fft.fftshift(np.fft.fft2(cpx))
        
        pl.matshow(np.log(np.abs(Fcpx)))
        pl.show()
        
        SliceKx=Posk[0,i*gap:ii+1]
        SliceKy=Posk[1,i*gap:ii+1]
        
        Xmap=ravel_kspace(SliceKx,m.shape)
        Ymap=ravel_kspace(SliceKy,m.shape)
        
        
        X1=np.diff(Xmap,axis=0)
        Y1=np.diff(Xmap,axis=1)
        
        X2=np.diff(Ymap,axis=0)
        Y2=np.diff(Ymap,axis=1)
        
        m1=np.amax(np.sqrt(np.square(X1[:,1:])+np.square(Y1[1:,:])))
        m2=np.amax(np.sqrt(np.square(X2[:,1:])+np.square(Y2[1:,:])))
        
        mx=np.amax((m1,m2))
        npx=mx*m.shape[0]/(np.amax(SliceKx)-np.amin(SliceKx))
        print npx
        
        
        
        
        
        
        
        
        
        
        
        pl.matshow(m,origin='lower')
        pl.plot(SliceKx,SliceKy)
        pl.show()
        iix,iiy,nkx,nky,shape,UF,weights=K2Ind_dev(refKx,refKy,(112,112),SliceKx,SliceKy,npx)
        #sys.exit()
        # time=kspaceTime(iix,iiy,dtx,dt,(112,112))
        # kdecay=np.exp(-1*time/T2s)
        # space=np.fft.fftshift(np.fft.ifft2(kdecay))
        # pl.matshow(np.abs(space))
        # pl.matshow(kdecay);
        # pl.show()
        
        # pl.matshow(np.log(np.abs(Fcpx)))
        # pl.title('original')
        # Fcpx2=Fcpx/kdecay
        # pl.matshow(np.log(np.abs(Fcpx2)))
        # pl.title('decay corrected')
        # 
        # im2=np.fft.fft2(Fcpx2)
        # pl.matshow(np.abs(im2))
        # pl.title('new')
        # pl.matshow(m)
        # pl.title('old')
        
        # testimage=phantom(112)
        # testFFt=np.fft.fftshift(np.fft.fft2(testimage,s=shape))
        # 
        # NewFFT=np.zeros((112,112),dtype=complex)
        # 
        # for rx,ry,nx,ny in zip(iix,iiy,nkx,nky):
        #     NewFFT[rx,ry]=testFFt[nx,ny]
        # 
        # pl.matshow(np.log(np.abs(NewFFT)))
        # pl.matshow(np.log(np.abs(testFFt)))
        # NewImg=np.fft.ifft2(NewFFT)
        # pl.matshow(np.abs(NewImg))
        # pl.show()
        
        
        ##################################################
        shape=(112,112)
        NewFft=np.zeros(shape)+1j*np.zeros(shape)
        for rx,ry,nx,ny,w in zip(iix,iiy,nkx,nky,weights):
            #NewFft[nx,ny]=NewFFT[rx,ry]
            #NewFft[nx,ny]=Fcpx[rx,ry]*w
            NewFft[rx,ry]=Fcpx[rx,ry]*w

            #print '{} {}'.format(rx,ry)
        pl.matshow(np.abs(NewFft))
        NewImg=np.fft.ifft2(NewFft)
        pl.matshow(np.abs(NewImg))
        pl.matshow(m)
        pl.show()
        #pl.matshow(m)
        pl.show()
        
        
        ###################################################
        
        
        
        # # sxmin=np.amin(SliceKx)
        # # sxmax=np.amax(SliceKx)
        # # symin=np.amin(SliceKy)
        # # symax=np.amax(SliceKy)
        # # 
        # # Xrange=sxmax-sxmin
        # # Yrange=symax-symin        
        # 
        # sliceix=SliceKx-minKx
        # sliceiy=SliceKy-minKy
        # sliceix/=maxKx
        # sliceiy/=maxKy
        # 
        # 
        # maxx=np.amax([np.amax(sliceix),np.amax(ikx)])
        # maxy=np.amax([np.amax(sliceiy),np.amax(iky)])
        # 
        # minx=np.amin([np.amin(sliceix),np.amin(ikx)])
        # miny=np.amin([np.amin(sliceiy),np.amin(iky)])
        # 
        # 
        # Xrange=maxx-minx
        # Yrange=maxy-miny
        # XupScale=np.ceil(Xrange*UpScale).astype(int)
        # YupScale=np.ceil(Yrange*UpScale).astype(int)
        # 
        # print 'maxx:\t{}'.format(maxx)
        # print 'maxy:\t{}'.format(maxy)
        # print 'minx:\t{}'.format(minx)
        # print 'miny:\t{}'.format(miny)
        # print 'Xrange:\t{}'.format(Xrange)
        # print 'Yrange:\t{}'.format(Yrange)
        # print 'XupScale:\t{}'.format(XupScale)
        # print 'YupScale:\t{}'.format(YupScale)
        # newsize=np.amax([XupScale,YupScale])
        # 
        # 
        # sliceix=np.round(sliceix*UpScale).astype(int)
        # sliceiy=np.round(sliceiy*UpScale).astype(int)
        # 
        # phSize=224
        # orig_size=(112,112)
        # image=phantom(matrix_size=phSize)
        # true128=phantom(112)
        # pl.plot(sliceix,sliceiy,'-o')
        # pl.show()
        # 
        # 
        # SampledImage=simulate_kspace_sampling(image,orig_size,SliceKx,SliceKy,refKx,refKy)
        
        
        # newF=zero_resample_fft(SampledImage,newsize,sliceix,sliceiy,ikx,iky)
        # newimage=np.fft.fftshift(np.fft.ifft2(newF))
        # pl.matshow(np.abs(newimage))
        # pl.show()
        # # 
        # # 
        # newfft=zero_resample_fft(Fcpx,kx,ky,ikx,iky)
        # 
        # FftSamp,xinds,yinds=CreateSamplingFunction2(origkx2,origky2,size,m)
        # 
        # 
        # 



        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
 