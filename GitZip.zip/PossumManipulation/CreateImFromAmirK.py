#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import seaborn as sb
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb
sys.path.append('/share/dbp2123/dparker/Code/KSpaceMotion/Code/Python')
import FreqDomainResampSupport as rs
import scipy.ndimage as ndi

def norm(data):
    data=data-np.min(data)
    data=data/np.amax(np.abs(data))
    return(data)







def LoadKspaceDat(filename,Nx,Ny,Nz,Nt):
    
    k_bin=np.fromfile(filename,dtype='float64')
    kspace_4D=np.reshape(k_bin,(Nz,Nt,Nx*Ny,2))
    kspace_4D=np.swapaxes(kspace_4D,0,2)
    kspace_4D=np.swapaxes(kspace_4D,1,2)
    print kspace_4D.shape
    
    # pl.plot(kspace_4D[:,0,6,0],kspace_4D[:,0,6,1])
    # pl.show()
    
    
    
    
    
    return(kspace_4D)
    #MyKx=np.zeros((Nx,Ny,Nz,Nt))
    #MyKy=np.zeros((Nx,Ny,Nz,Nt))



WrkDir='/share/users/dparker2/Amir/kspace_rot_full/10deg'
#WrkDir='/share/dbp2123/dparker/Code/KSpaceMotion/Possum/TestImage12_5mmZrot_DavidBuild'






imname='simulator_output_image.nii'
ImageFile=os.path.join(WrkDir,imname)
Image=nb.load(ImageFile).get_data()
Nx,Ny,Nz,Nt=Image.shape


MCimage=os.path.join(WrkDir,'MC_image_abs.nii.gz')
if not os.path.exists(MCimage):
    cmd='mcflirt -in {} -refvol 3 -2d -out {} -stats -mats -plots'.format(ImageFile,MCimage)
    pr=sp.Popen(cmd,shell=True)
    pr.wait()
    
MCimage=nb.load(MCimage).get_data()


KimagFile=os.path.join(WrkDir,'simulator_signal_space_imag.nii')
KrealFile=os.path.join(WrkDir,'simulator_signal_space_real.nii')
Kimag=nb.load(KimagFile).get_data()
Kreal=nb.load(KrealFile).get_data()


# MCimage=os.path.join(WrkDir,'MC_image_abs.nii.gz')
# MCimage=nb.load(MCimage).get_data()

K=np.zeros(Kreal.shape,complex)
K=Kreal+1j*Kimag
print K.shape





AmirKfile=os.path.join(WrkDir,'k_space.dat')
MyKxy=LoadKspaceDat(AmirKfile,Nx,Ny,Nz,Nt)

# KxFile=os.path.join(WrkDir,'Kcoord_mot_bin_kx.nii.gz')
# KyFile=os.path.join(WrkDir,'Kcoord_mot_bin_ky.nii.gz')
# 
# Kx=nb.load(KxFile).get_data()
# Ky=nb.load(KyFile).get_data()


# pl.matshow(Kx[:,:,0,1])
# pl.matshow(Ky[:,:,0,1])
# pl.matshow(Kx[:,:,0,1]-Ky[:,:,0,1])
# pl.show()

x,y,z,t=np.shape(Image)

OS=x
# xax=np.arange(OS)
# yax=np.arange(OS)
#     
# # xax=xax/OS*2*np.pi+np.pi
# # yax=yax/OS*2*np.pi+np.pi
# 
# Y,X=np.meshgrid(xax,yax)

# pl.plot(unravel_kspace(X),unravel_kspace(Y))
# 
# pl.show()
# pl.matshow(X)
# pl.title('xax X')
# pl.matshow(Y)
# pl.title('yax Y')


refx=MyKxy[:,0,3,0]
refy=MyKxy[:,0,3,1]

rxspan=np.amax(refx)-np.amin(refx)
ryspan=np.amax(refy)-np.amin(refy)

rxmin=np.amin(refx)
rymin=np.amin(refy)

# print type(refx)
# print refx.dtype
# print refx.shape

refx=np.real(rs.ravel_kspace(refx,(x,y)))
refy=np.real(rs.ravel_kspace(refy,(x,y)))
# print refx.shape
# print type(refx)
# print refx.dtype

# pl.matshow(refx)
# pl.matshow(refy)
# pl.show()

scalex=((np.amax(refx)-np.amin(refx)))/2
#Kx=Kx/scalex#*(np.pi/dx)
# 
scaley=((np.amax(refy)-np.amin(refy)))/2
#Ky=Ky/scaley#*(np.pi/dy)

xintercept=refx[0,0]
yintercept=refy[0,0]

orig_size=(OS,OS)

xm,xi,ym,yi=rs.mapk2ind(refx,refy,orig_size,orig_size,1)



MyPi=np.pi


# xax=np.arange(OS)-OS/2.0
# yax=np.arange(OS)-OS/2.0
xstepdown=2
ystepdown=2
xoffset=-1
yoffset=-1
xax=np.linspace(0,OS-xstepdown,OS)-(OS-xstepdown)/2.0+xoffset
yax=np.linspace(0,OS-ystepdown,OS)-(OS-ystepdown)/2.0+yoffset

xax=xax/(OS)*2*MyPi
yax=yax/(OS)*2*MyPi

# xax=np.fft.fftfreq(OS)*2*MyPi
# yax=np.fft.fftfreq(OS)*2*MyPi


# xax=np.fft.fftshift(xax)
# yax=np.fft.fftshift(yax)

dx=np.mean(np.diff(xax))
dy=np.mean(np.diff(yax))

# xax*=xdim
# yax*=ydim
print dx
print dy

X,Y=np.meshgrid(xax+dx/2,yax+dy/2)


# pl.matshow(np.log(np.abs(HrImgFft)),origin='lower')
# pl.title('HR FFt')
# pl.matshow(np.log(np.abs(ZpHrImgFft)),origin='lower')
# pl.title('Zero Pad Fft')

k2ix=np.array([xi+xm*kx for kx in refx])
k2iy=np.array([yi+ym*ky for ky in refy])


#print k2ix

# 
# RefFftSamp=[ZpHrImgFft[x,y]/HRfactor for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int))]
# RefFftSamp=rs.ravel_kspace(RefFftSamp,true128.shape)


k2ix=np.array([xi+xm*kx for kx in rs.unravel_kspace(refx)])
k2iy=np.array([yi+ym*ky for ky in rs.unravel_kspace(refy)])



ref_image=norm(Image[:,:,0,4])

f,ax=pl.subplots(3,6)


vermin=0
vermax=0.5

for ii,it in enumerate(range(5,8)):
    k=K[:,:,0,it]
    #k=np.fft.fftshift(k)
    kx=MyKxy[:,0,it,0]
    #kx=kx/rxspan
    ky=MyKxy[:,0,it,1]
    #ky=ky/ryspan
    im=Image[:,:,0,it]
    
    
    mcim=norm(MCimage[:,:,0,it])
    

    MyKx=kx/scalex*OS/(MyPi*4)
    MyKy=ky/scaley*OS/(MyPi*4)

    imK=np.fft.fftshift(np.fft.fft2(im))
    
    
    
    
    Kim=norm(np.abs(np.fft.fftshift(np.fft.ifft2(k))))
    
    
    
    #########################################################
    
    listk=list(rs.unravel_kspace(np.rot90(k,0,axes=(0,1))))
    MyImg=rs.MyIfft3(MyKx,MyKy,X,Y,listk)        
    MyImg=np.flipud(np.rot90(MyImg,1,axes=(0,1)))
    
    ##########################################################


    
    im=norm(im)
    MyImg=norm(np.abs(MyImg))
    
    
    a=ax[0,ii*2]
    a.matshow(im,vmin=0,vmax=1)
    if ii==0:
        title='Uncorrected Image (Ref)'
    else:
        title='Uncorrected Image'
    a.set_title(title)
    a.set_yticklabels([])
    a.set_xticklabels([])
    
    a=ax[0,ii*2+1]
    a.matshow(np.abs(im-ref_image),vmin=vermin,vmax=vermax)
    a.set_title('Uncorrected - Ref')
    a.set_yticklabels([])
    a.set_xticklabels([])    
    
    a=ax[1,ii*2]
    a.matshow(mcim,vmin=0,vmax=1)
    a.set_title('MCflirt Image')
    a.set_yticklabels([])
    a.set_xticklabels([])
    
    a=ax[1,ii*2+1]
    if it==6:
        cax=a.matshow(np.abs(mcim-ref_image),vmin=vermin,vmax=vermax)
        #f.colorbar(cax)
    else:
        a.matshow(np.abs(mcim-ref_image),vmin=vermin,vmax=vermax)
    #a.matshow(np.abs(mcim-ref_image),vmin=vermin,vmax=vermax)
    a.set_title('MCflirt - Ref')
    a.set_yticklabels([])
    a.set_xticklabels([])
    
    a=ax[2,ii*2]
    a.matshow(MyImg,vmin=0,vmax=1)
    a.set_title('DRIFT image')
    a.set_yticklabels([])
    a.set_xticklabels([])
    
    a=ax[2,ii*2+1]
    a.matshow(np.abs(MyImg-ref_image),vmin=vermin,vmax=vermax)
    a.set_title('DRIFT - Ref')
    a.set_yticklabels([])
    a.set_xticklabels([])

f.subplots_adjust(right=0.8)
cbar_ax = f.add_axes([0.85, 0.15, 0.05, 0.7])
f.colorbar(cax,cax=cbar_ax)

pl.suptitle('20deg z rotation POSSUM')
pl.show()
    
    
        




    # f,ax=pl.subplots(2,5)
    # 
    # a=ax[0,0]
    # a.matshow(ref_image,vmin=0,vmax=1)
    # a.set_title('Ref Im')
    # 
    # a=ax[0,1]
    # a.matshow(im,vmin=0,vmax=1)
    # a.set_title('current Image')
    # 
    # 
    # a=ax[0,2]
    # a.matshow(np.abs(im-ref_image),vmin=vermin,vmax=vermax)
    # a.set_title('current-ref')
    # 
    # a=ax[0,3]
    # a.matshow(Kim)
    # a.set_title('Pyifft of k')
    # 
    # a=ax[0,4]
    # a.matshow(np.log(np.abs(np.fft.fftshift(np.fft.fft2(im)))))
    # a.set_title('Pyfft of im')
    # 
    # a=ax[1,0]
    # a.plot(kx,ky)
    # a.set_title('Kspace')
    # 
    # a=ax[1,1]
    # a.matshow(MyImg,vmin=0,vmax=1)
    # a.set_title('DRIFT Image')
    # 
    # 
    # a=ax[1,2]
    # a.matshow(np.abs(MyImg-ref_image),vmin=vermin,vmax=vermax)
    # a.set_title('DRIFT-ref')
    # 
    # 
    # a=ax[1,3]
    # a.matshow(np.abs(Kim-ref_image),vmin=vermin,vmax=vermax)
    # a.set_title('PyifftK-ref')
    #     
    # 
    # a=ax[1,4]
    # a.matshow(np.log(np.abs(k)))
    # a.set_title('kspace.dat')
    # 
    # 
    # 
    # 
    # 
    # pl.show()
    

    
    
    
    
    
    
    
    
    
    