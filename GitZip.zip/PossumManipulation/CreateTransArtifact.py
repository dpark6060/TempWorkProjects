#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl



#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import seaborn as sb
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb
sys.path.append('/share/dbp2123/dparker/Code/KSpaceMotion/Code/Python')
import FreqDomainResampSupport as rs
import scipy.ndimage as ndi



IsPossum=True

def norm(data):
    data=data-np.min(data)
    data=data/np.amax(np.abs(data))
    return(data)



def unravel_kspace(imageF,origin='upper'):
    
    if origin=='lower':
        imageF=np.rot90(imageF,k=-1)
    
    newarr=[]
    Lx,Ly=np.shape(imageF)
    ix=0
    iy=0
    xinc=1
    yinc=1
    
    
    for y in range(Ly):
        
        for x in range(Lx):
            newarr.append(imageF[ix,iy])
            ix+=xinc
        xinc*=-1
        ix+=xinc
        iy+=yinc
    return newarr


def ViewImages_K(WrkDir):
    rs.plotPmat(WrkDir)
    ImageFile=os.path.join(WrkDir,'image_abs.nii.gz')
    Image=nb.load(ImageFile).get_data()


    
    KxFile=os.path.join(WrkDir,'Kcoord_mot_bin_kx.nii.gz')
    KyFile=os.path.join(WrkDir,'Kcoord_mot_bin_ky.nii.gz')
    Kx=nb.load(KxFile).get_data()
    Ky=nb.load(KyFile).get_data()
    refx=Kx[:,:,0,1]
    refy=Ky[:,:,0,1]  
    x,y,z,t=np.shape(Image)
    
    
    rx=rs.unravel_kspace(refx)
    ry=rs.unravel_kspace(refy)
    
    
    for ii,it in enumerate(range(t)):
        print it
        
        #k=np.fft.fftshift(k)
        kx=Kx[:,:,0,it]
        kx=rs.unravel_kspace(kx)
        #kx=kx/rxspan
        ky=Ky[:,:,0,it]
        ky=rs.unravel_kspace(ky)
        #ky=ky/ryspan
        im=Image[:,:,0,it]
        
        f,ax=pl.subplots(1,2)
        
        a=ax[0]
        a.matshow(im)
        
        a=ax[1]
        a.plot(rx,ry,'-o')
        a.plot(kx,ky,'-*')
        pl.show()

        
        




def Reconstruct(WrkDir):
        
    
    
    
    #WrkDir='/share/dbp2123/dparker/Code/KSpaceMotion/Possum/Possum41Vol'
    #WrkDir='/share/dbp2123/dparker/Code/KSpaceMotion/Possum/TestImage12_5mmZrot_DavidBuild'
    ImageFile=os.path.join(WrkDir,'image_abs.nii.gz')
    Image=nb.load(ImageFile).get_data()
    ImAff=nb.load(ImageFile).get_affine()
    ImHd=nb.load(ImageFile).get_header()
    
    
    
    KimagFile=os.path.join(WrkDir,'s2i_Kvals_imag.nii.gz')
    KrealFile=os.path.join(WrkDir,'s2i_Kvals_real.nii.gz')
    Kimag=nb.load(KimagFile).get_data()
    Kreal=nb.load(KrealFile).get_data()
    
    
    MCimage=os.path.join(WrkDir,'MC_image_abs.nii.gz')
    MCimage=nb.load(MCimage).get_data()
    
    K=np.zeros(Kreal.shape,complex)
    K=Kreal+1j*Kimag
    print K.shape
    
    KxFile=os.path.join(WrkDir,'Kcoord_mot_bin_kx.nii.gz')
    KyFile=os.path.join(WrkDir,'Kcoord_mot_bin_ky.nii.gz')
    
    Kx=nb.load(KxFile).get_data()
    Ky=nb.load(KyFile).get_data()
    
    
    # pl.matshow(Kx[:,:,0,1])
    # pl.matshow(Ky[:,:,0,1])
    # pl.matshow(Kx[:,:,0,1]-Ky[:,:,0,1])
    # pl.show()
    
    x,y,z,t=np.shape(Image)
    
    OSx=x
    OSy=y
    # xax=np.arange(OS)
    # yax=np.arange(OS)
    #     
    # # xax=xax/OS*2*np.pi+np.pi
    # # yax=yax/OS*2*np.pi+np.pi
    # 
    # Y,X=np.meshgrid(xax,yax)
    
    # pl.plot(unravel_kspace(X),unravel_kspace(Y))
    # 
    # pl.show()
    # pl.matshow(X)
    # pl.title('xax X')
    # pl.matshow(Y)
    # pl.title('yax Y')
    
    
    refx=Kx[:,:,0,1]
    refy=Ky[:,:,0,1]
    rxspan=np.amax(refx)-np.amin(refx)
    ryspan=np.amax(refy)-np.amin(refy)
    
    rxmin=np.amin(refx)
    rymin=np.amin(refy)
    
    
    
    scalex=((np.amax(refx)-np.amin(refx)))/2
    #Kx=Kx/scalex#*(np.pi/dx)
    # 
    scaley=((np.amax(refy)-np.amin(refy)))/2
    #Ky=Ky/scaley#*(np.pi/dy)
    
    xintercept=refx[0,0]
    yintercept=refy[0,0]
    
    orig_size=(OSx,OSy)
    
    xm,xi,ym,yi=rs.mapk2ind(refx,refy,orig_size,orig_size,1)
    
    
    
    MyPi=np.pi
    
    
    # xax=np.arange(OS)-OS/2.0
    # yax=np.arange(OS)-OS/2.0
    stepdown=2
    xax=np.linspace(0,OSx-stepdown,OSx)-(OSx-stepdown)/2.0
    yax=np.linspace(0,OSy-stepdown,OSy)-(OSy-stepdown)/2.0
    
    xax=xax/(OSx)*2*MyPi
    yax=yax/(OSy)*2*MyPi
    
    # xax=np.fft.fftfreq(OS)*2*MyPi
    # yax=np.fft.fftfreq(OS)*2*MyPi
    
    
    # xax=np.fft.fftshift(xax)
    # yax=np.fft.fftshift(yax)
    
    dx=np.mean(np.diff(xax))
    dy=np.mean(np.diff(yax))
    
    # xax*=xdim
    # yax*=ydim
    print dx
    print dy
    
    X,Y=np.meshgrid(xax+dx/2,yax+dy/2)
    
    
    # pl.matshow(np.log(np.abs(HrImgFft)),origin='lower')
    # pl.title('HR FFt')
    # pl.matshow(np.log(np.abs(ZpHrImgFft)),origin='lower')
    # pl.title('Zero Pad Fft')
    
    k2ix=np.array([xi+xm*kx for kx in refx])
    k2iy=np.array([yi+ym*ky for ky in refy])
    
    
    #print k2ix
    
    # 
    # RefFftSamp=[ZpHrImgFft[x,y]/HRfactor for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int))]
    # RefFftSamp=rs.ravel_kspace(RefFftSamp,true128.shape)
    
    
    k2ix=np.array([xi+xm*kx for kx in unravel_kspace(refx)])
    k2iy=np.array([yi+ym*ky for ky in unravel_kspace(refy)])
    
    
    
    ref_image=norm(Image[:,:,0,4])
    
    f,ax=pl.subplots(3,6)
    
    
    vermin=0
    vermax=0.5
    
    MyRecon=np.zeros((x,y,z,t))
    refimage=Image[:,:,0,1]
    
    DRIFT_rmsd=[]
    MCFLIRT_rmsd=[]
    
    for ii,it in enumerate(range(t)):
        print it
        k=K[:,:,0,it]
        #k=np.fft.fftshift(k)
        kx=Kx[:,:,0,it]
        #kx=kx/rxspan
        ky=Ky[:,:,0,it]
        #ky=ky/ryspan
        im=Image[:,:,0,it]
        
        
        mcim=norm(MCimage[:,:,0,it])
        
        #print kx
        #print rxmin
        
        nx,ny=np.shape(kx)
        # kx=kx-rxmin
        # kx=kx/rxspan
        
        MyKx=unravel_kspace(kx/scalex*OSx/(MyPi*4))
        MyKy=unravel_kspace(ky/scaley*OSy/(MyPi*4))
       
        # pl.title('xax ky')
        # pl.show()    
        #print np.shape(k)
        #k=np.rot90(k,k=2,axes=(0,1))
        imK=np.fft.fftshift(np.fft.fft2(im))
        
        
        
        
        
        
        
        #####################################
        
        
        
        testimgFft=unravel_kspace(k)
        
        
    
        #print np.shape(testimgFft)
        #print np.shape(k)
        #pl.plot(MyKx,MyKy,'-o')
        
        listk=list(unravel_kspace(np.rot90(k,0,axes=(0,1))))
        MyImg=rs.MyIfft3(MyKx,MyKy,X,Y,listk)
        
        #MyImg=np.flipud(np.rot90(np.fft.fftshift(MyImg),-1,axes=(0,1)))
        
        
        MyImg=np.flipud(np.rot90(MyImg,-1,axes=(0,1)))
        MyRecon[:,:,0,it]=np.abs(MyImg)
    
        rmsd=np.sqrt(np.mean(np.square(MCimage[:,:,0,it]-refimage)))
        MCFLIRT_rmsd.append(rmsd)
        
        rmsd=np.sqrt(np.mean(np.square(np.abs(MyImg)-refimage)))
        DRIFT_rmsd.append(rmsd)
        
        
    NiiOut=os.path.join(WrkDir,'DRIFT.nii')
    ReconNii=nb.Nifti1Image(MyRecon,ImAff,ImHd)
    
    nb.loadsave.save(ReconNii,NiiOut)
    
    rmsdout=os.path.join(WrkDir,'DRIFT_RMSD.txt')
    np.savetxt(rmsdout,DRIFT_rmsd)
    
    rmsdout=os.path.join(WrkDir,'MCFLIRT_RMSD.txt')
    np.savetxt(rmsdout,MCFLIRT_rmsd)
 
    
    #########################################################
    
def Reconstruct_Trans_old(WrkDir):
        
    
    
    
    #WrkDir='/share/dbp2123/dparker/Code/KSpaceMotion/Possum/Possum41Vol'
    #WrkDir='/share/dbp2123/dparker/Code/KSpaceMotion/Possum/TestImage12_5mmZrot_DavidBuild'
    ImageFile=os.path.join(WrkDir,'image_abs.nii.gz')
    Image=nb.load(ImageFile).get_data()
    ImAff=nb.load(ImageFile).get_affine()
    ImHd=nb.load(ImageFile).get_header()

    
    
    
    
    KimagFile=os.path.join(WrkDir,'s2i_Kvals_imag.nii.gz')
    KrealFile=os.path.join(WrkDir,'s2i_Kvals_real.nii.gz')
    Kimag=nb.load(KimagFile).get_data()
    Kreal=nb.load(KrealFile).get_data()
    
    # 
    # MCimage=os.path.join(WrkDir,'MC_image_abs.nii.gz')
    # MCimage=nb.load(MCimage).get_data()
    
    K=np.zeros(Kreal.shape,complex)
    K=Kreal+1j*Kimag
    print K.shape
    
    KxFile=os.path.join(WrkDir,'Kcoord_mot_bin_kx.nii.gz')
    KyFile=os.path.join(WrkDir,'Kcoord_mot_bin_ky.nii.gz')
    
    Kx=nb.load(KxFile).get_data()
    Ky=nb.load(KyFile).get_data()
    
    
    # pl.matshow(Kx[:,:,0,1])
    # pl.matshow(Ky[:,:,0,1])
    # pl.matshow(Kx[:,:,0,1]-Ky[:,:,0,1])
    # pl.show()
    
    x,y,z,t=np.shape(Image)
    
    OSx=x
    OSy=y

    refx=Kx[:,:,0,1]
    refy=Ky[:,:,0,1]
    rxspan=np.amax(refx)-np.amin(refx)
    ryspan=np.amax(refy)-np.amin(refy)
    
    rxmin=np.amin(refx)
    rymin=np.amin(refy)
    
    
    
    scalex=((np.amax(refx)-np.amin(refx)))/2
    #Kx=Kx/scalex#*(np.pi/dx)
    # 
    scaley=((np.amax(refy)-np.amin(refy)))/2
    #Ky=Ky/scaley#*(np.pi/dy)
    
    xintercept=refx[0,0]
    yintercept=refy[0,0]
    
    orig_size=(OSx,OSy)
    
    xm,xi,ym,yi=rs.mapk2ind(refx,refy,orig_size,orig_size,1)
    
    
    
    MyPi=np.pi
    
    
    # xax=np.arange(OS)-OS/2.0
    # yax=np.arange(OS)-OS/2.0
    stepdown=2
    xax=np.linspace(0,OSx-stepdown,OSx)-(OSx-stepdown)/2.0
    yax=np.linspace(0,OSy-stepdown,OSy)-(OSy-stepdown)/2.0
    
    xax=xax/(OSx)*2*MyPi
    yax=yax/(OSy)*2*MyPi
    
    # xax=np.fft.fftfreq(OS)*2*MyPi
    # yax=np.fft.fftfreq(OS)*2*MyPi
    
    
    # xax=np.fft.fftshift(xax)
    # yax=np.fft.fftshift(yax)
    
    dx=np.mean(np.diff(xax))
    dy=np.mean(np.diff(yax))
    
    # xax*=xdim
    # yax*=ydim
    print dx
    print dy
    
    X,Y=np.meshgrid(xax+dx/2,yax+dy/2)

    
    k2ix=np.array([xi+xm*kx for kx in refx])
    k2iy=np.array([yi+ym*ky for ky in refy])
    
    

    
    k2ix=np.array([xi+xm*kx for kx in unravel_kspace(refx)])
    k2iy=np.array([yi+ym*ky for ky in unravel_kspace(refy)])
    
    
    
    ref_image=norm(Image[:,:,0,4])
    
    #f,ax=pl.subplots(3,6)
    
    
    vermin=0
    vermax=0.5
    
    MyRecon=np.zeros((x,y,z,t))
    refimage=Image[:,:,0,1]
    
    DRIFT_rmsd=[]
    MCFLIRT_rmsd=[]
    
    
    
    
    tmat,fmat,RowKeys=rs.loadPmat(WrkDir)
    VolStartInds=rs.FindVolStartInds(fmat,RowKeys)
    VolReadInds=rs.FindReadIdxs(fmat,RowKeys,VolStartInds)
    GTx,GTy,GTz=rs.CalcGrad_Trans_Effect(tmat,fmat,RowKeys,VolStartInds)
    
    for ii,it in enumerate(range(3,6)):
        
        #Tx,Ty,Tz,Rx,Ry,Rz,gtx,gty,gtz,ft=rs.ExtractMotParFromRead(fmat,RowKeys,it,VolReadInds,GTx,GTy,GTz,tmat)
        Tx,Ty,Tz,Rx,Ry,Rz=rs.ExtractMotParFromRead_old(fmat,RowKeys,it,VolReadInds)
        
        
        
        # pl.plot(tmat,fmat[:,RowKeys['Xgrad']],label='Xgrad')
        # pl.plot(tmat,fmat[:,RowKeys['TransX']],label='TransX')
        # pl.plot(ft,Tx,label='ExtractedTx')
        # 
        # pl.legend()
        # pl.figure()
        # 
        # pl.plot(tmat,fmat[:,RowKeys['Ygrad']],label='Ygrad')
        # pl.plot(tmat,fmat[:,RowKeys['TransY']],label='TransY')
        # pl.plot(ft,Ty,label='ExtractedTy')
        # 
        # pl.legend()
        # pl.figure()
        # pl.show()
        # print it
        
        
        
        k=K[:,:,0,it]
        #k=np.fft.fftshift(k)
        kx=Kx[:,:,0,it]
        #kx=kx/rxspan
        ky=Ky[:,:,0,it]
        #ky=ky/ryspan
        im=Image[:,:,0,it]
        
        
        #mcim=norm(MCimage[:,:,0,it])
        
        #print kx
        #print rxmin
        
        nx,ny=np.shape(kx)
        # kx=kx-rxmin
        # kx=kx/rxspan
        
        
        if any(Tx!=0) or any(Ty!=0):
            print "Detected Translation, Operating"
            # GTx,GTy,GTz,Kx,Ky,Ks
            k=rs.CorrectForTrans_old(Tx,Ty,kx,ky,k)
            #k=rs.CorrectForTrans(gtx,gty,gtz,kx,ky,k)
        
        pl.plot(rs.unravel_kspace(refx),rs.unravel_kspace(refy),'-o')
        pl.plot(rs.unravel_kspace(kx),rs.unravel_kspace(ky),'-*')
        pl.show()
        
        kx=kx/scalex*OSx/(MyPi*4)
        ky=ky/scaley*OSy/(MyPi*4)
        
        MyKx=unravel_kspace(kx)
        MyKy=unravel_kspace(ky)
        # MyKx=unravel_kspace(kx/scalex*OSx/(MyPi*4))
        # MyKy=unravel_kspace(ky/scaley*OSy/(MyPi*4))
       
        # pl.title('xax ky')
        # pl.show()    
        #print np.shape(k)
        #k=np.rot90(k,k=2,axes=(0,1))
        imK=np.fft.fftshift(np.fft.fft2(im))
        
        
        
        
        
        
        
        #####################################
        
        
        
        testimgFft=unravel_kspace(k)
        
        
    
        #print np.shape(testimgFft)
        #print np.shape(k)
        #pl.plot(MyKx,MyKy,'-o')
        
        listk=list(unravel_kspace(np.rot90(k,0,axes=(0,1))))
        MyImg=np.fft.fftshift(np.fft.ifft2(k))#rs.MyIfft3(MyKx,MyKy,X,Y,listk)
        
        #MyImg=np.flipud(np.rot90(np.fft.fftshift(MyImg),-1,axes=(0,1)))
        
        
        #MyImg=np.flipud(np.rot90(MyImg,-1,axes=(0,1)))
        MyRecon[:,:,0,it]=np.abs(MyImg)
        
        
        f,ax=pl.subplots(1,2)
        
        a=ax[0]
        a.matshow(np.abs(MyImg))
        
        a=ax[1]
        a.matshow(np.abs(im))
        pl.show()


        # 
        # rmsd=np.sqrt(np.mean(np.square(MCimage[:,:,0,it]-refimage)))
        # MCFLIRT_rmsd.append(rmsd)
        # 
        rmsd=np.sqrt(np.mean(np.square(np.abs(MyImg)-refimage)))
        DRIFT_rmsd.append(rmsd)
        
        
    NiiOut=os.path.join(WrkDir,'DRIFT.nii')
    ReconNii=nb.Nifti1Image(MyRecon,ImAff,ImHd)
    
    nb.loadsave.save(ReconNii,NiiOut)
    
    rmsdout=os.path.join(WrkDir,'DRIFT_RMSD.txt')
    np.savetxt(rmsdout,DRIFT_rmsd)
    # 
    # rmsdout=os.path.join(WrkDir,'MCFLIRT_RMSD.txt')
    # np.savetxt(rmsdout,MCFLIRT_rmsd)
    # 
    
    #########################################################
    

def CreateTransArt(WrkDir):
        
    
    
    
    #WrkDir='/share/dbp2123/dparker/Code/KSpaceMotion/Possum/Possum41Vol'
    #WrkDir='/share/dbp2123/dparker/Code/KSpaceMotion/Possum/TestImage12_5mmZrot_DavidBuild'
    ImageFile=os.path.join(WrkDir,'image_abs.nii.gz')
    Image=nb.load(ImageFile).get_data()
    ImAff=nb.load(ImageFile).get_affine()
    ImHd=nb.load(ImageFile).get_header()

    
    
    
    
    KimagFile=os.path.join(WrkDir,'s2i_Kvals_imag.nii.gz')
    KrealFile=os.path.join(WrkDir,'s2i_Kvals_real.nii.gz')
    Kimag=nb.load(KimagFile).get_data()
    Kreal=nb.load(KrealFile).get_data()
    
    # 
    # MCimage=os.path.join(WrkDir,'MC_image_abs.nii.gz')
    # MCimage=nb.load(MCimage).get_data()
    
    K=np.zeros(Kreal.shape,complex)
    K=Kreal+1j*Kimag
    print K.shape
    
    KxFile=os.path.join(WrkDir,'Kcoord_mot_bin_kx.nii.gz')
    KyFile=os.path.join(WrkDir,'Kcoord_mot_bin_ky.nii.gz')
    
    Kx=nb.load(KxFile).get_data()
    Ky=nb.load(KyFile).get_data()
    
    
    # pl.matshow(Kx[:,:,0,1])
    # pl.matshow(Ky[:,:,0,1])
    # pl.matshow(Kx[:,:,0,1]-Ky[:,:,0,1])
    # pl.show()
    
    x,y,z,t=np.shape(Image)
    
    OSx=x
    OSy=y

    refx=Kx[:,:,0,1]
    refy=Ky[:,:,0,1]
    rxspan=np.amax(refx)-np.amin(refx)
    ryspan=np.amax(refy)-np.amin(refy)
    
    rxmin=np.amin(refx)
    rymin=np.amin(refy)
    
    
    
    scalex=((np.amax(refx)-np.amin(refx)))/2
    #Kx=Kx/scalex#*(np.pi/dx)
    # 
    scaley=((np.amax(refy)-np.amin(refy)))/2
    #Ky=Ky/scaley#*(np.pi/dy)
    
    xintercept=refx[0,0]
    yintercept=refy[0,0]
    
    orig_size=(OSx,OSy)
    
    xm,xi,ym,yi=rs.mapk2ind(refx,refy,orig_size,orig_size,1)
    
    
    
    MyPi=np.pi
    
    
    # xax=np.arange(OS)-OS/2.0
    # yax=np.arange(OS)-OS/2.0
    stepdown=2
    xax=np.linspace(0,OSx-stepdown,OSx)-(OSx-stepdown)/2.0
    yax=np.linspace(0,OSy-stepdown,OSy)-(OSy-stepdown)/2.0
    
    xax=xax/(OSx)*2*MyPi
    yax=yax/(OSy)*2*MyPi
    
    # xax=np.fft.fftfreq(OS)*2*MyPi
    # yax=np.fft.fftfreq(OS)*2*MyPi
    
    
    # xax=np.fft.fftshift(xax)
    # yax=np.fft.fftshift(yax)
    
    dx=np.mean(np.diff(xax))
    dy=np.mean(np.diff(yax))
    
    # xax*=xdim
    # yax*=ydim
    print dx
    print dy
    
    X,Y=np.meshgrid(xax+dx/2,yax+dy/2)

    
    k2ix=np.array([xi+xm*kx for kx in refx])
    k2iy=np.array([yi+ym*ky for ky in refy])
    
    

    
    k2ix=np.array([xi+xm*kx for kx in unravel_kspace(refx)])
    k2iy=np.array([yi+ym*ky for ky in unravel_kspace(refy)])
    
    
    
    ref_image=norm(Image[:,:,0,4])
    
    #f,ax=pl.subplots(3,6)
    
    
    vermin=0
    vermax=0.5
    
    MyRecon=np.zeros((x,y,z,t))
    refimage=Image[:,:,0,1]
    
    DRIFT_rmsd=[]
    MCFLIRT_rmsd=[]
    
    
    
    
    tmat,fmat,RowKeys=rs.loadPmat(WrkDir)
    VolStartInds=rs.FindVolStartInds(fmat,RowKeys)
    VolReadInds=rs.FindReadIdxs(fmat,RowKeys,VolStartInds)
    GTx,GTy,GTz=rs.CalcGrad_Trans_Effect_old(tmat,fmat,RowKeys,VolStartInds)
    
    for ii,it in enumerate(range(3,6)):
        
        Tx,Ty,Tz,Rx,Ry,Rz,gtx,gty,gtz,ft=rs.ExtractMotParFromRead(fmat,RowKeys,it,VolReadInds,GTx,GTy,GTz,tmat)
        #Tx,Ty,Tz,Rx,Ry,Rz=rs.ExtractMotParFromRead_old(fmat,RowKeys,it,VolReadInds)
        
        
        # 
        # pl.plot(tmat,fmat[:,RowKeys['Xgrad']],label='Xgrad')
        # pl.plot(tmat,fmat[:,RowKeys['TransX']],label='TransX')
        # pl.plot(ft,Tx,label='ExtractedTx')
        # pl.plot(ft,gtx,label='GradEffectedX')
        # 
        # 
        # 
        # pl.plot(tmat,fmat[:,RowKeys['Ygrad']],label='Ygrad')
        # pl.plot(tmat,fmat[:,RowKeys['TransY']],label='TransY')
        # pl.plot(ft,Ty,label='ExtractedTy')
        # pl.plot(ft,gty,label='GradEffectedY')
        # 
        # pl.legend()
        # 
        # pl.show()
        # print it
        
        
        
        k=K[:,:,0,it]
        #k=np.fft.fftshift(k)
        kx=Kx[:,:,0,it]
        #kx=kx/rxspan
        ky=Ky[:,:,0,it]
        #ky=ky/ryspan
        im=Image[:,:,0,it]
        
        
        #mcim=norm(MCimage[:,:,0,it])
        
        #print kx
        #print rxmin
        PhaseCor=rs.MakeTransCorrectMat(gtx,gty,kx,ky)
        refimage=K[:,:,0,2]
        sim=np.multiply(refimage,PhaseCor)
        simart=np.fft.fftshift(np.fft.ifft2(sim))
        f,ax=pl.subplots(1,3)
        
        a=ax[0]
        a.matshow(np.abs(simart))
        
        a=ax[1]
        a.matshow(np.abs(np.fft.fftshift(np.fft.ifft2(k))))
        a=ax[2]
        a.matshow(im)
        pl.show()
               
        
        
        nx,ny=np.shape(kx)
        # kx=kx-rxmin
        # kx=kx/rxspan
        
        
        if any(Tx!=0) or any(Ty!=0):
            print "Detected Translation, Operating"
            # GTx,GTy,GTz,Kx,Ky,Ks
            #k=rs.CorrectForTrans_old(Tx,Ty,kx,ky,k)
            k=rs.CorrectForTrans(gtx,gty,gtz,kx,ky,k)
        
        kx=kx/scalex*OSx/(MyPi*4)
        ky=ky/scaley*OSy/(MyPi*4)
        
        MyKx=unravel_kspace(kx)
        MyKy=unravel_kspace(ky)
        # MyKx=unravel_kspace(kx/scalex*OSx/(MyPi*4))
        # MyKy=unravel_kspace(ky/scaley*OSy/(MyPi*4))
       
        # pl.title('xax ky')
        # pl.show()    
        #print np.shape(k)
        #k=np.rot90(k,k=2,axes=(0,1))
        imK=np.fft.fftshift(np.fft.fft2(im))
        
        
        
        
        
        
        
        #####################################
        
        
        
        testimgFft=unravel_kspace(k)
        
        
    
        #print np.shape(testimgFft)
        #print np.shape(k)
        #pl.plot(MyKx,MyKy,'-o')
        
        listk=list(unravel_kspace(np.rot90(k,0,axes=(0,1))))
        MyImg=rs.MyIfft3(MyKx,MyKy,X,Y,listk)
        
        #MyImg=np.flipud(np.rot90(np.fft.fftshift(MyImg),-1,axes=(0,1)))
        
        
        MyImg=np.flipud(np.rot90(MyImg,-1,axes=(0,1)))
        MyRecon[:,:,0,it]=np.abs(MyImg)
        
        
        f,ax=pl.subplots(1,2)
        
        a=ax[0]
        a.matshow(np.abs(MyImg))
        
        a=ax[1]
        a.matshow(np.abs(im))
        pl.show()
        

        # 
        # rmsd=np.sqrt(np.mean(np.square(MCimage[:,:,0,it]-refimage)))
        # MCFLIRT_rmsd.append(rmsd)
        # 
        rmsd=np.sqrt(np.mean(np.square(np.abs(MyImg)-refimage)))
        DRIFT_rmsd.append(rmsd)
        
        
    NiiOut=os.path.join(WrkDir,'DRIFT.nii')
    ReconNii=nb.Nifti1Image(MyRecon,ImAff,ImHd)
    
    nb.loadsave.save(ReconNii,NiiOut)
    
    rmsdout=os.path.join(WrkDir,'DRIFT_RMSD.txt')
    np.savetxt(rmsdout,DRIFT_rmsd)
    # 
    # rmsdout=os.path.join(WrkDir,'MCFLIRT_RMSD.txt')
    # np.savetxt(rmsdout,MCFLIRT_rmsd)
    # 
    
    #########################################################
    







WrkDir='/share/dbp2123/dparker/Code/KSpaceMotion/Possum/Possum_10mmY'
#rs.plotPmat(WrkDir)
Reconstruct_Trans_old(WrkDir)
#CreateTransArt(WrkDir)

#rs.TestExtraction(WrkDir)
#ViewImages_K(WrkDir)


#CalcDiff()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    