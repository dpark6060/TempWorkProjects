#!/usr/bin/env python
import nibabel as nb
import numpy as np
import subprocess as sp

WrkDir='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord'
brainFile=os.path.join(WrkDir,brain)
brain=nb.load(brainFile).get_data()
gray=brain[:,:,:,0]
white=brain[:,:,:,1]
csf=brain[:,:,:,2]

PD=gray*0.86+white*0.77+csf*1
PDSlice=PD[:,:,105:111]
PDSlice=PDSlice.mean(axis=-1)

T1=1.331*gray+.832*white+3.7*csf
T1Slice=T1[:,:,105:111].mean(axis=-1)

T2s=.051*gray+.044*white+.5*csf
T2sSlice=T2s[:,:,105:111].mean(axis=-1)

cmd='fslroi {0}/brain.nii.gz {0}/BrainSlice 0 -1 0 -1 105 1 0 1'.format(WrkDir)

BrainSliceFile=os.path.join(WrkDir,'BrainSlice.nii.gz')

TempNii=nb.load(BrainSliceFile)

PdOut=os.path.join(WrkDir,'PDMap.nii.gz')
PDNii=nb.Nifti1Image(PDSlice,TempNii.get_affine(),TempNii.get_header())
nb.loadsave.save(PDNii,PdOut)

T1Out=os.path.join(WrkDir,'T1Map.nii.gz')
T1Nii=nb.Nifti1Image(T1Slice,TempNii.get_affine(),TempNii.get_header())
nb.loadsave.save(T1Nii,T1Out)

T2sOut=os.path.join(WrkDir,'T1Map.nii.gz')
T2sNii=nb.Nifti1Image(T2sSlice,TempNii.get_affine(),TempNii.get_header())
nb.loadsave.save(T2sNii,T2sOut)




PDsmall=np.zeros(112,112)
T1small=np.zeros(112,112)
T2small=np.zeros(112,112)



x,y=PDSlice.shape

xpad=112-x
ypad=112-y
































