#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import seaborn as sb
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb
sys.path.append('/share/dbp2123/dparker/Code/KSpaceMotion/Code/Python')
import FreqDomainResampSupport as rs
import scipy.ndimage as ndi

def norm(data):
    data=data-np.min(data)
    data=data/np.amax(np.abs(data))
    return(data)



def unravel_kspace(imageF,origin='upper'):
    
    if origin=='lower':
        imageF=np.rot90(imageF,k=-1)
    
    newarr=[]
    Lx,Ly=np.shape(imageF)
    ix=0
    iy=0
    xinc=1
    yinc=1
    
    
    for y in range(Ly):
        
        for x in range(Lx):
            newarr.append(imageF[ix,iy])
            ix+=xinc
        xinc*=-1
        ix+=xinc
        iy+=yinc
    return newarr






WrkDir='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast_Kcoord'
#WrkDir='/share/dbp2123/dparker/Code/KSpaceMotion/Possum/TestImage12_5mmZrot_DavidBuild'
ImageFile=os.path.join(WrkDir,'image_abs.nii.gz')
Image=nb.load(ImageFile).get_data()

KimagFile=os.path.join(WrkDir,'s2i_Kvals_imag.nii.gz')
KrealFile=os.path.join(WrkDir,'s2i_Kvals_real.nii.gz')
Kimag=nb.load(KimagFile).get_data()
Kreal=nb.load(KrealFile).get_data()


MCimage=os.path.join(WrkDir,'MC_image_abs.nii.gz')
MCimage=nb.load(MCimage).get_data()

K=np.zeros(Kreal.shape,complex)
K=Kreal+1j*Kimag
print K.shape

KxFile=os.path.join(WrkDir,'Kcoord_mot_bin_kx.nii.gz')
KyFile=os.path.join(WrkDir,'Kcoord_mot_bin_ky.nii.gz')

Kx=nb.load(KxFile).get_data()
Ky=nb.load(KyFile).get_data()


# pl.matshow(Kx[:,:,0,1])
# pl.matshow(Ky[:,:,0,1])
# pl.matshow(Kx[:,:,0,1]-Ky[:,:,0,1])
# pl.show()

x,y,z,t=np.shape(Image)

OS=112.0
# xax=np.arange(OS)
# yax=np.arange(OS)
#     
# # xax=xax/OS*2*np.pi+np.pi
# # yax=yax/OS*2*np.pi+np.pi
# 
# Y,X=np.meshgrid(xax,yax)

# pl.plot(unravel_kspace(X),unravel_kspace(Y))
# 
# pl.show()
# pl.matshow(X)
# pl.title('xax X')
# pl.matshow(Y)
# pl.title('yax Y')


refx=Kx[:,:,0,1]
refy=Ky[:,:,0,1]
rxspan=np.amax(refx)-np.amin(refx)
ryspan=np.amax(refy)-np.amin(refy)

rxmin=np.amin(refx)
rymin=np.amin(refy)


OS=112
HRfactor=1.5
UpFactor=10

scalex=((np.amax(refx)-np.amin(refx)))/2
#Kx=Kx/scalex#*(np.pi/dx)
# 
scaley=((np.amax(refy)-np.amin(refy)))/2
#Ky=Ky/scaley#*(np.pi/dy)

xintercept=refx[0,0]
yintercept=refy[0,0]

orig_size=(OS,OS)

xm,xi,ym,yi=rs.mapk2ind(refx,refy,orig_size,orig_size,1)



MyPi=np.pi


# xax=np.arange(OS)-OS/2.0
# yax=np.arange(OS)-OS/2.0
stepdown=2
xax=np.linspace(0,OS-stepdown,OS)-(OS-stepdown)/2.0
yax=np.linspace(0,OS-stepdown,OS)-(OS-stepdown)/2.0

xax=xax/(OS)*2*MyPi
yax=yax/(OS)*2*MyPi

# xax=np.fft.fftfreq(OS)*2*MyPi
# yax=np.fft.fftfreq(OS)*2*MyPi


# xax=np.fft.fftshift(xax)
# yax=np.fft.fftshift(yax)

dx=np.mean(np.diff(xax))
dy=np.mean(np.diff(yax))

# xax*=xdim
# yax*=ydim
print dx
print dy

X,Y=np.meshgrid(xax+dx/2,yax+dy/2)


# pl.matshow(np.log(np.abs(HrImgFft)),origin='lower')
# pl.title('HR FFt')
# pl.matshow(np.log(np.abs(ZpHrImgFft)),origin='lower')
# pl.title('Zero Pad Fft')

k2ix=np.array([xi+xm*kx for kx in refx])
k2iy=np.array([yi+ym*ky for ky in refy])


#print k2ix

# 
# RefFftSamp=[ZpHrImgFft[x,y]/HRfactor for x,y in zip(np.round(k2ix).astype(int),np.round(k2iy).astype(int))]
# RefFftSamp=rs.ravel_kspace(RefFftSamp,true128.shape)


k2ix=np.array([xi+xm*kx for kx in unravel_kspace(refx)])
k2iy=np.array([yi+ym*ky for ky in unravel_kspace(refy)])



ref_image=norm(Image[:,:,0,4])

f,ax=pl.subplots(3,6)


vermin=0
vermax=0.5

for ii,it in enumerate(range(4,7)):
    k=K[:,:,0,it]
    #k=np.fft.fftshift(k)
    kx=Kx[:,:,0,it]
    #kx=kx/rxspan
    ky=Ky[:,:,0,it]
    #ky=ky/ryspan
    im=Image[:,:,0,it]
    
    
    mcim=norm(MCimage[:,:,0,it])
    
    #print kx
    #print rxmin
    
    nx,ny=np.shape(kx)
    # kx=kx-rxmin
    # kx=kx/rxspan
    
    MyKx=unravel_kspace(kx/scalex*OS/(MyPi*4))
    MyKy=unravel_kspace(ky/scaley*OS/(MyPi*4))
   
    # pl.title('xax ky')
    # pl.show()    
    #print np.shape(k)
    #k=np.rot90(k,k=2,axes=(0,1))
    imK=np.fft.fftshift(np.fft.fft2(im))
    
    
    
    
    
    
    
    #####################################
    
    
    
    testimgFft=unravel_kspace(k)
    
    

    #print np.shape(testimgFft)
    #print np.shape(k)
    #pl.plot(MyKx,MyKy,'-o')
    
    listk=list(unravel_kspace(np.rot90(k,0,axes=(0,1))))
    MyImg=rs.MyIfft3(MyKx,MyKy,X,Y,listk)
    
    #MyImg=np.flipud(np.rot90(np.fft.fftshift(MyImg),-1,axes=(0,1)))
    
    MyImg=np.flipud(np.rot90(MyImg,-1,axes=(0,1)))
##########################################################


    # 
    # print np.shape(listk)
    # MyImg=rs.MyIfft2(kx,ky,X,Y,listk)
    
    
    
    im=norm(im)
    MyImg=norm(np.abs(MyImg))
    a=ax[0,ii*2]
    a.matshow(im,vmin=0,vmax=1)
    if ii==0:
        title='Uncorrected Image (Ref)'
    else:
        title='Uncorrected Image'
    a.set_title(title)
    a.set_yticklabels([])
    a.set_xticklabels([])
    
    a=ax[0,ii*2+1]
    a.matshow(np.abs(im-ref_image),vmin=vermin,vmax=vermax)
    a.set_title('Uncorrected - Ref')
    a.set_yticklabels([])
    a.set_xticklabels([])    
    
    a=ax[1,ii*2]
    a.matshow(mcim,vmin=0,vmax=1)
    a.set_title('MCflirt Image')
    a.set_yticklabels([])
    a.set_xticklabels([])
    
    a=ax[1,ii*2+1]
    if it==6:
        cax=a.matshow(np.abs(mcim-ref_image),vmin=vermin,vmax=vermax)
        #f.colorbar(cax)
    else:
        a.matshow(np.abs(mcim-ref_image),vmin=vermin,vmax=vermax)
    #a.matshow(np.abs(mcim-ref_image),vmin=vermin,vmax=vermax)
    a.set_title('MCflirt - Ref')
    a.set_yticklabels([])
    a.set_xticklabels([])
    
    a=ax[2,ii*2]
    a.matshow(MyImg,vmin=0,vmax=1)
    a.set_title('DRIFT image')
    a.set_yticklabels([])
    a.set_xticklabels([])
    
    a=ax[2,ii*2+1]
    a.matshow(np.abs(MyImg-ref_image),vmin=vermin,vmax=vermax)
    a.set_title('DRIFT - Ref')
    a.set_yticklabels([])
    a.set_xticklabels([])

f.subplots_adjust(right=0.8)
# cbar_ax = f.add_axes([0.85, 0.15, 0.05, 0.7])
# f.colorbar(cax,cax=cbar_ax)

pl.suptitle('20deg z rotation POSSUM')
pl.show()
    
    
    
    
    
    
    
    
    
    
    
    
    