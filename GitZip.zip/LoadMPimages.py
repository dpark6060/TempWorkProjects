#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import seaborn as sb
import scipy.stats as sts
import subprocess as sp
import pandas as pd
import seaborn as sb



def QuadCopy2D(F,image,pe='y-'):
    
    
    
    
    lx,ly=np.shape(F)
    
    mx=np.mod(lx,2)
    my=np.mod(ly,2)
    lx=np.floor(lx/2.0).astype(int)
    ly=np.floor(ly/2.0).astype(int)   

    
    
    if pe=='x+':
        
        
        ly+=1
        halfsig=F[:,:ly]
    
        realhalf=np.real(halfsig)
        imaghalf=np.imag(halfsig)
        
        realfullsig=np.hstack((realhalf,np.roll(np.fliplr(np.flipud(realhalf[:,1-my:-1])),1-mx,0)))
        imagfullsig=np.hstack((imaghalf,np.roll(np.fliplr(np.flipud(-1*imaghalf[:,1-my:-1])),1-mx,0)))
        
    elif pe=='x-':
        

        ly-=1
        halfsig=F[:,ly:]
        
        realhalf=np.real(halfsig)
        imaghalf=np.imag(halfsig)
        

        
        realfullsig=np.hstack((np.roll(np.fliplr(np.flipud(realhalf[:,1:realhalf.shape[-1]-(1-my)])),-1*(1-mx),0),realhalf))
        imagfullsig=np.hstack((np.roll(np.fliplr(np.flipud(-1*imaghalf[:,1:realhalf.shape[-1]-(1-my)])),-1*(1-mx),0),imaghalf))
        
    elif pe=='y+':
        
        lx+=1
        halfsig=F[:lx,:]
    
        realhalf=np.real(halfsig)
        imaghalf=np.imag(halfsig)
        
        realfullsig=np.vstack((realhalf,np.roll(np.fliplr(np.flipud(realhalf[1-mx:-1:,:])),1-my,1)))
        imagfullsig=np.vstack((imaghalf,np.roll(np.fliplr(np.flipud(-1*imaghalf[1-mx:-1,:])),1-my,1)))
        
    elif pe=='y-':
        
        lx-=1
        halfsig=F[lx:,:]
    
        realhalf=np.real(halfsig)
        imaghalf=np.imag(halfsig)
        
        realfullsig=np.vstack((np.roll(np.fliplr(np.flipud(realhalf[1:realhalf.shape[0]-(1-mx),:])),-1*(1-my),1),realhalf))
        imagfullsig=np.vstack((np.roll(np.fliplr(np.flipud(-1*imaghalf[1:realhalf.shape[0]-(1-mx),:])),-1*(1-my),1),imaghalf))
        
        
    
    fullsig=realfullsig+1j*imagfullsig    
    pl.matshow(np.log(np.abs(fullsig)))
    pl.title('Reconstcuct')
    pl.matshow(np.log(np.abs(F)))
    pl.title('original')    
    
    pl.matshow(image)
    reconstruct=np.fft.ifft2(np.fft.ifftshift(fullsig))
    pl.matshow(np.abs(reconstruct))
    pl.title('reconstruct mag')
    pl.matshow(image-np.abs(reconstruct))
    pl.title('image difference')
    pl.matshow(np.log(np.abs(realfullsig-np.real(F))))
    pl.title('realdiff')
    pl.matshow(np.log(np.abs(imagfullsig-np.imag(F))))
    pl.title('imagdiff')
    pl.show()
    return fullsig


MagNii='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast/image_abs.nii.gz'
PhaseNii='/home/dparker/Desktop/MyOutput/Possum/TestImage12_20ZFast/image_phase.nii.gz'


mag=nb.load(MagNii).get_data()
phase=nb.load(PhaseNii).get_data()

x,y,z,t=mag.shape

for i in range(t):
    if i>3 & i <6:
        m=mag[:,:,0,i]
        p=phase[:,:,0,i]
        
        cpx=m*np.cos(p)+1j*m*np.sin(p)
        Fcpx=np.fft.fftshift(np.fft.fft2(cpx))
        pl.matshow(np.log(np.abs(Fcpx)))
        pl.title('volume {}'.format(i))
        pl.matshow(np.abs(cpx))
        pl.title('volume {}'.format(i))
        
        QuadCopy2D(np.rot90(Fcpx,2,(0,1)),np.rot90(m,2,(0,1)))
    
pl.show()


















