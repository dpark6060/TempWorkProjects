#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import scipy.stats as sts
import subprocess as sp
import MakeMatsFromPar as mm
import scipy.interpolate as itp
import matplotlib.mlab as mlab


def RotateScanlineCoordinate(Nii,ParFile):
    #      (xStart,xStop,Nx,Y,Z,Rx,Ry,Rz)
    data=nb.load(Nii).get_data()
    (lx,ly,lz,lt)=data.shape
    
    xMid=lx/2.0
    yMid=ly/2.0
    zMid=lz/2.0
    
    Npts=lx*ly
    
    Params=np.loadtxt(ParFile)
    Params=np.diff(Params,axis=0)
    
    
    data=data[:,:,:,1:]
    
    
    hdr=nb.load(Nii).get_header()
    dx,dy,dz,dt=hdr.get_zooms()
    
    FOVx=dx*lx
    FOVy=dy*ly
    FOVz=dz*lz
    
    # For Possum: Gmax=0.055 T/m
    Gmax=0.055          #T/m
    gamma=42.6e6        #MHz/tesla
    
    Ts=dt/ly
    
    dkx=1.0/FOVx
    dky=1.0/FOVy
    dkz=1.0/FOVz
    
    Kminx=-1*xMid*dkx
    Kmaxx=xMid*dkx
    
    Kminy=-1*yMid*dky*2
    Kmaxy=yMid*dky*2
    
    Kminz=-1*zMid*dkz
    Kmaxz=zMid*dkz

    
    KxV=np.linspace(Kminx,Kmaxx,lx)
    KyV=np.linspace(Kminy,Kmaxy,ly)
    
    Xg,Yg=np.meshgrid(KxV,KyV)
    
    print KxV
    print KyV
    
    print Xg
    print Yg
    print lx
    print ly
    
    for nPar in range(Params.shape[0]):
        img=data[:,:,:,nPar]
        Fimg=np.fft.fftshift(np.fft.fft2(img[:,:,0]))

        parCount=0
        Rx=Params[nPar][0]*-1
        Ry=Params[nPar][1]*-1
        Rz=Params[nPar][2]*-1
        Tx=Params[nPar][3]*-1
        Ty=Params[nPar][4]*-1
        Tz=Params[nPar][5]*-1
        
        RxV=np.linspace(0,Rx,Npts)
        RyV=np.linspace(0,Ry,Npts)
        RzV=np.linspace(0,Rz,Npts)
        TxV=np.linspace(0,Tx,Npts)
        TyV=np.linspace(0,Ty,Npts)
        TzV=np.linspace(0,Tz,Npts)
        #print RzV
        XCount=0
        Xmod=1
        points=[]
        OldPoints=[]
        data=[]
        Fdata=[]
        for y in range(ly):
           # print XCount
            while XCount >= 0 and XCount <= lx-1:
                #print y
                #print XCount
                cx=Xg[y,XCount]
                cy=Yg[y,XCount]
                cz=0
                data.append(img[y,XCount,0])
                Fdata.append(Fimg[y,XCount])
                XCount=XCount+Xmod

                
                theta=RxV[parCount]
                rotx_mat=[[1,0,0,0],[0,np.cos(theta),1*np.sin(theta),0],[0,-1*np.sin(theta),np.cos(theta),0],[0,0,0,1]]
                theta=RyV[parCount]
                roty_mat=[[np.cos(theta),0,-1*np.sin(theta),0],[0,1,0,0],[1*np.sin(theta),0,np.cos(theta),0],[0,0,0,1]]
                theta=RzV[parCount]
                rotz_mat=[[np.cos(theta),-1*np.sin(theta),0,0],[-1*np.sin(theta),np.cos(theta),0,0],[0,0,1,0],[0,0,0,1]]
                #print rotz_mat
                Rot=np.dot(rotz_mat,np.dot(roty_mat,rotx_mat))
                #print Rot
                Trans=[[1,0,0,TxV[parCount]],[0,1,0,TyV[parCount]],[0,0,1,TzV[parCount]],[0,0,0,1]]
                
                
                v=[cx,cy,cz,1]
                Vnew=np.dot(Rot,np.transpose(v))
                # print v
                # print Vnew
                points.append(Vnew)
                OldPoints.append(v)
                

                parCount+=1
                
            Xmod=Xmod*-1
            XCount=XCount+Xmod
                
                
        oldx=[]
        oldy=[]
        newx=[]
        newy=[]
        for p in range(len(OldPoints)):
            oldx.append(OldPoints[p][0])
            oldy.append(OldPoints[p][1])
            newx.append(points[p][0])
            newy.append(points[p][1])
        
        # flat=np.reshape(img,-1)
        # if all(flat==data):
        #     print('true')
        # print flat
        # print data
        # 
        
        pl.plot(oldx,oldy,'r.')
        pl.plot(newx,newy,'b.')
        pl.show()
        print np.shape(newx)
        print np.shape(newy)
        print np.shape(Fdata)
        print np.shape(Xg)
        print np.shape(Yg)
        fr=mlab.griddata(newx,newy,np.real(Fdata),Xg,Yg)
        fi=mlab.griddata(newx,newy,np.imag(Fdata),Xg,Yg)
        print np.where(fr=='--')
        # znewr=fr(oldx,oldy)
        # znewi=fi(oldx,oldy)
        f=fr+1j*fi
        XCount=0
        Xmod=1
        Fnew=np.zeros(Fimg.shape)
        # itCount=0
        # for y in range(ly):
        #    # print XCount
        #     while XCount >= 0 and XCount <= lx-1:
        #         #print y
        #         #print XCount
        #         #print fr
        #         Fnew[y,XCount]=f[itCount]
        #         itCount+=1
        #         
        #     Xmod=Xmod*-1
        #     XCount=XCount+Xmod
            
 
        pl.figure()
        pl.imshow(np.abs(f))
        pl.figure()
        #pl.pcolormesh(Xg,Yg,np.abs(f))
        pl.imshow(np.abs(Fnew))
        #pl.figure()
        #newImg=np.fft.ifftshift(np.fft.ifft2(znewr+1j*znewi))
        # pl.imshow(img)
        # pl.figure()
        # pl.imshow(np.abs(newImg))
        pl.show()
        

        
    


def dKcalc(G,dt):
    gam=42.6e6
    gx=G[0]
    gy=G[1]
    gz=G[2]
    dk=[0,0,0]
    dk[0]=gam*gx*dt
    dk[1]=gam*gx*dt
    dk[2]=gam*gz*dt
    return(dk)

#def RotVect[V,Rx,Ry,Rz]


    
    



def MakeInplane(ParFile):
    
    base,name=os.path.split(ParFile)
    name,ext=os.path.splitext(name)
    
    Mpar=np.loadtxt(ParFile)
    
    ## Motion and rotation in X/Y Plane
    
    # Mpar[:,2]=0
    # Mpar[:,3]=0
    # Mpar[:,4]=0
    
    OutFile=os.path.join(base,'{}_InPlane.txt'.format(name))
    
    np.savetxt(OutFile,Mpar,fmt='%0.7f')
    return(OutFile)



def MakeMatFromPar(ParFile):

    base,name=os.path.split(ParFile)
    name,ext=os.path.splitext(name)
    Mpar=np.loadtxt(ParFile)
    
    #refName=os.path.join(base,'Sim_MC_meanvol.nii.gz') 

    
    for i in range(Mpar.shape[0]):
        par=Mpar[i,:]
        
        
        Tmat=mm.Trans(par[3],par[4],par[5])
        Rx=mm.Rotx(par[0])
        Ry=mm.Roty(par[1])
        Rz=mm.Rotz(par[2])
        Mat=mm.Combine([Rx,Ry,Rz])
        
        Mat[0,-1]=par[3]
        Mat[1,-1]=par[4]
        Mat[2,-1]=par[5]
        
        
        MatDir=os.path.join(base,'NewMats')
        if not os.path.exists(MatDir):
            os.mkdir(MatDir)
        
        matName=os.path.join(base,'NewMats','Mat_{0:04g}'.format(i))
        np.savetxt(matName,Mat,fmt='%0.6f')
    return(MatDir)

def ParDif(ParFile):
    
    base,name=os.path.split(ParFile)
    name,ext=os.path.splitext(name)
    Mpar=np.loadtxt(ParFile)
    
    diff=np.diff(Mpar,axis=-1)
    
    output=os.path.join('base','DiffPar.par')
    np.savetxt(output,diff,fmt='%0.7f')
    return(output)




def SplitPars(ParFile):

    base,name=os.path.split(ParFile)
    name,ext=os.path.splitext(name)
    Mpar=np.loadtxt(ParFile)
    
    
    
    #refName=os.path.join(base,'Sim_MC_meanvol.nii.gz') 

    
    for i in range(Mpar.shape[0]):
        par=Mpar[i,:]
        
        
        Tmat=mm.Trans(par[3],par[4],par[5])
        Rx=mm.Rotx(par[0])
        Ry=mm.Roty(par[1])
        Rz=mm.Rotz(par[2])
        Mat=mm.Combine([Rz,Ry,Rx])
        
        
        
        MatDir=os.path.join(base,'NewMats')
        if not os.path.exists(MatDir):
            os.mkdir(MatDir)
        
        tName=os.path.join(base,'NewMats','Trans_{0:04g}'.format(i))
        np.savetxt(tName,Tmat,fmt='%0.6f')
        rName=os.path.join(base,'NewMats','Rot_{0:04g}'.format(i))
        np.savetxt(rName,Mat,fmt='%0.6f')
        
        cmd='/share/users/dparker/dparker/Code/KSpaceMotion/Code/Bash/ConvertXFM_Mid.sh {} {} /home/dparker/Desktop/simdir/mc/MidShift.mat'.format(tName,rName)
        os.system(cmd)
        
        cmd='mv {0}/NewMats/WrkMat {0}/NewMats/MAT_{1:04g}'.format(base,i)
        os.system(cmd)
        
    return(MatDir)


def PossumMot2Par(PossumFile,Ts,TR,OutFile):
    
    Skip=TR/Ts
    
    Pmot=np.loadtxt(PossumFile)
    lTorig=Pmot.shape[0]
    
    Pmot=Pmot[0::Skip,1:]
    Mpar=np.zeros(Pmot.shape)
    if Mpar.shape[0]*TR>lTorig*Ts:
        Mpar=Mpar[:-1]
        Pmot=Pmot[:-1]
    
    print Pmot.shape
    
    
    
    for i in range(Pmot.shape[0]):
        Mpar[i,0]=Pmot[i,3]
        Mpar[i,1]=Pmot[i,4]
        Mpar[i,2]=Pmot[i,5]
        Mpar[i,3]=Pmot[i,0]*1000
        Mpar[i,4]=Pmot[i,1]*1000
        Mpar[i,5]=Pmot[i,2]*1000
    
    
    toMid=np.array([[1,0,0,-128],[0,1,0,-128],[0,0,1,0],[0,0,0,1]])
    fromMid=np.array([[1,0,0,128],[0,1,0,128],[0,0,1,0],[0,0,0,1]])

    
    np.savetxt(OutFile,Mpar,fmt='%0.7f')
    pass
    
    
    #Mpar=np.array(Mpar)
    #Mpar[np.where(Mpar==0)]=0


###############################################


def main():
    pass




if __name__ == '__main__':
    name=sys.argv[1]
    if name=='SplitPars':
        md=SplitPars(sys.argv[2])
    elif name=='PossumMot2Par':
        #PossumMot2Par(PossumFile,Ts,TR,OutFile):
        PossumMot2Par(sys.argv[2],float(sys.argv[3]),float(sys.argv[4]),sys.argv[5])
    elif name=='ParDif':
        ParDif(sys.argv[2])
    elif name=='RotateScanLine':
        RotateScanlineCoordinate(sys.argv[2],sys.argv[3])








# xStart=0
# xStop=20
# Nx=20
# 
# Y=0
# Z=0
# 
# Rx=np.zeros(Nx)
# Ry=np.zeros(Nx)
# Rz=np.arange(float(Nx))/10*np.pi/180
# 
# 
# NewPoints=RotateScanlineCoordinate(xStart,xStop,Nx,Y,Z,Rx,Ry,Rz)
# 
# OldPoints=[(x,Y,Z,1) for x in np.linspace(xStart,xStop,Nx)]
# 
# oldx=[]
# oldy=[]
# newx=[]
# newy=[]
# for p in range(len(OldPoints)):
#     oldx.append(OldPoints[p][0])
#     oldy.append(OldPoints[p][1])
#     newx.append(NewPoints[p][0])
#     newy.append(NewPoints[p][1])
# 
# pl.plot(oldx,oldy)
# pl.plot(newx,newy)
# pl.show()
