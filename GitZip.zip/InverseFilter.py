#!/usr/bin/env python
import nibabel as nb
import numpy as np
import sys
import os
import glob
import matplotlib.pyplot as pl
import matplotlib as mpl
import scipy.stats as sts
import subprocess as sp



def phantom (matrix_size = 256, phantom_type = 'Modified Shepp-Logan', ellipses = None):
    """
    Create a Shepp-Logan or modified Shepp-Logan phantom::
        phantom (n = 256, phantom_type = 'Modified Shepp-Logan', ellipses = None)
    :param matrix_size: size of imaging matrix in pixels (default 256)
    :param phantom_type: The type of phantom to produce.
        Either "Modified Shepp-Logan" or "Shepp-Logan". This is overridden
        if ``ellipses`` is also specified.
    :param ellipses: Custom set of ellipses to use.  These should be in
        the form::
            [[I, a, b, x0, y0, phi],
            [I, a, b, x0, y0, phi],
                            ...]
        where each row defines an ellipse.
        :I: Additive intensity of the ellipse.
        :a: Length of the major axis.
        :b: Length of the minor axis.
        :x0: Horizontal offset of the centre of the ellipse.
        :y0: Vertical offset of the centre of the ellipse.
        :phi: Counterclockwise rotation of the ellipse in degrees,
            measured as the angle between the horizontal axis and
            the ellipse major axis.
    The image bounding box in the algorithm is ``[-1, -1], [1, 1]``,
    so the values of ``a``, ``b``, ``x0``, ``y0`` should all be specified with
    respect to this box.
    :returns: Phantom image
    References:
    Shepp, L. A.; Logan, B. F.; Reconstructing Interior Head Tissue
    from X-Ray Transmissions, IEEE Transactions on Nuclear Science,
    Feb. 1974, p. 232.
    Toft, P.; "The Radon Transform - Theory and Implementation",
    Ph.D. thesis, Department of Mathematical Modelling, Technical
    University of Denmark, June 1996.
    """

    if (ellipses is None):
        ellipses = _select_phantom (phantom_type)
    elif (np.size (ellipses, 1) != 6):
        raise AssertionError ("Wrong number of columns in user phantom")

    ph = np.zeros ((matrix_size, matrix_size),dtype=np.float32)

    # Create the pixel grid
    ygrid, xgrid = np.mgrid[-1:1:(1j*matrix_size), -1:1:(1j*matrix_size)]

    for ellip in ellipses:
        I   = ellip [0]
        a2  = ellip [1]**2
        b2  = ellip [2]**2
        x0  = ellip [3]
        y0  = ellip [4]
        phi = ellip [5] * np.pi / 180  # Rotation angle in radians

        # Create the offset x and y values for the grid
        x = xgrid - x0
        y = ygrid - y0

        cos_p = np.cos (phi)
        sin_p = np.sin (phi)

        # Find the pixels within the ellipse
        locs = (((x * cos_p + y * sin_p)**2) / a2
        + ((y * cos_p - x * sin_p)**2) / b2) <= 1

        # Add the ellipse intensity to those pixels
        ph [locs] += I

    return ph

def _select_phantom (name):
    if (name.lower () == 'shepp-logan'):
        e = _shepp_logan ()
    elif (name.lower () == 'modified shepp-logan'):
        e = _mod_shepp_logan ()
    else:
        raise ValueError ("Unknown phantom type: %s" % name)
    return e

def _shepp_logan ():
    #  Standard head phantom, taken from Shepp & Logan
    return [[   2,   .69,   .92,    0,      0,   0],
            [-.98, .6624, .8740,    0, -.0184,   0],
            [-.02, .1100, .3100,  .22,      0, -18],
            [-.02, .1600, .4100, -.22,      0,  18],
            [ .01, .2100, .2500,    0,    .35,   0],
            [ .01, .0460, .0460,    0,     .1,   0],
            [ .02, .0460, .0460,    0,    -.1,   0],
            [ .01, .0460, .0230, -.08,  -.605,   0],
            [ .01, .0230, .0230,    0,  -.606,   0],
            [ .01, .0230, .0460,  .06,  -.605,   0]]

def _mod_shepp_logan ():
    #  Modified version of Shepp & Logan's head phantom,
    #  adjusted to improve contrast.  Taken from Toft.
    return [[   1,   .69,   .92,    0,      0,   0],
            [-.80, .6624, .8740,    0, -.0184,   0],
            [-.20, .1100, .3100,  .22,      0, -18],
            [-.20, .1600, .4100, -.22,      0,  18],
            [ .10, .2100, .2500,    0,    .35,   0],
            [ .10, .0460, .0460,    0,     .1,   0],
            [ .10, .0460, .0460,    0,    -.1,   0],
            [ .10, .0460, .0230, -.08,  -.605,   0],
            [ .10, .0230, .0230,    0,  -.606,   0],
            [ .10, .0230, .0460,  .06,  -.605,   0]]



def CreateSamplingFunction(size,m,ss):
    FftSamp=np.zeros((size*m,size*m))
    xis=np.arange(size)*m
    yis=xis.astype(int)
    xis=xis.astype(int)
    
    for ii,xi in enumerate(xis):
        FftSamp[xi,yis]=1
        
    # for ii,xi in enumerate(xis):
    #     if xi+ii<size*m:
    #         FftSamp[xi+ii,yis]=1
    # pl.matshow(FftSamp)
    # pl.show()
    return(FftSamp)

def CreateSamplingFunction2(kxgrid,kygrid,size,m):
    FftSamp=np.zeros((int(size*m),int(size*m)))
    xinds=[]
    yinds=[]
    for kx,ky in zip(kxgrid,kygrid):
        if (kx >=0 and ky >=0) and (kx<size*m and ky<size*m):
            FftSamp[kx,ky]=1
            xinds.append(kx)
            yinds.append(ky)
        else:
            xinds.append(-1)
            yinds.append(-1)
            
            
    # for ii,xi in enumerate(xis):
    #     if xi+ii<size*m:
    #         FftSamp[xi+ii,yis]=1
    # pl.matshow(FftSamp)
    # pl.show()
    return(FftSamp,xinds,yinds)



def SampleKspace(kspace,SamplingGrid,size):
    inds=np.where(SamplingGrid==1)
    NewGrid=kspace[inds].reshape(size)
    return(NewGrid)

def SampleKspace2(kspace,xinds,yinds,size):
    
    NewGrid=[]
    for x,y in zip(xinds,yinds):
        if x!=-1:
            NewGrid.append(kspace[x,y])
        else:
            NewGrid.append(0)
            
    NewGrid=np.array(NewGrid).reshape(size)
    return(NewGrid)

def create_kspace(Nx,Ny,dx=1,dy=1,angle=[0],sample_zero=False):
    
    Nk=Nx*Ny
    
    if len(angle)==1 and angle[0]!=0:
        angle=np.linspace(0,angle[0],Nk)
    elif len(angle)==1 and angle[0]==0:
        angle=np.zeros(Nk)
    elif len(angle)<Nk:
        NewAngle=np.zeros(Nk)
        NewAngle[0:len(angle)]=angle
        NewAngle[len(angle):]=angle[-1]
        angle=NewAngle
        
    
    
    
    Kx=[]
    Ky=[]
    
    xStart=-1*int(np.floor(Nx/2))
    yStart=-1*int(np.floor(Ny/2))
    
    if not sample_zero:
        if np.mod(Nx,2)==0:
            xStart+=0.5
            yStart+=0.5
    

    
       
    ik=0
    rx=xStart
    ry=yStart
    xdir=1
    
    for iy in range(Ny):
        
        for ix in range(Nx):
            
            xx=rx*np.cos(angle[ik]*np.pi/180)-ry*np.sin(angle[ik]*np.pi/180)
            yy=rx*np.sin(angle[ik]*np.pi/180)+ry*np.cos(angle[ik]*np.pi/180)
            
            Kx.append(xx)
            Ky.append(yy)
            
            ik+=1
            rx+=xdir
            
        xdir*=-1
        rx+=xdir        
        ry+=1

    return(np.array(Kx)*dx,np.array(Ky)*dy)


def onedInstance():
    m=10
    sig=np.random.rand(256)
    Fsig=np.fft.fftshift(np.fft.fft(sig))
    pl.plot(np.abs(Fsig))
    pl.figure()
    Fsig_hf=np.fft.fftshift(np.fft.fft(sig,256*m))
    t=np.arange(len(Fsig_hf))
    pl.plot(t,np.abs(Fsig_hf))
    pl.plot(t[::10],np.abs(Fsig_hf[::10]),'-o')
    pl.plot(t[::10],np.abs(Fsig),'--o')
    pl.show()

def ZeroPadUp(size,m,ss):
    FftSamp=np.zeros((size*m,size*m))
    xis=np.arange(size)*m
    yis=xis.astype(int)
    xis=xis.astype(int)
    
    for ii,xi in enumerate(xis):
        FftSamp[xi,yis]=1
        
    # for ii,xi in enumerate(xis):
    #     if xi+ii<size*m:
    #         FftSamp[xi+ii,yis]=1
    # pl.matshow(FftSamp)
    # pl.show()
    return(FftSamp)



    
    


size=100
m=10.0
#onedInstance()
ph_big=phantom(1000)
ph_small=phantom(100)
angle=[5]
origkx,origky=create_kspace(size,size,angle=angle)

origkx-=origkx[0]
origky-=origky[0]

origkx*=m
origky*=m
pl.plot(origkx,origky)
pl.show()
origkx2=np.round(origkx).astype(int)
origky2=np.round(origky).astype(int)




print origkx
Fft_big=np.fft.fft2(ph_big)
#Fft_big=np.fft.fftshift(np.fft.fft2(ph_small,(1000,1000)))





Fft_small=np.fft.fft2(ph_small)

df=1000*1000.0/(100*100.0)

#FftSamp=CreateSamplingFunction(size,m,m)
FftSamp,xinds,yinds=CreateSamplingFunction2(origkx2,origky2,size,m)



pl.matshow(FftSamp)

Fft_downsample=SampleKspace2(Fft_big,xinds,yinds,(size,size))
pl.matshow(np.log(np.abs(Fft_downsample)))
rs=np.fft.ifft2(Fft_big*FftSamp)
pl.matshow(np.abs(rs))
pl.show()

# 
# pl.matshow(Fft_downsample)
# pl.matshow(ph_small)
# pl.show()
#Fft_downsample=Fft_downsample
pl.matshow(np.abs(Fft_downsample))
pl.title('Downsampled')
pl.matshow(np.abs(Fft_small))
pl.title('Small')
pl.matshow(np.abs(Fft_big))
pl.title('Big')
pl.matshow(np.abs(Fft_downsample-Fft_small))
pl.title('difference')
tdsamp=np.fft.fftshift(np.fft.ifft2(np.fft.ifftshift(FftSamp)))

pl.matshow(ph_big)
pl.title('Big')
pl.matshow(ph_small)
pl.title('small')


pl.matshow(np.abs(np.fft.ifft2(Fft_downsample)))
pl.title('Downsampled')




pl.show()



































